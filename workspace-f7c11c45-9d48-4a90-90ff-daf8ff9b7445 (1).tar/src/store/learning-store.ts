import { create } from 'zustand'

export type ViewType = 
  | 'auth'
  | 'dashboard'
  | 'courses'
  | 'course-detail'
  | 'lesson'
  | 'quizzes'
  | 'quiz-detail'
  | 'quiz-taking'
  | 'gamification'
  | 'leaderboard'
  | 'analytics'
  | 'profile'

export interface UserStats {
  totalLessonsCompleted: number
  totalQuizAttempts: number
  totalBadges: number
  averageQuizScore: number
}

export interface User {
  id: string
  email: string
  name: string
  role: string
  avatar: string | null
  points: number
  streak: number
  level: number
  bio: string | null
  stats?: UserStats
}

export interface Course {
  id: string
  title: string
  description: string
  category: string
  difficulty: string
  image: string | null
  duration: string | null
  rating: number
  enrolledCount: number
  topics?: Topic[]
  _count?: { topics: number }
  progress?: number
}

export interface Topic {
  id: string
  name: string
  description: string | null
  order: number
  lessons?: Lesson[]
  _count?: { lessons: number }
}

export interface Lesson {
  id: string
  title: string
  content: string
  type: string
  order: number
  difficulty: string
  duration: number
  topicId: string
  topic?: Topic
  progress?: UserProgress
  isBookmarked?: boolean
}

export interface UserProgress {
  id: string
  completed: boolean
  score: number | null
  timeSpent: number
  completedAt: string | null
}

export interface Quiz {
  id: string
  title: string
  description: string | null
  difficulty: string
  timeLimit: number
  courseId: string | null
  topicId: string | null
  questions?: Question[]
  _count?: { questions: number; attempts: number }
  latestScore?: number | null
}

export interface Question {
  id: string
  text: string
  type: string
  options: string[]
  correctAnswer?: string
  explanation?: string | null
  points: number
  order: number
  userAnswer?: string
}

export interface QuizAttempt {
  id: string
  score: number
  totalPoints: number
  answers: Record<string, string>
  completed: boolean
  completedAt: string | null
}

export interface Badge {
  id: string
  name: string
  description: string
  icon: string
  category: string
  requirement: string | null
  points: number
  earned?: boolean
  earnedAt?: string | null
}

export interface Challenge {
  id: string
  title: string
  description: string
  type: string
  target: number
  points: number
  duration: string
  icon: string
  active: boolean
  progress?: number
  completed?: boolean
  completedAt?: string | null
}

export interface LeaderboardEntry {
  id: string
  name: string
  avatar: string | null
  points: number
  level: number
  streak: number
  rank: number
}

export interface Analytics {
  progressByCategory: { category: string; completed: number; total: number }[]
  quizScores: { date: string; score: number }[]
  weeklyActivity: { day: string; lessons: number; quizzes: number; points: number }[]
  strongTopics: { name: string; score: number }[]
  weakTopics: { name: string; score: number }[]
  learningTime: { date: string; minutes: number }[]
}

export interface Recommendation {
  id: string
  courseId: string | null
  lessonId: string | null
  reason: string
  type: string
  priority: number
  course?: Course
  lesson?: Lesson
}

// Helper to get auth headers
function authHeaders(token: string | null): Record<string, string> {
  const headers: Record<string, string> = { 'Content-Type': 'application/json' }
  if (token) {
    headers['Authorization'] = `Bearer ${token}`
  }
  return headers
}

// Token persistence helpers
function saveToken(token: string) {
  if (typeof window !== 'undefined') {
    localStorage.setItem('learnquest_token', token)
  }
}

function loadToken(): string | null {
  if (typeof window !== 'undefined') {
    return localStorage.getItem('learnquest_token')
  }
  return null
}

function clearToken() {
  if (typeof window !== 'undefined') {
    localStorage.removeItem('learnquest_token')
  }
}

interface LearningState {
  // Auth
  user: User | null
  token: string | null
  isAuthenticated: boolean
  authLoading: boolean
  authError: string | null

  // Navigation
  currentView: ViewType
  selectedCourseId: string | null
  selectedLessonId: string | null
  selectedQuizId: string | null
  sidebarOpen: boolean

  // Data
  courses: Course[]
  currentCourse: Course | null
  currentLesson: Lesson | null
  quizzes: Quiz[]
  currentQuiz: Quiz | null
  badges: Badge[]
  challenges: Challenge[]
  leaderboard: LeaderboardEntry[]
  analytics: Analytics | null
  recommendations: Recommendation[]
  bookmarks: string[]

  // UI State
  loading: boolean
  quizAnswers: Record<string, string>
  quizSubmitted: boolean
  quizResult: QuizAttempt | null
  authMode: 'login' | 'register'

  // Actions
  setView: (view: ViewType) => void
  login: (email: string, password: string) => Promise<void>
  register: (email: string, name: string, password: string) => Promise<void>
  logout: () => void
  restoreSession: () => Promise<void>
  fetchCourses: () => Promise<void>
  fetchCourseDetail: (courseId: string) => Promise<void>
  fetchLesson: (lessonId: string) => Promise<void>
  completeLesson: (lessonId: string, score?: number, timeSpent?: number) => Promise<void>
  fetchQuizzes: (courseId?: string) => Promise<void>
  fetchQuizDetail: (quizId: string) => Promise<void>
  submitQuiz: (quizId: string) => Promise<void>
  setQuizAnswer: (questionId: string, answer: string) => void
  resetQuiz: () => void
  fetchBadges: () => Promise<void>
  fetchChallenges: () => Promise<void>
  fetchLeaderboard: (type?: string) => Promise<void>
  fetchAnalytics: () => Promise<void>
  fetchAIRecommendations: () => Promise<void>
  fetchRecommendations: () => Promise<void>
  fetchBookmarks: () => Promise<void>
  toggleBookmark: (lessonId: string) => Promise<void>
  dailyLogin: () => Promise<void>
  selectCourse: (courseId: string) => void
  selectLesson: (lessonId: string) => void
  selectQuiz: (quizId: string) => void
  setSidebarOpen: (open: boolean) => void
  setAuthMode: (mode: 'login' | 'register') => void
  updateProfile: (data: { name?: string; bio?: string }) => Promise<void>
}

export const useLearningStore = create<LearningState>((set, get) => ({
  // Auth
  user: null,
  token: null,
  isAuthenticated: false,
  authLoading: false,
  authError: null,

  // Navigation
  currentView: 'auth',
  selectedCourseId: null,
  selectedLessonId: null,
  selectedQuizId: null,
  sidebarOpen: true,

  // Data
  courses: [],
  currentCourse: null,
  currentLesson: null,
  quizzes: [],
  currentQuiz: null,
  badges: [],
  challenges: [],
  leaderboard: [],
  analytics: null,
  recommendations: [],
  aiRecommendations: [] as { title: string; reason: string; action: string }[],
  bookmarks: [],

  // UI State
  loading: false,
  quizAnswers: {},
  quizSubmitted: false,
  quizResult: null,
  authMode: 'login',

  // Actions
  setView: (view) => set({ currentView: view }),

  // Restore session from localStorage token
  restoreSession: async () => {
    const token = loadToken()
    if (!token) return
    try {
      const res = await fetch('/api/auth/me', {
        headers: authHeaders(token),
      })
      if (!res.ok) {
        clearToken()
        return
      }
      const data = await res.json()
      set({
        user: data.user,
        token,
        isAuthenticated: true,
        currentView: 'dashboard',
      })
      // Fetch initial data
      get().dailyLogin()
      get().fetchRecommendations()
    } catch {
      clearToken()
    }
  },

  login: async (email, password) => {
    set({ authLoading: true, authError: null })
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Login failed')
      // Save token
      saveToken(data.token)
      set({
        user: data.user,
        token: data.token,
        isAuthenticated: true,
        authLoading: false,
        currentView: 'dashboard',
      })
      // Trigger daily login and fetch initial data
      get().dailyLogin()
      get().fetchRecommendations()
    } catch (error: unknown) {
      set({ authError: (error as Error).message, authLoading: false })
    }
  },

  register: async (email, name, password) => {
    set({ authLoading: true, authError: null })
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, name, password }),
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error || 'Registration failed')
      // Save token
      saveToken(data.token)
      set({
        user: data.user,
        token: data.token,
        isAuthenticated: true,
        authLoading: false,
        currentView: 'dashboard',
      })
    } catch (error: unknown) {
      set({ authError: (error as Error).message, authLoading: false })
    }
  },

  logout: () => {
    clearToken()
    set({
      user: null,
      token: null,
      isAuthenticated: false,
      currentView: 'auth',
      courses: [],
      currentCourse: null,
      currentLesson: null,
      quizzes: [],
      currentQuiz: null,
      badges: [],
      challenges: [],
      leaderboard: [],
      analytics: null,
      recommendations: [],
      bookmarks: [],
      quizAnswers: {},
      quizSubmitted: false,
      quizResult: null,
    })
  },

  fetchCourses: async () => {
    set({ loading: true })
    try {
      const token = get().token
      const res = await fetch('/api/courses', {
        headers: authHeaders(token),
      })
      const data = await res.json()
      const coursesRaw = data.courses || data
      const courses = coursesRaw.map((c: Record<string, unknown>) => ({
        ...c,
        progress: c.progressPercentage ?? c.progress ?? 0,
      }))
      set({ courses, loading: false })
    } catch {
      set({ loading: false })
    }
  },

  fetchCourseDetail: async (courseId) => {
    set({ loading: true })
    try {
      const token = get().token
      const res = await fetch(`/api/courses/${courseId}`, {
        headers: authHeaders(token),
      })
      const data = await res.json()
      set({ currentCourse: data.course || data, loading: false })
    } catch {
      set({ loading: false })
    }
  },

  fetchLesson: async (lessonId) => {
    set({ loading: true })
    try {
      const token = get().token
      const res = await fetch(`/api/lessons/${lessonId}`, {
        headers: authHeaders(token),
      })
      const data = await res.json()
      set({ currentLesson: data.lesson || data, loading: false })
    } catch {
      set({ loading: false })
    }
  },

  completeLesson: async (lessonId, score, timeSpent) => {
    try {
      const token = get().token
      const userId = get().user?.id
      await fetch(`/api/lessons/${lessonId}/complete`, {
        method: 'POST',
        headers: authHeaders(token),
        body: JSON.stringify({ userId, score: score || 100, timeSpent: timeSpent || 300 }),
      })
      // Refresh user data
      const meRes = await fetch('/api/auth/me', {
        headers: authHeaders(token),
      })
      const meData = await meRes.json()
      if (meData.user) {
        set({ user: meData.user })
      }
      // Refresh course detail if we're in one
      const courseId = get().selectedCourseId
      if (courseId) {
        get().fetchCourseDetail(courseId)
      }
    } catch {
      // silently fail
    }
  },

  fetchQuizzes: async (courseId) => {
    set({ loading: true })
    try {
      const params = new URLSearchParams()
      if (courseId) params.set('courseId', courseId)
      const userId = get().user?.id
      if (userId) params.set('userId', userId)
      const token = get().token
      const res = await fetch(`/api/quizzes?${params}`, {
        headers: authHeaders(token),
      })
      const data = await res.json()
      set({ quizzes: data.quizzes || data, loading: false })
    } catch {
      set({ loading: false })
    }
  },

  fetchQuizDetail: async (quizId) => {
    set({ loading: true, quizSubmitted: false, quizResult: null, quizAnswers: {} })
    try {
      const token = get().token
      const res = await fetch(`/api/quizzes/${quizId}`, {
        headers: authHeaders(token),
      })
      const data = await res.json()
      const quizData = data.quiz || data
      if (quizData.questions) {
        quizData.questions = quizData.questions.map((q: Record<string, unknown>) => ({
          ...q,
          options: typeof q.options === 'string' ? JSON.parse(q.options) : q.options,
        }))
      }
      set({ currentQuiz: quizData, loading: false })
    } catch {
      set({ loading: false })
    }
  },

  submitQuiz: async (quizId) => {
    set({ loading: true })
    try {
      const token = get().token
      const userId = get().user?.id
      const res = await fetch(`/api/quizzes/${quizId}/attempt`, {
        method: 'POST',
        headers: authHeaders(token),
        body: JSON.stringify({ userId, answers: get().quizAnswers }),
      })
      const data = await res.json()
      // Refresh user data
      const meRes = await fetch('/api/auth/me', {
        headers: authHeaders(token),
      })
      const meData = await meRes.json()
      if (meData.user) {
        set({ user: meData.user })
      }
      set({ quizSubmitted: true, quizResult: data, loading: false })
    } catch {
      set({ loading: false })
    }
  },

  setQuizAnswer: (questionId, answer) => {
    set((state) => ({
      quizAnswers: { ...state.quizAnswers, [questionId]: answer },
    }))
  },

  resetQuiz: () => {
    set({ quizAnswers: {}, quizSubmitted: false, quizResult: null })
  },

  fetchBadges: async () => {
    try {
      const userId = get().user?.id
      const token = get().token
      const res = await fetch(`/api/badges?userId=${userId}`, {
        headers: authHeaders(token),
      })
      const data = await res.json()
      set({ badges: data.badges || data })
    } catch {
      // silently fail
    }
  },

  fetchChallenges: async () => {
    try {
      const userId = get().user?.id
      const token = get().token
      const res = await fetch(`/api/challenges?userId=${userId}`, {
        headers: authHeaders(token),
      })
      const data = await res.json()
      const challengesRaw = data.challenges || data
      const challenges = challengesRaw.map((c: Record<string, unknown>) => ({
        ...c,
        progress: Number(c.userProgress ?? c.progress ?? 0),
        completed: Boolean(c.completed ?? false),
        completedAt: c.completedAt ? String(c.completedAt) : null,
      }))
      set({ challenges })
    } catch {
      // silently fail
    }
  },

  fetchLeaderboard: async (type = 'all') => {
    try {
      const token = get().token
      const res = await fetch(`/api/leaderboard?type=${type}`, {
        headers: authHeaders(token),
      })
      const data = await res.json()
      set({ leaderboard: data.leaderboard || data })
    } catch {
      // silently fail
    }
  },

  fetchAnalytics: async () => {
    set({ loading: true })
    try {
      const userId = get().user?.id
      const token = get().token
      const res = await fetch(`/api/analytics?userId=${userId}`, {
        headers: authHeaders(token),
      })
      const data = await res.json()
      const analyticsData = data.analytics || data
      const analytics: Analytics = {
        progressByCategory: (analyticsData.progressByCategory || []).map((c: Record<string, unknown>) => ({
          category: String(c.category || ''),
          completed: Number(c.completed || 0),
          total: Number(c.total || 0),
        })),
        quizScores: (analyticsData.quizScores || []).map((s: Record<string, unknown>) => ({
          date: String(s.completedAt || s.date || ''),
          score: Number(s.percentage || s.score || 0),
        })),
        weeklyActivity: (analyticsData.weeklyActivity || []).map((w: Record<string, unknown>) => ({
          day: String(w.date || w.day || ''),
          lessons: Number(w.lessonsCompleted || w.lessons || 0),
          quizzes: Number(w.quizzes || 0),
          points: Number(w.points || 0),
        })),
        strongTopics: (analyticsData.strongTopics || []).map((t: Record<string, unknown>) => ({
          name: String(t.topic || t.name || ''),
          score: Number(t.percentage || t.score || 0),
        })),
        weakTopics: (analyticsData.weakTopics || []).map((t: Record<string, unknown>) => ({
          name: String(t.topic || t.name || ''),
          score: Number(t.percentage || t.score || 0),
        })),
        learningTime: (analyticsData.weeklyActivity || []).map((w: Record<string, unknown>) => ({
          date: String(w.date || ''),
          minutes: Math.round(Number(w.timeSpent || 0) / 60),
        })),
      }
      set({ analytics, loading: false })
    } catch {
      set({ loading: false })
    }
  },

  fetchAIRecommendations: async () => {
    try {
      const userId = get().user?.id
      const token = get().token
      const res = await fetch(`/api/ai-recommendations?userId=${userId}`, {
        headers: authHeaders(token),
      })
      const data = await res.json()
      set({ aiRecommendations: data.recommendations || [] })
    } catch {
      // silently fail
    }
  },

  fetchRecommendations: async () => {
    try {
      const userId = get().user?.id
      const token = get().token
      const res = await fetch(`/api/recommendations?userId=${userId}`, {
        headers: authHeaders(token),
      })
      const data = await res.json()
      const recsRaw = data.recommendations || data || []
      const recommendations = recsRaw.map((r: Record<string, unknown>) => ({
        id: String(r.id || ''),
        courseId: r.courseId ? String(r.courseId) : null,
        lessonId: r.lessonId ? String(r.lessonId) : null,
        reason: String(r.reason || ''),
        type: String(r.type || ''),
        priority: Number(r.priority || 0),
        course: r.courseTitle ? { id: String(r.courseId || ''), title: String(r.courseTitle) } : (r.course as Record<string, unknown> | undefined),
      }))
      set({ recommendations })
    } catch {
      // silently fail
    }
  },

  fetchBookmarks: async () => {
    try {
      const userId = get().user?.id
      const token = get().token
      const res = await fetch(`/api/bookmarks?userId=${userId}`, {
        headers: authHeaders(token),
      })
      const data = await res.json()
      const bookmarkIds = (data.bookmarks || data || []).map((b: { lessonId: string }) => b.lessonId)
      set({ bookmarks: bookmarkIds })
    } catch {
      // silently fail
    }
  },

  toggleBookmark: async (lessonId) => {
    const bookmarks = get().bookmarks
    const userId = get().user?.id
    const token = get().token
    try {
      if (bookmarks.includes(lessonId)) {
        await fetch(`/api/bookmarks/${lessonId}?userId=${userId}`, { 
          method: 'DELETE',
          headers: authHeaders(token),
        })
        set({ bookmarks: bookmarks.filter((id) => id !== lessonId) })
      } else {
        await fetch('/api/bookmarks', {
          method: 'POST',
          headers: authHeaders(token),
          body: JSON.stringify({ userId, lessonId }),
        })
        set({ bookmarks: [...bookmarks, lessonId] })
      }
    } catch {
      // silently fail
    }
  },

  dailyLogin: async () => {
    try {
      const userId = get().user?.id
      const token = get().token
      await fetch('/api/daily-login', {
        method: 'POST',
        headers: authHeaders(token),
        body: JSON.stringify({ userId }),
      })
      // Refresh user data after daily login
      const meRes = await fetch('/api/auth/me', {
        headers: authHeaders(token),
      })
      const meData = await meRes.json()
      if (meData.user) {
        set({ user: meData.user })
      }
    } catch {
      // silently fail
    }
  },

  selectCourse: (courseId) => {
    set({ selectedCourseId: courseId })
    get().fetchCourseDetail(courseId)
    get().setView('course-detail')
  },

  selectLesson: (lessonId) => {
    set({ selectedLessonId: lessonId })
    get().fetchLesson(lessonId)
    get().setView('lesson')
  },

  selectQuiz: (quizId) => {
    set({ selectedQuizId: quizId })
    get().fetchQuizDetail(quizId)
    get().setView('quiz-taking')
  },

  setSidebarOpen: (open) => set({ sidebarOpen: open }),
  setAuthMode: (mode) => set({ authMode: mode }),

  updateProfile: async (data) => {
    try {
      const token = get().token
      await fetch('/api/auth/profile', {
        method: 'PUT',
        headers: authHeaders(token),
        body: JSON.stringify(data),
      })
      // Refresh user
      const meRes = await fetch('/api/auth/me', {
        headers: authHeaders(token),
      })
      const meData = await meRes.json()
      if (meData.user) {
        set({ user: meData.user })
      }
    } catch {
      // silently fail
    }
  },
}))
