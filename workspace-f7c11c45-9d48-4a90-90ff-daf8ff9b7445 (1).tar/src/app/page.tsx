'use client'

import { useLearningStore } from '@/store/learning-store'
import { AnimatePresence, motion } from 'framer-motion'
import { Menu } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { useEffect } from 'react'

// Import all view components
import AuthView from '@/components/learning/auth-view'
import SidebarNav from '@/components/learning/sidebar-nav'
import DashboardView from '@/components/learning/dashboard-view'
import CoursesView from '@/components/learning/courses-view'
import CourseDetailView from '@/components/learning/course-detail-view'
import LessonView from '@/components/learning/lesson-view'
import QuizListView from '@/components/learning/quiz-list-view'
import QuizTakingView from '@/components/learning/quiz-taking-view'
import GamificationView from '@/components/learning/gamification-view'
import LeaderboardView from '@/components/learning/leaderboard-view'
import AnalyticsView from '@/components/learning/analytics-view'
import ProfileView from '@/components/learning/profile-view'
import AIChatAssistant from '@/components/learning/ai-chat-assistant'

function MainContent() {
  const { currentView, setSidebarOpen } = useLearningStore()

  const viewMap: Record<string, React.ReactNode> = {
    dashboard: <DashboardView />,
    courses: <CoursesView />,
    'course-detail': <CourseDetailView />,
    lesson: <LessonView />,
    quizzes: <QuizListView />,
    'quiz-taking': <QuizTakingView />,
    gamification: <GamificationView />,
    leaderboard: <LeaderboardView />,
    analytics: <AnalyticsView />,
    profile: <ProfileView />,
  }

  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={currentView}
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -8 }}
        transition={{ duration: 0.2 }}
        className="flex-1 h-full"
      >
        {viewMap[currentView] || <DashboardView />}
      </motion.div>
    </AnimatePresence>
  )
}

export default function Home() {
  const { isAuthenticated, setSidebarOpen, restoreSession } = useLearningStore()

  // Restore session from JWT token on mount
  useEffect(() => {
    restoreSession()
  }, [restoreSession])

  if (!isAuthenticated) {
    return <AuthView />
  }

  return (
    <div className="min-h-screen flex bg-background">
      {/* Sidebar */}
      <SidebarNav />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top bar for mobile */}
        <header className="sticky top-0 z-30 flex items-center gap-3 px-4 py-3 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 lg:hidden">
          <Button
            variant="ghost"
            size="icon"
            className="h-9 w-9"
            onClick={() => setSidebarOpen(true)}
          >
            <Menu className="w-5 h-5" />
          </Button>
          <span className="font-bold text-lg">LearnQuest</span>
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-y-auto">
          <div className="max-w-7xl mx-auto p-4 md:p-6 lg:p-8">
            <MainContent />
          </div>
        </main>

        {/* Footer */}
        <footer className="border-t border-border bg-card px-4 py-3 text-center text-xs text-muted-foreground">
          LearnQuest — Personalized & Gamified Intelligent Learning Platform
        </footer>
      </div>

      {/* AI Chat Assistant */}
      <AIChatAssistant />
    </div>
  )
}
