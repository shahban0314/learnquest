import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()
    const { userId, answers } = body

    if (!userId || !answers) {
      return NextResponse.json(
        { error: 'userId and answers are required' },
        { status: 400 }
      )
    }

    const quiz = await db.quiz.findUnique({
      where: { id },
      include: { questions: true },
    })

    if (!quiz) {
      return NextResponse.json(
        { error: 'Quiz not found' },
        { status: 404 }
      )
    }

    const user = await db.user.findUnique({
      where: { id: userId },
    })

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      )
    }

    // Calculate score
    let earnedScore = 0
    let totalPoints = 0
    const results: Record<string, { correct: boolean; points: number; earned: number; correctAnswer: string; yourAnswer: string }> = {}

    for (const question of quiz.questions) {
      totalPoints += question.points
      const userAnswer = answers[question.id]
      const isCorrect = userAnswer === question.correctAnswer

      if (isCorrect) {
        earnedScore += question.points
      }

      results[question.id] = {
        correct: isCorrect,
        points: question.points,
        earned: isCorrect ? question.points : 0,
        correctAnswer: question.correctAnswer,
        yourAnswer: userAnswer || '',
      }
    }

    // Create quiz attempt
    const attempt = await db.quizAttempt.create({
      data: {
        userId,
        quizId: id,
        score: earnedScore,
        totalPoints,
        answers: JSON.stringify(answers),
        completed: true,
        completedAt: new Date(),
      },
    })

    // Add points to user
    const pointsEarned = earnedScore
    await db.user.update({
      where: { id: userId },
      data: {
        points: { increment: pointsEarned },
      },
    })

    // Check badge eligibility
    const newBadges: string[] = []

    // Check "first quiz" badge
    const quizAttemptCount = await db.quizAttempt.count({
      where: { userId, completed: true },
    })

    if (quizAttemptCount === 1) {
      const firstQuizBadge = await db.badge.findFirst({
        where: { name: { contains: 'First Quiz' } },
      })
      if (firstQuizBadge) {
        const existingBadge = await db.userBadge.findUnique({
          where: { userId_badgeId: { userId, badgeId: firstQuizBadge.id } },
        })
        if (!existingBadge) {
          await db.userBadge.create({
            data: { userId, badgeId: firstQuizBadge.id },
          })
          newBadges.push(firstQuizBadge.name)
        }
      }
    }

    // Check perfect score badge
    if (earnedScore === totalPoints && totalPoints > 0) {
      const perfectBadge = await db.badge.findFirst({
        where: { name: { contains: 'Perfect Score' } },
      })
      if (perfectBadge) {
        const existingBadge = await db.userBadge.findUnique({
          where: { userId_badgeId: { userId, badgeId: perfectBadge.id } },
        })
        if (!existingBadge) {
          await db.userBadge.create({
            data: { userId, badgeId: perfectBadge.id },
          })
          newBadges.push(perfectBadge.name)
        }
      }
    }

    const percentage = totalPoints > 0 ? Math.round((earnedScore / totalPoints) * 100) : 0

    return NextResponse.json({
      attempt,
      results,
      score: earnedScore,
      totalPoints,
      percentage,
      pointsEarned,
      newBadges,
      message: percentage >= 70 ? 'Great job! You passed!' : 'Keep practicing!',
    })
  } catch (error) {
    console.error('Quiz attempt error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
