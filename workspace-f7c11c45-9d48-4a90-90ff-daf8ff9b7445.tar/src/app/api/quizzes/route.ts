import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const courseId = searchParams.get('courseId')
    const topicId = searchParams.get('topicId')

    const where: Record<string, unknown> = {}
    if (courseId) where.courseId = courseId
    if (topicId) where.topicId = topicId

    const quizzes = await db.quiz.findMany({
      where,
      include: {
        _count: { select: { questions: true, attempts: true } },
      },
      orderBy: { createdAt: 'desc' },
    })

    return NextResponse.json({ quizzes })
  } catch (error) {
    console.error('List quizzes error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
