import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { email, password } = body

    if (!email || !password) {
      return NextResponse.json(
        { error: 'Email and password are required' },
        { status: 400 }
      )
    }

    const user = await db.user.findUnique({
      where: { email },
      include: {
        progress: { select: { id: true } },
        quizAttempts: { select: { id: true, score: true, totalPoints: true } },
        badges: { select: { badgeId: true } },
      },
    })

    if (!user) {
      return NextResponse.json(
        { error: 'Invalid email or password' },
        { status: 401 }
      )
    }

    if (user.password !== password) {
      return NextResponse.json(
        { error: 'Invalid email or password' },
        { status: 401 }
      )
    }

    const { password: _, ...userWithoutPassword } = user
    const totalQuizScore = user.quizAttempts.reduce((sum, a) => sum + a.score, 0)
    const totalQuizPoints = user.quizAttempts.reduce((sum, a) => sum + a.totalPoints, 0)

    return NextResponse.json({
      user: {
        ...userWithoutPassword,
        stats: {
          totalLessonsCompleted: user.progress.length,
          totalQuizAttempts: user.quizAttempts.length,
          totalBadges: user.badges.length,
          averageQuizScore: totalQuizPoints > 0 ? Math.round((totalQuizScore / totalQuizPoints) * 100) : 0,
        },
      },
    })
  } catch (error) {
    console.error('Login error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
