import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')

    if (!userId) {
      return NextResponse.json(
        { error: 'userId is required' },
        { status: 400 }
      )
    }

    const user = await db.user.findUnique({
      where: { id: userId },
    })

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      )
    }

    // Get user's progress across all courses
    const userProgress = await db.userProgress.findMany({
      where: { userId },
      include: {
        lesson: {
          include: {
            topic: {
              include: {
                course: true,
              },
            },
          },
        },
      },
    })

    // Analyze progress by course
    const courseProgressMap = new Map<
      string,
      {
        courseId: string
        courseTitle: string
        category: string
        difficulty: string
        totalLessons: number
        completedLessons: number
        topics: Map<string, { name: string; total: number; completed: number }>
      }
    >()

    for (const p of userProgress) {
      const course = p.lesson.topic.course
      let courseData = courseProgressMap.get(course.id)

      if (!courseData) {
        courseData = {
          courseId: course.id,
          courseTitle: course.title,
          category: course.category,
          difficulty: course.difficulty,
          totalLessons: 0,
          completedLessons: 0,
          topics: new Map(),
        }
        courseProgressMap.set(course.id, courseData)
      }

      courseData.totalLessons += 1
      if (p.completed) courseData.completedLessons += 1

      const topicName = p.lesson.topic.name
      const existingTopic = courseData.topics.get(topicName) || {
        name: topicName,
        total: 0,
        completed: 0,
      }
      existingTopic.total += 1
      if (p.completed) existingTopic.completed += 1
      courseData.topics.set(topicName, existingTopic)
    }

    const recommendations: {
      id: string
      type: string
      reason: string
      courseId?: string
      courseTitle?: string
      priority: number
    }[] = []

    // 1. Weak topics - suggest courses where user has <50% completion
    for (const [, courseData] of courseProgressMap) {
      const completionRate =
        courseData.totalLessons > 0
          ? courseData.completedLessons / courseData.totalLessons
          : 0

      if (completionRate > 0 && completionRate < 0.5) {
        const weakTopicNames = Array.from(courseData.topics.values())
          .filter((t) => t.total > 0 && t.completed / t.total < 0.5)
          .map((t) => t.name)

        recommendations.push({
          id: `weak-${courseData.courseId}`,
          type: 'weak_topic',
          reason: `You're making progress in "${courseData.courseTitle}" but ${weakTopicNames.length > 0 ? `struggling with: ${weakTopicNames.join(', ')}` : 'have some incomplete topics'}. Keep going!`,
          courseId: courseData.courseId,
          courseTitle: courseData.courseTitle,
          priority: 10,
        })
      }
    }

    // 2. Next step - suggest courses where user has started but not completed
    for (const [, courseData] of courseProgressMap) {
      const completionRate =
        courseData.totalLessons > 0
          ? courseData.completedLessons / courseData.totalLessons
          : 0

      if (completionRate >= 0.5 && completionRate < 1) {
        recommendations.push({
          id: `next-${courseData.courseId}`,
          type: 'next_step',
          reason: `You're ${Math.round(completionRate * 100)}% through "${courseData.courseTitle}". Finish strong!`,
          courseId: courseData.courseId,
          courseTitle: courseData.courseTitle,
          priority: 8,
        })
      }
    }

    // 3. Popular courses user hasn't started
    const startedCourseIds = Array.from(courseProgressMap.keys())
    const unstartedCourses = await db.course.findMany({
      where: {
        id: { notIn: startedCourseIds },
      },
      orderBy: { enrolledCount: 'desc' },
      take: 3,
    })

    for (const course of unstartedCourses) {
      recommendations.push({
        id: `popular-${course.id}`,
        type: 'popular',
        reason: `"${course.title}" is popular with ${course.enrolledCount} students. Give it a try!`,
        courseId: course.id,
        courseTitle: course.title,
        priority: 5,
      })
    }

    // 4. AI-suggested based on user's strongest category
    const categoryCount = new Map<string, number>()
    for (const [, courseData] of courseProgressMap) {
      const count = categoryCount.get(courseData.category) || 0
      categoryCount.set(courseData.category, courseData.completedLessons + count)
    }

    const strongestCategory = Array.from(categoryCount.entries()).sort(
      (a, b) => b[1] - a[1]
    )[0]

    if (strongestCategory) {
      const suggestedCourses = await db.course.findMany({
        where: {
          category: strongestCategory[0],
          id: { notIn: startedCourseIds },
        },
        take: 2,
      })

      for (const course of suggestedCourses) {
        recommendations.push({
          id: `ai-${course.id}`,
          type: 'ai_suggested',
          reason: `Since you enjoy ${strongestCategory[0]}, you might like "${course.title}"!`,
          courseId: course.id,
          courseTitle: course.title,
          priority: 3,
        })
      }
    }

    // Sort by priority (highest first)
    recommendations.sort((a, b) => b.priority - a.priority)

    return NextResponse.json({ recommendations })
  } catch (error) {
    console.error('Recommendations error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
