import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')

    const badges = await db.badge.findMany({
      orderBy: [{ category: 'asc' }, { points: 'asc' }],
    })

    let earnedBadgeIds: Set<string> = new Set()
    if (userId) {
      const userBadges = await db.userBadge.findMany({
        where: { userId },
        select: { badgeId: true, earnedAt: true },
      })
      earnedBadgeIds = new Set(userBadges.map((ub) => ub.badgeId))

      // Get earnedAt mapping
      const earnedMap = new Map(userBadges.map((ub) => [ub.badgeId, ub.earnedAt]))

      const badgesWithStatus = badges.map((badge) => ({
        ...badge,
        earned: earnedBadgeIds.has(badge.id),
        earnedAt: earnedMap.get(badge.id) || null,
      }))

      return NextResponse.json({
        badges: badgesWithStatus,
        totalBadges: badges.length,
        earnedCount: earnedBadgeIds.size,
      })
    }

    return NextResponse.json({
      badges: badges.map((b) => ({ ...b, earned: false, earnedAt: null })),
      totalBadges: badges.length,
      earnedCount: 0,
    })
  } catch (error) {
    console.error('Badges error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
