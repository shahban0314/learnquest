import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { userId } = body

    if (!userId) {
      return NextResponse.json(
        { error: 'userId is required' },
        { status: 400 }
      )
    }

    const user = await db.user.findUnique({
      where: { id: userId },
    })

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      )
    }

    const today = new Date().toISOString().split('T')[0] // YYYY-MM-DD
    const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0]

    let streakUpdated = false
    let pointsEarned = 0
    let newStreak = user.streak

    if (user.lastLoginDate === today) {
      // Already logged in today
      return NextResponse.json({
        message: 'Already logged in today',
        streak: user.streak,
        pointsEarned: 0,
        streakUpdated: false,
      })
    }

    if (user.lastLoginDate === yesterday) {
      // Consecutive day - increment streak
      newStreak = user.streak + 1
      streakUpdated = true
    } else if (user.lastLoginDate !== today) {
      // Streak broken - reset to 1
      newStreak = 1
      streakUpdated = true
    }

    // Daily login points: base 10 + streak bonus
    pointsEarned = 10 + Math.min(newStreak * 2, 50) // cap streak bonus at 50

    await db.user.update({
      where: { id: userId },
      data: {
        lastLoginDate: today,
        streak: newStreak,
        points: { increment: pointsEarned },
      },
    })

    // Check streak badges
    const newBadges: string[] = []
    const streakMilestones = [3, 7, 14, 30, 60, 100]
    for (const milestone of streakMilestones) {
      if (newStreak === milestone) {
        const streakBadge = await db.badge.findFirst({
          where: { name: { contains: `${milestone} Day Streak` } },
        })
        if (streakBadge) {
          const existingBadge = await db.userBadge.findUnique({
            where: { userId_badgeId: { userId, badgeId: streakBadge.id } },
          })
          if (!existingBadge) {
            await db.userBadge.create({
              data: { userId, badgeId: streakBadge.id },
            })
            newBadges.push(streakBadge.name)
          }
        }
      }
    }

    return NextResponse.json({
      message: 'Daily login recorded',
      streak: newStreak,
      pointsEarned,
      streakUpdated,
      newBadges,
    })
  } catch (error) {
    console.error('Daily login error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
