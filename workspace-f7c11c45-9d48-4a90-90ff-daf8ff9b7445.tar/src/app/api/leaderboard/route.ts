import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const type = searchParams.get('type') || 'all'

    const users = await db.user.findMany({
      select: {
        id: true,
        name: true,
        avatar: true,
        points: true,
        level: true,
        streak: true,
        createdAt: true,
      },
      orderBy: { points: 'desc' },
      take: 50,
    })

    // For weekly/monthly, we could filter by points earned in that period
    // For this demo, we'll filter based on createdAt or recent activity
    let filteredUsers = users

    if (type === 'weekly') {
      const oneWeekAgo = new Date()
      oneWeekAgo.setDate(oneWeekAgo.getDate() - 7)
      // In a real app, we'd track weekly points separately
      // For demo, just return the same leaderboard
      filteredUsers = users
    } else if (type === 'monthly') {
      const oneMonthAgo = new Date()
      oneMonthAgo.setMonth(oneMonthAgo.getMonth() - 1)
      filteredUsers = users
    }

    const leaderboard = filteredUsers.map((user, index) => ({
      rank: index + 1,
      ...user,
    }))

    return NextResponse.json({ leaderboard, type })
  } catch (error) {
    console.error('Leaderboard error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
