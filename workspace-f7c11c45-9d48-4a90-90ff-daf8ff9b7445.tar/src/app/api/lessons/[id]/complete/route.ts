import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const body = await request.json()
    const { userId, score, timeSpent } = body

    if (!userId) {
      return NextResponse.json(
        { error: 'userId is required' },
        { status: 400 }
      )
    }

    const lesson = await db.lesson.findUnique({
      where: { id },
    })

    if (!lesson) {
      return NextResponse.json(
        { error: 'Lesson not found' },
        { status: 404 }
      )
    }

    const user = await db.user.findUnique({
      where: { id: userId },
    })

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      )
    }

    const existingProgress = await db.userProgress.findUnique({
      where: {
        userId_lessonId: { userId, lessonId: id },
      },
    })

    let progress
    if (existingProgress) {
      progress = await db.userProgress.update({
        where: { id: existingProgress.id },
        data: {
          completed: true,
          score: score ?? existingProgress.score,
          timeSpent: timeSpent ?? existingProgress.timeSpent,
          completedAt: new Date(),
        },
      })
    } else {
      progress = await db.userProgress.create({
        data: {
          userId,
          lessonId: id,
          completed: true,
          score: score ?? null,
          timeSpent: timeSpent ?? 0,
          completedAt: new Date(),
        },
      })
    }

    // Add points for completing lesson
    const pointsEarned = 20
    await db.user.update({
      where: { id: userId },
      data: {
        points: { increment: pointsEarned },
      },
    })

    // Check badge eligibility
    const newBadges: string[] = []

    // Check "first lesson" badge
    const completedCount = await db.userProgress.count({
      where: { userId, completed: true },
    })

    if (completedCount === 1) {
      const firstLessonBadge = await db.badge.findFirst({
        where: { name: { contains: 'First Lesson' } },
      })
      if (firstLessonBadge) {
        const existingBadge = await db.userBadge.findUnique({
          where: { userId_badgeId: { userId, badgeId: firstLessonBadge.id } },
        })
        if (!existingBadge) {
          await db.userBadge.create({
            data: { userId, badgeId: firstLessonBadge.id },
          })
          newBadges.push(firstLessonBadge.name)
        }
      }
    }

    // Check lesson milestone badges (5, 10, 25, 50, 100)
    const milestones = [5, 10, 25, 50, 100]
    for (const milestone of milestones) {
      if (completedCount === milestone) {
        const milestoneBadge = await db.badge.findFirst({
          where: { name: { contains: `${milestone} Lessons` } },
        })
        if (milestoneBadge) {
          const existingBadge = await db.userBadge.findUnique({
            where: { userId_badgeId: { userId, badgeId: milestoneBadge.id } },
          })
          if (!existingBadge) {
            await db.userBadge.create({
              data: { userId, badgeId: milestoneBadge.id },
            })
            newBadges.push(milestoneBadge.name)
          }
        }
      }
    }

    return NextResponse.json({
      progress,
      pointsEarned,
      newBadges,
      message: 'Lesson completed successfully',
    })
  } catch (error) {
    console.error('Complete lesson error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
