import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import ZAI from 'z-ai-web-dev-sdk'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')

    if (!userId) {
      return NextResponse.json(
        { error: 'userId is required' },
        { status: 400 }
      )
    }

    const user = await db.user.findUnique({
      where: { id: userId },
      include: {
        progress: {
          where: { completed: true },
          include: {
            lesson: {
              include: {
                topic: {
                  include: { course: { select: { title: true, category: true } } },
                },
              },
            },
          },
        },
        quizAttempts: {
          where: { completed: true },
          select: { score: true, totalPoints: true, quiz: { select: { title: true, courseId: true } } },
        },
        badges: { select: { badge: { select: { name: true } } } },
      },
    })

    if (!user) {
      return NextResponse.json({ error: 'User not found' }, { status: 404 })
    }

    // Gather all available courses
    const allCourses = await db.course.findMany({
      select: { id: true, title: true, category: true, difficulty: true, description: true },
    })

    // Build context for AI
    const completedLessonTopics = user.progress.map((p) => ({
      lesson: p.lesson.title,
      topic: p.lesson.topic.name,
      course: p.lesson.topic.course.title,
      category: p.lesson.topic.course.category,
    }))

    const quizPerformance = user.quizAttempts.map((a) => ({
      quiz: a.quiz.title,
      score: `${a.score}/${a.totalPoints}`,
      percentage: a.totalPoints > 0 ? Math.round((a.score / a.totalPoints) * 100) : 0,
    }))

    const earnedBadges = user.badges.map((b) => b.badge.name)

    // Get started course IDs
    const startedCourseIds = new Set(
      user.progress.map((p) => p.lesson.topic.course.title)
    )
    const unstartedCourses = allCourses.filter(
      (c) => !startedCourseIds.has(c.title)
    )

    const context = {
      userName: user.name,
      level: user.level,
      points: user.points,
      streak: user.streak,
      completedLessons: completedLessonTopics,
      quizPerformance,
      earnedBadges,
      availableCourses: unstartedCourses.map((c) => ({
        title: c.title,
        category: c.category,
        difficulty: c.difficulty,
      })),
    }

    // Use LLM to generate recommendations
    const zai = await ZAI.create()
    const completion = await zai.chat.completions.create({
      messages: [
        {
          role: 'assistant',
          content: `You are an intelligent learning advisor for an online learning platform called LearnQuest. 
Based on the user's learning history, quiz performance, and available courses, provide 3-5 personalized learning recommendations.
Each recommendation should include:
- A course suggestion (from available courses or courses they've started)
- A specific reason why this course/topic is recommended
- An actionable next step

Format your response as a JSON array of objects with fields: "title", "reason", "action"
Keep reasons concise (1-2 sentences). Be encouraging and specific.`,
        },
        {
          role: 'user',
          content: `Here is the user's learning data:\n${JSON.stringify(context, null, 2)}\n\nPlease provide personalized learning recommendations.`,
        },
      ],
      thinking: { type: 'disabled' },
    })

    let recommendations = []
    try {
      const content = completion.choices[0]?.message?.content || '[]'
      // Try to extract JSON from the response
      const jsonMatch = content.match(/\[[\s\S]*\]/)
      if (jsonMatch) {
        recommendations = JSON.parse(jsonMatch[0])
      }
    } catch {
      recommendations = [
        {
          title: 'Continue Your Learning Journey',
          reason: 'Keep up the great work! Consistency is key to mastering new subjects.',
          action: 'Try completing the next lesson in your current course.',
        },
      ]
    }

    return NextResponse.json({ recommendations })
  } catch (error) {
    console.error('AI Recommendations error:', error)
    // Fallback to basic recommendations
    return NextResponse.json({
      recommendations: [
        {
          title: 'Keep Learning!',
          reason: 'Consistency leads to mastery. Try to complete at least one lesson every day.',
          action: 'Visit the Courses page to find your next lesson.',
        },
      ],
    })
  }
}
