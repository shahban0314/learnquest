import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import ZAI from 'z-ai-web-dev-sdk'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { userId, message, history = [] } = body

    if (!message) {
      return NextResponse.json({ error: 'Message is required' }, { status: 400 })
    }

    // Get user context for personalized responses
    let userContext = ''
    if (userId) {
      const user = await db.user.findUnique({
        where: { id: userId },
        include: {
          progress: {
            where: { completed: true },
            include: {
              lesson: {
                include: {
                  topic: {
                    include: { course: { select: { title: true, category: true } } },
                  },
                },
              },
            },
          },
          quizAttempts: {
            where: { completed: true },
            select: { score: true, totalPoints: true },
          },
        },
      })

      if (user) {
        const completedTopics = [...new Set(user.progress.map((p) => p.lesson.topic.name))]
        const avgScore = user.quizAttempts.length > 0
          ? Math.round(
              user.quizAttempts.reduce((sum, a) => sum + a.score, 0) /
              user.quizAttempts.reduce((sum, a) => sum + a.totalPoints, 0) * 100
            )
          : 0

        userContext = `User: ${user.name}, Level: ${user.level}, Points: ${user.points}, Streak: ${user.streak} days. Completed topics: ${completedTopics.join(', ') || 'none yet'}. Average quiz score: ${avgScore}%.`
      }
    }

    const zai = await ZAI.create()

    // Build messages array with history
    const messages = [
      {
        role: 'assistant',
        content: `You are LearnBot, a friendly and encouraging AI learning assistant for the LearnQuest platform. 
You help students with their studies by:
- Explaining concepts clearly with examples
- Providing study tips and strategies
- Motivating and encouraging learners
- Answering subject-related questions (Math, Science, Computer Science)
- Suggesting learning paths based on their progress

Keep responses concise but helpful (2-3 paragraphs max). Use emojis occasionally to be friendly. Be encouraging!

${userContext ? `Current user context: ${userContext}` : ''}`,
      },
      ...history.slice(-6), // Keep last 6 messages for context
      {
        role: 'user',
        content: message,
      },
    ]

    const completion = await zai.chat.completions.create({
      messages,
      thinking: { type: 'disabled' },
    })

    const response = completion.choices[0]?.message?.content || 'Sorry, I couldn\'t generate a response. Please try again!'

    return NextResponse.json({ response })
  } catch (error) {
    console.error('AI Chat error:', error)
    return NextResponse.json({
      response: 'I\'m having trouble connecting right now. Please try again in a moment! 🙏',
    })
  }
}
