import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')

    const course = await db.course.findUnique({
      where: { id },
      include: {
        topics: {
          include: {
            lessons: {
              orderBy: { order: 'asc' },
            },
          },
          orderBy: { order: 'asc' },
        },
        quizzes: {
          include: {
            _count: { select: { questions: true } },
          },
        },
      },
    })

    if (!course) {
      return NextResponse.json(
        { error: 'Course not found' },
        { status: 404 }
      )
    }

    let userProgress: Record<string, { completed: boolean; score: number | null; timeSpent: number }> = {}
    if (userId) {
      const allLessonIds = course.topics.flatMap((t) => t.lessons.map((l) => l.id))
      if (allLessonIds.length > 0) {
        const progress = await db.userProgress.findMany({
          where: {
            userId,
            lessonId: { in: allLessonIds },
          },
        })
        progress.forEach((p) => {
          userProgress[p.lessonId] = {
            completed: p.completed,
            score: p.score,
            timeSpent: p.timeSpent,
          }
        })
      }
    }

    const totalLessons = course.topics.reduce(
      (sum, topic) => sum + topic.lessons.length,
      0
    )
    const completedLessons = Object.values(userProgress).filter(
      (p) => p.completed
    ).length

    const topicsWithProgress = course.topics.map((topic) => ({
      ...topic,
      lessons: topic.lessons.map((lesson) => ({
        ...lesson,
        progress: userProgress[lesson.id] || null,
      })),
      completedLessons: topic.lessons.filter(
        (l) => userProgress[l.id]?.completed
      ).length,
    }))

    return NextResponse.json({
      course: {
        ...course,
        topics: topicsWithProgress,
        totalLessons,
        completedLessons,
        progressPercentage: totalLessons > 0 ? Math.round((completedLessons / totalLessons) * 100) : 0,
      },
    })
  } catch (error) {
    console.error('Course detail error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
