import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const category = searchParams.get('category')
    const difficulty = searchParams.get('difficulty')
    const search = searchParams.get('search')
    const userId = searchParams.get('userId')

    const where: Record<string, unknown> = {}

    if (category) {
      where.category = category
    }
    if (difficulty) {
      where.difficulty = difficulty
    }
    if (search) {
      where.OR = [
        { title: { contains: search } },
        { description: { contains: search } },
      ]
    }

    const courses = await db.course.findMany({
      where,
      include: {
        topics: {
          include: {
            lessons: {
              select: { id: true },
            },
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    })

    const coursesWithStats = await Promise.all(
      courses.map(async (course) => {
        const totalLessons = course.topics.reduce(
          (sum, topic) => sum + topic.lessons.length,
          0
        )

        let completedLessons = 0
        if (userId) {
          const lessonIds = course.topics.flatMap((t) => t.lessons.map((l) => l.id))
          if (lessonIds.length > 0) {
            const completed = await db.userProgress.count({
              where: {
                userId,
                lessonId: { in: lessonIds },
                completed: true,
              },
            })
            completedLessons = completed
          }
        }

        return {
          id: course.id,
          title: course.title,
          description: course.description,
          category: course.category,
          difficulty: course.difficulty,
          image: course.image,
          duration: course.duration,
          rating: course.rating,
          enrolledCount: course.enrolledCount,
          createdAt: course.createdAt,
          updatedAt: course.updatedAt,
          topicCount: course.topics.length,
          totalLessons,
          completedLessons,
          progressPercentage: totalLessons > 0 ? Math.round((completedLessons / totalLessons) * 100) : 0,
        }
      })
    )

    return NextResponse.json({ courses: coursesWithStats })
  } catch (error) {
    console.error('List courses error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
