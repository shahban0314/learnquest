import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')

    if (!userId) {
      return NextResponse.json(
        { error: 'userId is required' },
        { status: 400 }
      )
    }

    const user = await db.user.findUnique({
      where: { id: userId },
    })

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      )
    }

    // 1. Progress by category
    const progress = await db.userProgress.findMany({
      where: { userId },
      include: {
        lesson: {
          include: {
            topic: {
              include: {
                course: {
                  select: { category: true, title: true },
                },
              },
            },
          },
        },
      },
    })

    const categoryMap = new Map<string, { total: number; completed: number }>()
    for (const p of progress) {
      const cat = p.lesson.topic.course.category
      const existing = categoryMap.get(cat) || { total: 0, completed: 0 }
      existing.total += 1
      if (p.completed) existing.completed += 1
      categoryMap.set(cat, existing)
    }

    const progressByCategory = Array.from(categoryMap.entries()).map(
      ([category, data]) => ({
        category,
        total: data.total,
        completed: data.completed,
        percentage: data.total > 0 ? Math.round((data.completed / data.total) * 100) : 0,
      })
    )

    // 2. Quiz scores
    const quizAttempts = await db.quizAttempt.findMany({
      where: { userId, completed: true },
      orderBy: { completedAt: 'asc' },
      include: {
        quiz: { select: { title: true, difficulty: true } },
      },
    })

    const quizScores = quizAttempts.map((a) => ({
      quizTitle: a.quiz.title,
      difficulty: a.quiz.difficulty,
      score: a.score,
      totalPoints: a.totalPoints,
      percentage: a.totalPoints > 0 ? Math.round((a.score / a.totalPoints) * 100) : 0,
      completedAt: a.completedAt,
    }))

    // 3. Weekly activity (last 7 days)
    const weekAgo = new Date()
    weekAgo.setDate(weekAgo.getDate() - 7)

    const recentProgress = await db.userProgress.findMany({
      where: {
        userId,
        completedAt: { gte: weekAgo },
      },
      select: { completedAt: true, timeSpent: true },
    })

    const weeklyActivity: Record<string, { lessonsCompleted: number; timeSpent: number }> = {}
    for (let i = 6; i >= 0; i--) {
      const date = new Date()
      date.setDate(date.getDate() - i)
      const dateKey = date.toISOString().split('T')[0]
      weeklyActivity[dateKey] = { lessonsCompleted: 0, timeSpent: 0 }
    }

    for (const p of recentProgress) {
      if (p.completedAt) {
        const dateKey = p.completedAt.toISOString().split('T')[0]
        if (weeklyActivity[dateKey]) {
          weeklyActivity[dateKey].lessonsCompleted += 1
          weeklyActivity[dateKey].timeSpent += p.timeSpent
        }
      }
    }

    const weeklyActivityArray = Object.entries(weeklyActivity).map(
      ([date, data]) => ({ date, ...data })
    )

    // 4. Strong topics (>80% completion)
    const topicMap = new Map<string, { name: string; total: number; completed: number }>()
    for (const p of progress) {
      const topicName = p.lesson.topic.name
      const existing = topicMap.get(topicName) || { name: topicName, total: 0, completed: 0 }
      existing.total += 1
      if (p.completed) existing.completed += 1
      topicMap.set(topicName, existing)
    }

    const topicStats = Array.from(topicMap.values())
    const strongTopics = topicStats
      .filter((t) => t.total > 0 && (t.completed / t.total) >= 0.8)
      .map((t) => ({
        topic: t.name,
        total: t.total,
        completed: t.completed,
        percentage: Math.round((t.completed / t.total) * 100),
      }))

    const weakTopics = topicStats
      .filter((t) => t.total > 0 && (t.completed / t.total) < 0.5)
      .map((t) => ({
        topic: t.name,
        total: t.total,
        completed: t.completed,
        percentage: Math.round((t.completed / t.total) * 100),
      }))

    // 5. Learning time
    const totalTimeSpent = progress.reduce((sum, p) => sum + p.timeSpent, 0)
    const learningTime = {
      totalSeconds: totalTimeSpent,
      totalMinutes: Math.round(totalTimeSpent / 60),
      totalHours: Math.round((totalTimeSpent / 3600) * 10) / 10,
      averagePerLesson:
        progress.length > 0
          ? Math.round(totalTimeSpent / progress.filter((p) => p.completed).length)
          : 0,
    }

    return NextResponse.json({
      analytics: {
        progressByCategory,
        quizScores,
        weeklyActivity: weeklyActivityArray,
        strongTopics,
        weakTopics,
        learningTime,
      },
    })
  } catch (error) {
    console.error('Analytics error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
