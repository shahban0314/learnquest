import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')

    if (!userId) {
      return NextResponse.json(
        { error: 'userId is required' },
        { status: 400 }
      )
    }

    const bookmarks = await db.bookmark.findMany({
      where: { userId },
      include: {
        lesson: {
          include: {
            topic: {
              include: {
                course: {
                  select: { id: true, title: true, category: true },
                },
              },
            },
          },
        },
      },
      orderBy: { createdAt: 'desc' },
    })

    return NextResponse.json({ bookmarks })
  } catch (error) {
    console.error('Get bookmarks error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { userId, lessonId } = body

    if (!userId || !lessonId) {
      return NextResponse.json(
        { error: 'userId and lessonId are required' },
        { status: 400 }
      )
    }

    const lesson = await db.lesson.findUnique({
      where: { id: lessonId },
    })

    if (!lesson) {
      return NextResponse.json(
        { error: 'Lesson not found' },
        { status: 404 }
      )
    }

    const existingBookmark = await db.bookmark.findUnique({
      where: {
        userId_lessonId: { userId, lessonId },
      },
    })

    if (existingBookmark) {
      return NextResponse.json(
        { error: 'Lesson already bookmarked' },
        { status: 409 }
      )
    }

    const bookmark = await db.bookmark.create({
      data: { userId, lessonId },
      include: {
        lesson: {
          include: {
            topic: {
              include: {
                course: {
                  select: { id: true, title: true, category: true },
                },
              },
            },
          },
        },
      },
    })

    return NextResponse.json({ bookmark, message: 'Bookmark created' }, { status: 201 })
  } catch (error) {
    console.error('Create bookmark error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
