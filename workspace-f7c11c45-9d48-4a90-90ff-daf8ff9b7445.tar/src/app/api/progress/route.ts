import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')
    const courseId = searchParams.get('courseId')

    if (!userId) {
      return NextResponse.json(
        { error: 'userId is required' },
        { status: 400 }
      )
    }

    const user = await db.user.findUnique({
      where: { id: userId },
      select: { id: true, points: true, streak: true, level: true },
    })

    if (!user) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      )
    }

    // Get all progress for the user
    const progressWhere: Record<string, unknown> = { userId }
    if (courseId) {
      progressWhere.lesson = { topic: { courseId } }
    }

    const progress = await db.userProgress.findMany({
      where: progressWhere,
      include: {
        lesson: {
          include: {
            topic: {
              include: {
                course: {
                  select: { id: true, title: true, category: true },
                },
              },
            },
          },
        },
      },
    })

    const completedLessons = progress.filter((p) => p.completed)
    const totalLessons = progress.length
    const completionRate = totalLessons > 0 ? Math.round((completedLessons.length / totalLessons) * 100) : 0

    const totalTimeSpent = progress.reduce((sum, p) => sum + p.timeSpent, 0)

    // Get quiz attempts
    const quizAttempts = await db.quizAttempt.findMany({
      where: { userId, completed: true },
      orderBy: { completedAt: 'desc' },
    })

    const averageQuizScore =
      quizAttempts.length > 0
        ? Math.round(
            quizAttempts.reduce((sum, a) => sum + (a.totalPoints > 0 ? (a.score / a.totalPoints) * 100 : 0), 0) /
              quizAttempts.length
          )
        : 0

    // Get badge count
    const badgeCount = await db.userBadge.count({
      where: { userId },
    })

    // Course-specific progress
    let courseProgress = null
    if (courseId) {
      const course = await db.course.findUnique({
        where: { id: courseId },
        include: {
          topics: {
            include: {
              lessons: { select: { id: true } },
            },
          },
        },
      })

      if (course) {
        const courseLessonIds = course.topics.flatMap((t) => t.lessons.map((l) => l.id))
        const courseCompleted = await db.userProgress.count({
          where: {
            userId,
            lessonId: { in: courseLessonIds },
            completed: true,
          },
        })
        courseProgress = {
          courseId: course.id,
          courseTitle: course.title,
          totalLessons: courseLessonIds.length,
          completedLessons: courseCompleted,
          progressPercentage: courseLessonIds.length > 0 ? Math.round((courseCompleted / courseLessonIds.length) * 100) : 0,
        }
      }
    }

    return NextResponse.json({
      progress: {
        userId: user.id,
        points: user.points,
        streak: user.streak,
        level: user.level,
        totalLessons,
        completedLessons: completedLessons.length,
        completionRate,
        totalTimeSpent,
        totalQuizAttempts: quizAttempts.length,
        averageQuizScore,
        totalBadges: badgeCount,
        courseProgress,
      },
    })
  } catch (error) {
    console.error('Progress error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
