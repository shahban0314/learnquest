import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const userId = searchParams.get('userId')

    const challenges = await db.challenge.findMany({
      where: { active: true },
      orderBy: { createdAt: 'desc' },
    })

    if (userId) {
      const userChallenges = await db.userChallenge.findMany({
        where: { userId },
      })

      const userChallengeMap = new Map(
        userChallenges.map((uc) => [uc.challengeId, uc])
      )

      const challengesWithProgress = challenges.map((challenge) => {
        const userChallenge = userChallengeMap.get(challenge.id)
        return {
          ...challenge,
          userProgress: userChallenge?.progress ?? 0,
          completed: userChallenge?.completed ?? false,
          startedAt: userChallenge?.startedAt ?? null,
          completedAt: userChallenge?.completedAt ?? null,
          progressPercentage:
            challenge.target > 0
              ? Math.min(
                  100,
                  Math.round(((userChallenge?.progress ?? 0) / challenge.target) * 100)
                )
              : 0,
        }
      })

      return NextResponse.json({ challenges: challengesWithProgress })
    }

    return NextResponse.json({
      challenges: challenges.map((c) => ({
        ...c,
        userProgress: 0,
        completed: false,
        startedAt: null,
        completedAt: null,
        progressPercentage: 0,
      })),
    })
  } catch (error) {
    console.error('Challenges error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
