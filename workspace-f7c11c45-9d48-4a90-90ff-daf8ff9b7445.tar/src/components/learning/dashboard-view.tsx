'use client'

import { useEffect } from 'react'
import { motion } from 'framer-motion'
import {
  Coins,
  Star,
  BookCheck,
  Target,
  Flame,
  ArrowRight,
  Sparkles,
  Trophy,
  BookOpen,
  Zap,
} from 'lucide-react'
import { useLearningStore } from '@/store/learning-store'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { cn } from '@/lib/utils'

const motivationalQuotes = [
  "The expert in anything was once a beginner. Keep going! 🚀",
  "Learning is a treasure that will follow its owner everywhere. ✨",
  "The beautiful thing about learning is that no one can take it away from you. 💎",
  "Success is the sum of small efforts, repeated day in and day out. 🌟",
  "Every accomplishment starts with the decision to try. 💪",
]

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.08 },
  },
}

const itemVariants = {
  hidden: { opacity: 0, y: 16 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.4 } },
}

export default function DashboardView() {
  const {
    user,
    courses,
    recommendations,
    aiRecommendations,
    challenges,
    badges,
    fetchCourses,
    fetchRecommendations,
    fetchAIRecommendations,
    fetchChallenges,
    fetchBadges,
    selectCourse,
    loading,
  } = useLearningStore()

  useEffect(() => {
    fetchCourses()
    fetchRecommendations()
    fetchAIRecommendations()
    fetchChallenges()
    fetchBadges()
  }, [fetchCourses, fetchRecommendations, fetchAIRecommendations, fetchChallenges, fetchBadges])

  if (!user) return null

  const quote = motivationalQuotes[Math.floor(Math.random() * motivationalQuotes.length)]
  const activeChallenges = challenges.filter((c) => c.active && !c.completed)
  const recentBadges = badges
    .filter((b) => b.earned)
    .sort((a, b) => {
      if (!a.earnedAt) return 1
      if (!b.earnedAt) return -1
      return new Date(b.earnedAt!).getTime() - new Date(a.earnedAt!).getTime()
    })
    .slice(0, 4)

  const inProgressCourses = courses.filter((c) => c.progress !== undefined && c.progress > 0 && c.progress < 100)
  const completedLessons = user.stats?.totalLessonsCompleted || 0

  // Compute quiz average from available data
  const quizAverage = user.stats?.averageQuizScore || 0

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-6 p-4 md:p-6 max-w-7xl mx-auto"
    >
      {/* Welcome Section */}
      <motion.div variants={itemVariants}>
        <Card className="bg-gradient-to-br from-emerald-500/10 via-card to-amber-500/5 border-emerald-500/20">
          <CardContent className="p-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
              <div>
                <h1 className="text-2xl md:text-3xl font-bold tracking-tight">
                  Welcome back, {user.name}! 👋
                </h1>
                <p className="text-muted-foreground mt-1.5 text-sm md:text-base">
                  {quote}
                </p>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <Badge
                  variant="secondary"
                  className="gap-1.5 px-3 py-1.5 text-sm bg-amber-500/10 text-amber-700 dark:text-amber-400 border-amber-500/20"
                >
                  <Flame className="w-4 h-4" />
                  {user.streak} Day Streak
                </Badge>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Stats Cards */}
      <motion.div variants={itemVariants}>
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4">
          <StatsCard
            icon={Coins}
            label="Total Points"
            value={user.points.toLocaleString()}
            color="amber"
          />
          <StatsCard
            icon={Star}
            label="Current Level"
            value={user.level.toString()}
            color="emerald"
          />
          <StatsCard
            icon={BookCheck}
            label="Lessons Done"
            value={completedLessons.toString()}
            color="slate"
          />
          <StatsCard
            icon={Target}
            label="Quiz Average"
            value={`${quizAverage}%`}
            color="rose"
          />
        </div>
      </motion.div>

      {/* Continue Learning */}
      <motion.div variants={itemVariants}>
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-emerald-500" />
                Continue Learning
              </CardTitle>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => useLearningStore.getState().setView('courses')}
                className="text-muted-foreground"
              >
                View All
                <ArrowRight className="w-3.5 h-3.5 ml-1" />
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {inProgressCourses.length > 0 ? (
              <div className="space-y-3">
                {inProgressCourses.slice(0, 3).map((course) => (
                  <div
                    key={course.id}
                    className="flex items-center gap-4 p-3 rounded-xl bg-muted/50 hover:bg-muted transition-colors cursor-pointer"
                    onClick={() => selectCourse(course.id)}
                  >
                    <div className="w-10 h-10 rounded-lg bg-emerald-500/10 flex items-center justify-center shrink-0">
                      <BookOpen className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm truncate">{course.title}</p>
                      <div className="flex items-center gap-2 mt-1.5">
                        <Progress value={course.progress || 0} className="h-1.5 flex-1" />
                        <span className="text-xs text-muted-foreground shrink-0">
                          {course.progress}%
                        </span>
                      </div>
                    </div>
                    <Button size="sm" className="shrink-0 bg-emerald-600 hover:bg-emerald-700">
                      Continue
                    </Button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <BookOpen className="w-10 h-10 mx-auto mb-3 opacity-40" />
                <p className="text-sm">No courses in progress yet.</p>
                <Button
                  variant="outline"
                  size="sm"
                  className="mt-3"
                  onClick={() => useLearningStore.getState().setView('courses')}
                >
                  Browse Courses
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* AI Recommendations & Challenges Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
        {/* AI-Powered Recommendations */}
        {aiRecommendations.length > 0 && (
          <motion.div variants={itemVariants}>
            <Card className="h-full border-amber-500/20">
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center gap-2">
                  <Sparkles className="w-5 h-5 text-amber-500" />
                  AI Study Advisor
                </CardTitle>
                <CardDescription>Personalized suggestions powered by AI</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
                  {aiRecommendations.map((rec, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.05 }}
                      className="p-3 rounded-lg bg-gradient-to-r from-amber-500/5 to-emerald-500/5 border border-amber-500/10"
                    >
                      <p className="font-medium text-sm flex items-center gap-1.5">
                        <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                        {rec.title}
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">{rec.reason}</p>
                      <p className="text-xs text-emerald-600 dark:text-emerald-400 mt-1.5 font-medium">
                        → {rec.action}
                      </p>
                    </motion.div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {/* Personalized Recommendations */}
        <motion.div variants={itemVariants}>
          <Card className="h-full">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Zap className="w-5 h-5 text-amber-500" />
                Recommended For You
              </CardTitle>
              <CardDescription>Based on your learning patterns</CardDescription>
            </CardHeader>
            <CardContent>
              {recommendations.length > 0 ? (
                <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
                  {recommendations.slice(0, 5).map((rec, i) => (
                    <motion.div
                      key={rec.id}
                      initial={{ opacity: 0, x: -10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.05 }}
                      className="flex items-start gap-3 p-3 rounded-lg hover:bg-muted/50 transition-colors"
                    >
                      <div className="w-8 h-8 rounded-lg bg-amber-500/10 flex items-center justify-center shrink-0 mt-0.5">
                        <Zap className="w-4 h-4 text-amber-600 dark:text-amber-400" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm">
                          {rec.course?.title || rec.lesson?.title || 'New Topic'}
                        </p>
                        <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">
                          {rec.reason}
                        </p>
                      </div>
                      {rec.course && (
                        <Button
                          variant="ghost"
                          size="sm"
                          className="shrink-0 text-emerald-600 dark:text-emerald-400"
                          onClick={() => selectCourse(rec.courseId!)}
                        >
                          <ArrowRight className="w-4 h-4" />
                        </Button>
                      )}
                    </motion.div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <Sparkles className="w-10 h-10 mx-auto mb-3 opacity-40" />
                  <p className="text-sm">Recommendations will appear as you learn more.</p>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Challenges & Badges Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
        {/* Active Challenges */}
        <motion.div variants={itemVariants}>
          <Card className="h-full">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg flex items-center gap-2">
                <Trophy className="w-5 h-5 text-amber-500" />
                Active Challenges
              </CardTitle>
              <CardDescription>Complete challenges to earn bonus points</CardDescription>
            </CardHeader>
            <CardContent>
              {activeChallenges.length > 0 ? (
                <div className="space-y-3 max-h-80 overflow-y-auto pr-1">
                  {activeChallenges.slice(0, 4).map((challenge, i) => (
                    <motion.div
                      key={challenge.id}
                      initial={{ opacity: 0, x: 10 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: i * 0.05 }}
                      className="p-3 rounded-lg bg-muted/50"
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="text-lg">{challenge.icon || '🎯'}</span>
                          <div>
                            <p className="font-medium text-sm">{challenge.title}</p>
                            <p className="text-xs text-muted-foreground">
                              +{challenge.points} pts
                            </p>
                          </div>
                        </div>
                        <Badge variant="outline" className="text-[10px]">
                          {challenge.duration}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-2 mt-2">
                        <Progress
                          value={Math.min((challenge.progress || 0) / challenge.target * 100, 100)}
                          className="h-1.5 flex-1"
                        />
                        <span className="text-xs text-muted-foreground shrink-0">
                          {challenge.progress || 0}/{challenge.target}
                        </span>
                      </div>
                    </motion.div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <Trophy className="w-10 h-10 mx-auto mb-3 opacity-40" />
                  <p className="text-sm">No active challenges right now.</p>
                  <p className="text-xs mt-1">New challenges appear as you learn!</p>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>
      </div>

      {/* Recent Badges */}
      <motion.div variants={itemVariants}>
        <Card>
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg flex items-center gap-2">
                <Trophy className="w-5 h-5 text-amber-500" />
                Recent Badges
              </CardTitle>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => useLearningStore.getState().setView('gamification')}
                className="text-muted-foreground"
              >
                View All
                <ArrowRight className="w-3.5 h-3.5 ml-1" />
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {recentBadges.length > 0 ? (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {recentBadges.map((badge) => (
                  <motion.div
                    key={badge.id}
                    whileHover={{ scale: 1.03 }}
                    className="flex flex-col items-center p-4 rounded-xl bg-muted/50 text-center hover:bg-muted transition-colors"
                  >
                    <span className="text-3xl mb-2">{badge.icon || '🏅'}</span>
                    <p className="font-medium text-xs">{badge.name}</p>
                    <p className="text-[10px] text-muted-foreground mt-0.5">
                      +{badge.points} pts
                    </p>
                  </motion.div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <Trophy className="w-10 h-10 mx-auto mb-3 opacity-40" />
                <p className="text-sm">No badges earned yet.</p>
                <p className="text-xs mt-1">Complete lessons and quizzes to earn your first badge!</p>
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>

      {/* Loading Overlay */}
      {loading && (
        <div className="fixed inset-0 bg-background/50 backdrop-blur-sm z-30 flex items-center justify-center pointer-events-none">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ repeat: Infinity, duration: 1, ease: 'linear' }}
            className="w-8 h-8 border-2 border-emerald-500 border-t-transparent rounded-full"
          />
        </div>
      )}
    </motion.div>
  )
}

/* ───── Stats Card Sub-component ───── */

function StatsCard({
  icon: Icon,
  label,
  value,
  color,
}: {
  icon: React.ElementType
  label: string
  value: string
  color: 'amber' | 'emerald' | 'slate' | 'rose'
}) {
  const colorMap = {
    amber: {
      bg: 'bg-amber-500/10',
      icon: 'text-amber-600 dark:text-amber-400',
      border: 'border-amber-500/20',
    },
    emerald: {
      bg: 'bg-emerald-500/10',
      icon: 'text-emerald-600 dark:text-emerald-400',
      border: 'border-emerald-500/20',
    },
    slate: {
      bg: 'bg-slate-500/10',
      icon: 'text-slate-600 dark:text-slate-400',
      border: 'border-slate-500/20',
    },
    rose: {
      bg: 'bg-rose-500/10',
      icon: 'text-rose-600 dark:text-rose-400',
      border: 'border-rose-500/20',
    },
  }

  const c = colorMap[color]

  return (
    <motion.div whileHover={{ y: -2 }} transition={{ duration: 0.2 }}>
      <Card className={cn('overflow-hidden border', c.border)}>
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            <div className={cn('w-10 h-10 rounded-lg flex items-center justify-center', c.bg)}>
              <Icon className={cn('w-5 h-5', c.icon)} />
            </div>
            <div>
              <p className="text-2xl font-bold tracking-tight">{value}</p>
              <p className="text-xs text-muted-foreground">{label}</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  )
}


