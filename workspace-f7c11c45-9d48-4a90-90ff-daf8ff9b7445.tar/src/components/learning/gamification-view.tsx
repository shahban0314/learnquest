'use client'

import { useEffect, useMemo } from 'react'
import { useLearningStore } from '@/store/learning-store'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Separator } from '@/components/ui/separator'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Award,
  Lock,
  CheckCircle2,
  Flame,
  Zap,
  Target,
  Star,
  TrendingUp,
  Calendar,
  BookOpen,
  Brain,
  Trophy,
} from 'lucide-react'
import { motion } from 'framer-motion'

const badgeCategoryColors: Record<string, string> = {
  learning: 'from-emerald-500 to-teal-500',
  social: 'from-amber-500 to-orange-500',
  achievement: 'from-violet-500 to-purple-500',
  streak: 'from-rose-500 to-pink-500',
  mastery: 'from-teal-500 to-cyan-500',
}

const challengeDurationConfig: Record<string, { color: string; label: string }> = {
  daily: { color: 'bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-300', label: 'Daily' },
  weekly: { color: 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300', label: 'Weekly' },
  monthly: { color: 'bg-violet-100 text-violet-700 dark:bg-violet-900/40 dark:text-violet-300', label: 'Monthly' },
}

export default function GamificationView() {
  const { user, badges, challenges, fetchBadges, fetchChallenges } = useLearningStore()

  useEffect(() => {
    fetchBadges()
    fetchChallenges()
  }, [fetchBadges, fetchChallenges])

  const earnedBadges = useMemo(() => badges.filter((b) => b.earned), [badges])
  const lockedBadges = useMemo(() => badges.filter((b) => !b.earned), [badges])

  const activeChallenges = useMemo(() => challenges.filter((c) => c.active && !c.completed), [challenges])
  const completedChallenges = useMemo(() => challenges.filter((c) => c.completed), [challenges])

  const currentLevel = user?.level ?? 1
  const currentPoints = user?.points ?? 0
  // Simple level formula: each level requires more points
  const pointsForCurrentLevel = (currentLevel - 1) * 500
  const pointsForNextLevel = currentLevel * 500
  const levelProgress = ((currentPoints - pointsForCurrentLevel) / (pointsForNextLevel - pointsForCurrentLevel)) * 100

  // Simulated points breakdown
  const pointsBreakdown = useMemo(() => {
    const lessonPoints = Math.min(currentPoints * 0.4, currentPoints)
    const quizPoints = Math.min(currentPoints * 0.3, currentPoints - lessonPoints)
    const streakPoints = Math.min(currentPoints * 0.15, currentPoints - lessonPoints - quizPoints)
    const loginPoints = currentPoints - lessonPoints - quizPoints - streakPoints
    return [
      { label: 'Lessons Completed', points: Math.round(lessonPoints), icon: <BookOpen className="size-4" />, color: 'text-emerald-500' },
      { label: 'Quiz Scores', points: Math.round(quizPoints), icon: <Brain className="size-4" />, color: 'text-amber-500' },
      { label: 'Login Streaks', points: Math.round(streakPoints), icon: <Flame className="size-4" />, color: 'text-rose-500' },
      { label: 'Daily Logins', points: Math.round(loginPoints), icon: <Calendar className="size-4" />, color: 'text-teal-500' },
    ]
  }, [currentPoints])

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight sm:text-3xl flex items-center gap-2">
          <Trophy className="size-7 text-amber-500" />
          Gamification Hub
        </h1>
        <p className="text-muted-foreground mt-1">Track your achievements, challenges, and rewards</p>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {[
          { label: 'Total Points', value: currentPoints.toLocaleString(), icon: <Zap className="size-4" />, color: 'text-amber-500' },
          { label: 'Level', value: currentLevel, icon: <TrendingUp className="size-4" />, color: 'text-emerald-500' },
          { label: 'Badges Earned', value: earnedBadges.length, icon: <Award className="size-4" />, color: 'text-violet-500' },
          { label: 'Streak', value: `${user?.streak ?? 0} days`, icon: <Flame className="size-4" />, color: 'text-rose-500' },
        ].map((stat) => (
          <Card key={stat.label}>
            <CardContent className="p-4">
              <div className="flex items-center gap-2 mb-1">
                <span className={stat.color}>{stat.icon}</span>
                <span className="text-xs text-muted-foreground">{stat.label}</span>
              </div>
              <p className="text-xl font-bold">{stat.value}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Tabs */}
      <Tabs defaultValue="badges">
        <TabsList className="w-full sm:w-auto">
          <TabsTrigger value="badges" className="gap-1.5">
            <Award className="size-4" />
            Badges
          </TabsTrigger>
          <TabsTrigger value="challenges" className="gap-1.5">
            <Target className="size-4" />
            Challenges
          </TabsTrigger>
          <TabsTrigger value="points" className="gap-1.5">
            <Star className="size-4" />
            Points
          </TabsTrigger>
        </TabsList>

        {/* Badges Tab */}
        <TabsContent value="badges">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-semibold">Your Badges</h2>
              <Badge variant="secondary" className="gap-1">
                <Award className="size-3" />
                {earnedBadges.length}/{badges.length} earned
              </Badge>
            </div>

            {badges.length === 0 ? (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <Award className="size-12 text-muted-foreground mb-3" />
                <p className="text-muted-foreground">No badges available yet. Start learning to earn badges!</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
                {badges.map((badge, index) => {
                  const isEarned = badge.earned
                  const gradientClass = badgeCategoryColors[badge.category.toLowerCase()] || 'from-slate-500 to-gray-500'

                  return (
                    <motion.div
                      key={badge.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.03 }}
                    >
                      <Card className={`relative overflow-hidden transition-all duration-300 ${isEarned ? 'hover:shadow-lg hover:-translate-y-0.5' : 'opacity-60'}`}>
                        <CardContent className="p-4 flex flex-col items-center text-center">
                          {/* Badge Icon */}
                          <div className={`relative mb-3`}>
                            <div className={`size-16 rounded-full flex items-center justify-center text-3xl ${
                              isEarned
                                ? `bg-gradient-to-br ${gradientClass} text-white shadow-lg`
                                : 'bg-muted text-muted-foreground'
                            }`}>
                              {badge.icon || '🏅'}
                            </div>
                            {!isEarned && (
                              <div className="absolute inset-0 flex items-center justify-center rounded-full bg-background/50">
                                <Lock className="size-5 text-muted-foreground" />
                              </div>
                            )}
                          </div>

                          <h3 className={`font-semibold text-sm mb-1 ${isEarned ? '' : 'text-muted-foreground'}`}>
                            {badge.name}
                          </h3>
                          <p className="text-xs text-muted-foreground line-clamp-2 mb-2">
                            {badge.description}
                          </p>

                          {isEarned && badge.earnedAt && (
                            <Badge variant="secondary" className="bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300 text-[10px]">
                              <CheckCircle2 className="size-2.5 mr-0.5" />
                              Earned
                            </Badge>
                          )}

                          {!isEarned && badge.points > 0 && (
                            <span className="text-[10px] text-muted-foreground">
                              +{badge.points} pts
                            </span>
                          )}
                        </CardContent>
                      </Card>
                    </motion.div>
                  )
                })}
              </div>
            )}
          </div>
        </TabsContent>

        {/* Challenges Tab */}
        <TabsContent value="challenges">
          <div className="space-y-6">
            {/* Active Challenges */}
            <div className="space-y-3">
              <h2 className="text-lg font-semibold flex items-center gap-2">
                <Zap className="size-5 text-amber-500" />
                Active Challenges
              </h2>

              {activeChallenges.length === 0 ? (
                <Card>
                  <CardContent className="p-6 text-center">
                    <Target className="size-10 text-muted-foreground mx-auto mb-2" />
                    <p className="text-muted-foreground text-sm">No active challenges right now. Check back later!</p>
                  </CardContent>
                </Card>
              ) : (
                <div className="space-y-3">
                  {activeChallenges.map((challenge, index) => {
                    const progress = challenge.progress ?? 0
                    const progressPercent = Math.min((progress / challenge.target) * 100, 100)
                    const durConfig = challengeDurationConfig[challenge.duration.toLowerCase()] || challengeDurationConfig.daily

                    return (
                      <motion.div
                        key={challenge.id}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: index * 0.05 }}
                      >
                        <Card className="hover:shadow-md transition-shadow">
                          <CardContent className="p-4">
                            <div className="flex items-start gap-3">
                              <div className="size-10 rounded-lg bg-amber-100 dark:bg-amber-900/30 flex items-center justify-center text-xl shrink-0">
                                {challenge.icon || '🎯'}
                              </div>
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2 mb-1">
                                  <h3 className="font-semibold text-sm">{challenge.title}</h3>
                                  <Badge variant="secondary" className={durConfig.color}>
                                    {durConfig.label}
                                  </Badge>
                                </div>
                                <p className="text-xs text-muted-foreground mb-2">{challenge.description}</p>
                                <div className="space-y-1.5">
                                  <div className="flex items-center justify-between text-xs">
                                    <span className="text-muted-foreground">
                                      {progress}/{challenge.target}
                                    </span>
                                    <span className="font-medium text-amber-600 dark:text-amber-400">
                                      +{challenge.points} pts
                                    </span>
                                  </div>
                                  <Progress value={progressPercent} className="h-2" />
                                </div>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      </motion.div>
                    )
                  })}
                </div>
              )}
            </div>

            {/* Completed Challenges */}
            {completedChallenges.length > 0 && (
              <div className="space-y-3">
                <h2 className="text-lg font-semibold flex items-center gap-2">
                  <CheckCircle2 className="size-5 text-emerald-500" />
                  Completed Challenges
                </h2>
                <div className="space-y-2">
                  {completedChallenges.map((challenge) => (
                    <Card key={challenge.id} className="opacity-70">
                      <CardContent className="p-3">
                        <div className="flex items-center gap-3">
                          <div className="size-8 rounded-lg bg-emerald-100 dark:bg-emerald-900/30 flex items-center justify-center text-lg shrink-0">
                            {challenge.icon || '✅'}
                          </div>
                          <div className="flex-1 min-w-0">
                            <h4 className="font-medium text-sm line-clamp-1">{challenge.title}</h4>
                            <p className="text-xs text-muted-foreground">
                              +{challenge.points} pts earned
                              {challenge.completedAt && ` · ${new Date(challenge.completedAt).toLocaleDateString()}`}
                            </p>
                          </div>
                          <CheckCircle2 className="size-5 text-emerald-500 shrink-0" />
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            )}
          </div>
        </TabsContent>

        {/* Points Tab */}
        <TabsContent value="points">
          <div className="space-y-6">
            {/* Current Points */}
            <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}>
              <Card className="bg-gradient-to-br from-amber-50 to-amber-100 dark:from-amber-900/20 dark:to-amber-800/20 border-amber-200 dark:border-amber-800">
                <CardContent className="p-6 text-center">
                  <Zap className="size-10 text-amber-500 mx-auto mb-2" />
                  <p className="text-4xl font-bold text-amber-600 dark:text-amber-400">
                    {currentPoints.toLocaleString()}
                  </p>
                  <p className="text-sm text-muted-foreground mt-1">Total Points</p>
                </CardContent>
              </Card>
            </motion.div>

            {/* Level Progress */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base flex items-center gap-2">
                  <TrendingUp className="size-4 text-emerald-500" />
                  Level Progress
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Level {currentLevel}</span>
                  <span className="text-sm text-muted-foreground">Level {currentLevel + 1}</span>
                </div>
                <Progress value={Math.max(0, Math.min(100, levelProgress))} className="h-3" />
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>{currentPoints.toLocaleString()} pts</span>
                  <span>{pointsForNextLevel.toLocaleString()} pts needed</span>
                </div>
              </CardContent>
            </Card>

            {/* Points Breakdown */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Points Breakdown</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {pointsBreakdown.map((item) => (
                  <div key={item.label} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className={item.color}>{item.icon}</span>
                      <span className="text-sm">{item.label}</span>
                    </div>
                    <span className="text-sm font-semibold">{item.points.toLocaleString()} pts</span>
                  </div>
                ))}
                <Separator />
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Total</span>
                  <span className="text-sm font-bold text-amber-600 dark:text-amber-400">
                    {currentPoints.toLocaleString()} pts
                  </span>
                </div>
              </CardContent>
            </Card>

            {/* Recent Points History */}
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-base">Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {[
                    { action: 'Completed a lesson', points: 25, time: '2 hours ago' },
                    { action: 'Quiz score: 90%', points: 45, time: '5 hours ago' },
                    { action: 'Daily login bonus', points: 10, time: '1 day ago' },
                    { action: '3-day streak bonus', points: 30, time: '1 day ago' },
                    { action: 'Completed a lesson', points: 25, time: '2 days ago' },
                  ].map((item, i) => (
                    <div key={i} className="flex items-center justify-between text-sm">
                      <div>
                        <p className="font-medium">{item.action}</p>
                        <p className="text-xs text-muted-foreground">{item.time}</p>
                      </div>
                      <span className="font-semibold text-emerald-600 dark:text-emerald-400">
                        +{item.points}
                      </span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
