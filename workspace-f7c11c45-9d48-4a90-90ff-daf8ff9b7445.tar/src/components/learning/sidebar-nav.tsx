'use client'

import { motion, AnimatePresence } from 'framer-motion'
import {
  Brain,
  LayoutDashboard,
  BookOpen,
  FileQuestion,
  Trophy,
  Medal,
  BarChart3,
  User,
  LogOut,
  X,
  Flame,
  Star,
} from 'lucide-react'
import { useLearningStore, type ViewType } from '@/store/learning-store'
import { Button } from '@/components/ui/button'
import { Separator } from '@/components/ui/separator'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'
import { ScrollArea } from '@/components/ui/scroll-area'
import { cn } from '@/lib/utils'

const navItems: { icon: React.ElementType; label: string; view: ViewType }[] = [
  { icon: LayoutDashboard, label: 'Dashboard', view: 'dashboard' },
  { icon: BookOpen, label: 'Courses', view: 'courses' },
  { icon: FileQuestion, label: 'Quizzes', view: 'quizzes' },
  { icon: Trophy, label: 'Badges & Challenges', view: 'gamification' },
  { icon: Medal, label: 'Leaderboard', view: 'leaderboard' },
  { icon: BarChart3, label: 'Analytics', view: 'analytics' },
  { icon: User, label: 'Profile', view: 'profile' },
]

export default function SidebarNav() {
  const {
    user,
    currentView,
    setView,
    logout,
    sidebarOpen,
    setSidebarOpen,
  } = useLearningStore()

  if (!user) return null

  const avatarEmoji = user.avatar || '🎓'

  return (
    <>
      {/* Mobile overlay */}
      <AnimatePresence>
        {sidebarOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/40 backdrop-blur-sm z-40 lg:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}
      </AnimatePresence>

      {/* Sidebar - always visible on desktop, toggleable on mobile */}
      <aside
        className={cn(
          'fixed top-0 left-0 h-full w-72 bg-card border-r border-border z-50 flex flex-col transition-transform duration-300',
          'lg:relative lg:translate-x-0 lg:z-auto',
          sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        )}
      >
        {/* Header */}
        <div className="flex items-center justify-between p-4 pb-2">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-500 to-emerald-600 flex items-center justify-center shadow-md shadow-emerald-500/20">
              <Brain className="w-5 h-5 text-white" />
            </div>
            <span className="font-bold text-lg tracking-tight">LearnQuest</span>
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 lg:hidden"
            onClick={() => setSidebarOpen(false)}
          >
            <X className="w-4 h-4" />
          </Button>
        </div>

        {/* User Info */}
        <div className="px-4 py-3">
          <div className="flex items-center gap-3 p-3 rounded-xl bg-muted/50">
            <Avatar className="h-11 w-11 border-2 border-emerald-500/30">
              <AvatarFallback className="bg-emerald-500/10 text-lg">
                {avatarEmoji}
              </AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-sm truncate">{user.name}</p>
              <div className="flex items-center gap-2 mt-0.5">
                <Badge variant="secondary" className="text-[10px] px-1.5 py-0 h-5 gap-0.5">
                  <Star className="w-2.5 h-2.5 text-emerald-500" />
                  Lvl {user.level}
                </Badge>
                <Badge variant="secondary" className="text-[10px] px-1.5 py-0 h-5 gap-0.5">
                  <Flame className="w-2.5 h-2.5 text-amber-500" />
                  {user.streak}
                </Badge>
              </div>
            </div>
          </div>
        </div>

        <Separator className="mx-4 w-auto" />

        {/* Navigation */}
        <ScrollArea className="flex-1 px-3 py-3">
          <nav className="space-y-1">
            {navItems.map((item) => {
              const isActive = currentView === item.view
              const Icon = item.icon
              return (
                <motion.button
                  key={item.view}
                  whileHover={{ x: 2 }}
                  whileTap={{ scale: 0.98 }}
                  onClick={() => {
                    setView(item.view)
                    setSidebarOpen(false)
                  }}
                  className={cn(
                    'w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors duration-150',
                    isActive
                      ? 'bg-emerald-500/10 text-emerald-700 dark:text-emerald-400'
                      : 'text-muted-foreground hover:bg-muted hover:text-foreground'
                  )}
                >
                  <Icon
                    className={cn(
                      'w-4.5 h-4.5',
                      isActive ? 'text-emerald-600 dark:text-emerald-400' : ''
                    )}
                  />
                  <span>{item.label}</span>
                  {isActive && (
                    <motion.div
                      layoutId="activeIndicator"
                      className="ml-auto w-1.5 h-1.5 rounded-full bg-emerald-500"
                    />
                  )}
                </motion.button>
              )
            })}
          </nav>
        </ScrollArea>

        {/* Footer */}
        <div className="p-3 mt-auto">
          <Separator className="mb-3" />
          <motion.button
            whileHover={{ x: 2 }}
            whileTap={{ scale: 0.98 }}
            onClick={logout}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium text-muted-foreground hover:bg-rose-500/10 hover:text-rose-600 dark:hover:text-rose-400 transition-colors duration-150"
          >
            <LogOut className="w-4.5 h-4.5" />
            <span>Logout</span>
          </motion.button>
        </div>
      </aside>
    </>
  )
}
