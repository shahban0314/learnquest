'use client'

import { useEffect } from 'react'
import { motion } from 'framer-motion'
import {
  BarChart3,
  TrendingUp,
  TrendingDown,
  Clock,
  Brain,
  BookOpen,
  FileQuestion,
  Activity,
} from 'lucide-react'
import { useLearningStore } from '@/store/learning-store'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
  ResponsiveContainer,
} from 'recharts'

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 },
  },
}

const itemVariants = {
  hidden: { opacity: 0, y: 16 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.4 } },
}

// Theme colors for charts
const CHART_COLORS = {
  emerald: '#10b981',
  amber: '#f59e0b',
  rose: '#f43f5e',
  slate: '#64748b',
  teal: '#14b8a6',
}

export default function AnalyticsView() {
  const { analytics, fetchAnalytics, loading } = useLearningStore()

  useEffect(() => {
    fetchAnalytics()
  }, [fetchAnalytics])

  const hasData = analytics && (
    (analytics.quizScores?.length > 0) ||
    (analytics.weeklyActivity?.length > 0) ||
    (analytics.progressByCategory?.length > 0) ||
    (analytics.learningTime?.length > 0)
  )

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-6 p-4 md:p-6 max-w-7xl mx-auto"
    >
      {/* Header */}
      <motion.div variants={itemVariants}>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/10 flex items-center justify-center">
            <BarChart3 className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
          </div>
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Analytics</h1>
            <p className="text-sm text-muted-foreground">Track your learning progress and performance</p>
          </div>
        </div>
      </motion.div>

      {!hasData && !loading ? (
        <motion.div variants={itemVariants}>
          <Card>
            <CardContent className="py-16 text-center text-muted-foreground">
              <Activity className="w-12 h-12 mx-auto mb-4 opacity-30" />
              <p className="text-lg font-medium">No analytics data yet</p>
              <p className="text-sm mt-1">Start completing lessons and quizzes to see your learning insights!</p>
            </CardContent>
          </Card>
        </motion.div>
      ) : (
        <>
          {/* Top Row: Performance + Learning Activity */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
            {/* Performance Overview - Area Chart */}
            <motion.div variants={itemVariants}>
              <Card className="h-full">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <TrendingUp className="w-5 h-5 text-emerald-500" />
                    Performance Overview
                  </CardTitle>
                  <CardDescription>Quiz scores over time</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-64 md:h-72">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={analytics?.quizScores || []}>
                        <defs>
                          <linearGradient id="scoreGradient" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor={CHART_COLORS.emerald} stopOpacity={0.3} />
                            <stop offset="95%" stopColor={CHART_COLORS.emerald} stopOpacity={0} />
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" className="stroke-muted/30" />
                        <XAxis
                          dataKey="date"
                          tick={{ fontSize: 11 }}
                          tickFormatter={(v) => {
                            const d = new Date(v)
                            return `${d.getMonth() + 1}/${d.getDate()}`
                          }}
                          className="text-muted-foreground"
                        />
                        <YAxis
                          domain={[0, 100]}
                          tick={{ fontSize: 11 }}
                          className="text-muted-foreground"
                        />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: 'hsl(var(--card))',
                            border: '1px solid hsl(var(--border))',
                            borderRadius: '8px',
                            fontSize: '12px',
                          }}
                          labelFormatter={(v) => {
                            const d = new Date(v)
                            return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
                          }}
                          formatter={(value: number) => [`${value}%`, 'Score']}
                        />
                        <Area
                          type="monotone"
                          dataKey="score"
                          stroke={CHART_COLORS.emerald}
                          strokeWidth={2.5}
                          fill="url(#scoreGradient)"
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Learning Activity - Bar Chart */}
            <motion.div variants={itemVariants}>
              <Card className="h-full">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Activity className="w-5 h-5 text-amber-500" />
                    Learning Activity
                  </CardTitle>
                  <CardDescription>Weekly lessons and quizzes completed</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-64 md:h-72">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={analytics?.weeklyActivity || []}>
                        <CartesianGrid strokeDasharray="3 3" className="stroke-muted/30" />
                        <XAxis
                          dataKey="day"
                          tick={{ fontSize: 11 }}
                          className="text-muted-foreground"
                        />
                        <YAxis
                          tick={{ fontSize: 11 }}
                          className="text-muted-foreground"
                        />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: 'hsl(var(--card))',
                            border: '1px solid hsl(var(--border))',
                            borderRadius: '8px',
                            fontSize: '12px',
                          }}
                        />
                        <Bar
                          dataKey="lessons"
                          fill={CHART_COLORS.emerald}
                          radius={[4, 4, 0, 0]}
                          maxBarSize={32}
                        />
                        <Bar
                          dataKey="quizzes"
                          fill={CHART_COLORS.amber}
                          radius={[4, 4, 0, 0]}
                          maxBarSize={32}
                        />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>

          {/* Middle Row: Progress by Category */}
          <motion.div variants={itemVariants}>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  <BookOpen className="w-5 h-5 text-teal-500" />
                  Progress by Category
                </CardTitle>
                <CardDescription>Your completion rate across different subjects</CardDescription>
              </CardHeader>
              <CardContent>
                {analytics?.progressByCategory && analytics.progressByCategory.length > 0 ? (
                  <div className="space-y-4 py-2">
                    {analytics.progressByCategory.map((cat, index) => {
                      const percentage = cat.total > 0 ? Math.round((cat.completed / cat.total) * 100) : 0
                      const colors = [
                        { bar: 'bg-emerald-500', track: 'bg-emerald-500/20', text: 'text-emerald-600 dark:text-emerald-400' },
                        { bar: 'bg-amber-500', track: 'bg-amber-500/20', text: 'text-amber-600 dark:text-amber-400' },
                        { bar: 'bg-rose-500', track: 'bg-rose-500/20', text: 'text-rose-600 dark:text-rose-400' },
                        { bar: 'bg-teal-500', track: 'bg-teal-500/20', text: 'text-teal-600 dark:text-teal-400' },
                        { bar: 'bg-slate-500', track: 'bg-slate-500/20', text: 'text-slate-600 dark:text-slate-400' },
                      ]
                      const color = colors[index % colors.length]

                      return (
                        <div key={cat.category} className="space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-sm font-medium">{cat.category}</span>
                            <span className={`text-sm font-semibold ${color.text}`}>
                              {cat.completed}/{cat.total} · {percentage}%
                            </span>
                          </div>
                          <div className={`h-3 rounded-full ${color.track} overflow-hidden`}>
                            <motion.div
                              initial={{ width: 0 }}
                              animate={{ width: `${percentage}%` }}
                              transition={{ duration: 0.8, delay: index * 0.1, ease: 'easeOut' }}
                              className={`h-full rounded-full ${color.bar}`}
                            />
                          </div>
                        </div>
                      )
                    })}
                  </div>
                ) : (
                  <div className="py-8 text-center text-muted-foreground text-sm">
                    No category progress data yet.
                  </div>
                )}
              </CardContent>
            </Card>
          </motion.div>

          {/* Bottom Row: Strong/Weak Topics + Learning Time */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6">
            {/* Strong vs Weak Topics */}
            <motion.div variants={itemVariants}>
              <Card className="h-full">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Brain className="w-5 h-5 text-emerald-500" />
                    Strong & Weak Topics
                  </CardTitle>
                  <CardDescription>Areas you excel and need improvement</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    {/* Strong Topics */}
                    <div className="space-y-1.5">
                      <h4 className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider flex items-center gap-1">
                        <TrendingUp className="w-3 h-3" /> Strong
                      </h4>
                      {analytics?.strongTopics && analytics.strongTopics.length > 0 ? (
                        <div className="space-y-2 mt-2">
                          {analytics.strongTopics.slice(0, 5).map((topic) => (
                            <div
                              key={topic.name}
                              className="flex items-center justify-between p-2 rounded-lg bg-emerald-500/5 border border-emerald-500/10"
                            >
                              <span className="text-xs font-medium truncate mr-2">{topic.name}</span>
                              <Badge
                                variant="secondary"
                                className="text-[10px] bg-emerald-500/10 text-emerald-700 dark:text-emerald-400 shrink-0"
                              >
                                {topic.score}%
                              </Badge>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-xs text-muted-foreground py-4 text-center">No data yet</p>
                      )}
                    </div>

                    {/* Weak Topics */}
                    <div className="space-y-1.5">
                      <h4 className="text-xs font-semibold text-rose-600 dark:text-rose-400 uppercase tracking-wider flex items-center gap-1">
                        <TrendingDown className="w-3 h-3" /> Needs Work
                      </h4>
                      {analytics?.weakTopics && analytics.weakTopics.length > 0 ? (
                        <div className="space-y-2 mt-2">
                          {analytics.weakTopics.slice(0, 5).map((topic) => (
                            <div
                              key={topic.name}
                              className="flex items-center justify-between p-2 rounded-lg bg-rose-500/5 border border-rose-500/10"
                            >
                              <span className="text-xs font-medium truncate mr-2">{topic.name}</span>
                              <Badge
                                variant="secondary"
                                className="text-[10px] bg-rose-500/10 text-rose-700 dark:text-rose-400 shrink-0"
                              >
                                {topic.score}%
                              </Badge>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <p className="text-xs text-muted-foreground py-4 text-center">No data yet</p>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>

            {/* Learning Time - Line Chart */}
            <motion.div variants={itemVariants}>
              <Card className="h-full">
                <CardHeader className="pb-2">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Clock className="w-5 h-5 text-slate-500" />
                    Learning Time
                  </CardTitle>
                  <CardDescription>Minutes spent learning over time</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-64 md:h-72">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={analytics?.learningTime || []}>
                        <CartesianGrid strokeDasharray="3 3" className="stroke-muted/30" />
                        <XAxis
                          dataKey="date"
                          tick={{ fontSize: 11 }}
                          tickFormatter={(v) => {
                            const d = new Date(v)
                            return `${d.getMonth() + 1}/${d.getDate()}`
                          }}
                          className="text-muted-foreground"
                        />
                        <YAxis
                          tick={{ fontSize: 11 }}
                          className="text-muted-foreground"
                          label={{
                            value: 'min',
                            angle: -90,
                            position: 'insideLeft',
                            style: { fontSize: 10, textAnchor: 'middle' },
                          }}
                        />
                        <Tooltip
                          contentStyle={{
                            backgroundColor: 'hsl(var(--card))',
                            border: '1px solid hsl(var(--border))',
                            borderRadius: '8px',
                            fontSize: '12px',
                          }}
                          labelFormatter={(v) => {
                            const d = new Date(v)
                            return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
                          }}
                          formatter={(value: number) => [`${value} min`, 'Study Time']}
                        />
                        <Line
                          type="monotone"
                          dataKey="minutes"
                          stroke={CHART_COLORS.teal}
                          strokeWidth={2.5}
                          dot={{ r: 3, fill: CHART_COLORS.teal }}
                          activeDot={{ r: 5, fill: CHART_COLORS.teal }}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </>
      )}

      {/* Loading State */}
      {loading && (
        <div className="fixed inset-0 bg-background/50 backdrop-blur-sm z-30 flex items-center justify-center pointer-events-none">
          <motion.div
            animate={{ rotate: 360 }}
            transition={{ repeat: Infinity, duration: 1, ease: 'linear' }}
            className="w-8 h-8 border-2 border-emerald-500 border-t-transparent rounded-full"
          />
        </div>
      )}
    </motion.div>
  )
}
