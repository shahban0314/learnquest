'use client'

import { useEffect, useState, useMemo } from 'react'
import { useLearningStore } from '@/store/learning-store'
import { Card, CardContent } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { Separator } from '@/components/ui/separator'
import {
  ArrowLeft,
  ArrowRight,
  Bookmark,
  BookmarkCheck,
  CheckCircle2,
  Clock,
  Trophy,
  Sparkles,
  FileText,
} from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'

const difficultyConfig: Record<string, { color: string }> = {
  Beginner: { color: 'bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-300' },
  Intermediate: { color: 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300' },
  Advanced: { color: 'bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-300' },
}

export default function LessonView() {
  const {
    currentLesson,
    currentCourse,
    selectedLessonId,
    loading,
    fetchLesson,
    completeLesson,
    toggleBookmark,
    bookmarks,
    setView,
    selectLesson,
  } = useLearningStore()

  const [completing, setCompleting] = useState(false)
  const [showSuccess, setShowSuccess] = useState(false)

  useEffect(() => {
    if (selectedLessonId) {
      fetchLesson(selectedLessonId)
    }
  }, [selectedLessonId, fetchLesson])

  const isBookmarked = currentLesson ? bookmarks.includes(currentLesson.id) : false
  const isCompleted = currentLesson?.progress?.completed ?? false

  // Find previous/next lessons
  const { prevLesson, nextLesson } = useMemo(() => {
    if (!currentCourse?.topics) return { prevLesson: null, nextLesson: null }
    const allLessons = currentCourse.topics
      .sort((a, b) => a.order - b.order)
      .flatMap((t) => (t.lessons || []).sort((a, b) => a.order - b.order))
    const currentIndex = allLessons.findIndex((l) => l.id === selectedLessonId)
    return {
      prevLesson: currentIndex > 0 ? allLessons[currentIndex - 1] : null,
      nextLesson: currentIndex < allLessons.length - 1 ? allLessons[currentIndex + 1] : null,
    }
  }, [currentCourse, selectedLessonId])

  const handleComplete = async () => {
    if (!currentLesson || isCompleted) return
    setCompleting(true)
    try {
      await completeLesson(currentLesson.id)
      setShowSuccess(true)
      setTimeout(() => setShowSuccess(false), 3000)
    } finally {
      setCompleting(false)
    }
  }

  const handleBookmark = () => {
    if (!currentLesson) return
    toggleBookmark(currentLesson.id)
  }

  if (loading && !currentLesson) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-6 w-64" />
        <Skeleton className="h-80 w-full" />
      </div>
    )
  }

  if (!currentLesson) {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-center">
        <FileText className="size-12 text-muted-foreground mb-4" />
        <h3 className="text-lg font-semibold mb-1">Lesson not found</h3>
        <p className="text-muted-foreground mb-4">The lesson you&apos;re looking for doesn&apos;t exist.</p>
        <Button variant="outline" onClick={() => setView('course-detail')}>
          <ArrowLeft className="size-4 mr-2" />
          Back to Course
        </Button>
      </div>
    )
  }

  const topicName = currentLesson.topic?.name || ''
  const diffConfig = difficultyConfig[currentLesson.difficulty] || difficultyConfig.Beginner

  return (
    <div className="space-y-6">
      {/* Back Button */}
      <Button variant="ghost" size="sm" onClick={() => setView('course-detail')} className="gap-2">
        <ArrowLeft className="size-4" />
        Back to Course
      </Button>

      {/* Lesson Header */}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
        <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
          <div className="flex-1">
            {topicName && (
              <p className="text-sm text-muted-foreground mb-1">{topicName}</p>
            )}
            <h1 className="text-2xl font-bold tracking-tight sm:text-3xl mb-2">
              {currentLesson.title}
            </h1>
            <div className="flex items-center gap-3">
              <Badge variant="secondary" className={diffConfig.color}>
                {currentLesson.difficulty}
              </Badge>
              <span className="flex items-center gap-1 text-sm text-muted-foreground">
                <Clock className="size-3.5" />
                {currentLesson.duration} min
              </span>
              {isCompleted && (
                <Badge className="bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300 gap-1">
                  <CheckCircle2 className="size-3" />
                  Completed
                </Badge>
              )}
            </div>
          </div>

          <Button
            variant="ghost"
            size="icon"
            onClick={handleBookmark}
            className="shrink-0"
            aria-label={isBookmarked ? 'Remove bookmark' : 'Add bookmark'}
          >
            {isBookmarked ? (
              <BookmarkCheck className="size-5 text-amber-500" />
            ) : (
              <Bookmark className="size-5" />
            )}
          </Button>
        </div>
      </motion.div>

      <Separator />

      {/* Lesson Content */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
      >
        <Card>
          <CardContent className="p-6 sm:p-8">
            <div className="prose prose-slate dark:prose-invert max-w-none">
              <div className="whitespace-pre-wrap text-sm leading-relaxed sm:text-base sm:leading-7">
                {currentLesson.content}
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Completion Section */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
      >
        <Card className="border-dashed">
          <CardContent className="p-6 flex flex-col items-center gap-4 text-center">
            <AnimatePresence mode="wait">
              {showSuccess ? (
                <motion.div
                  key="success"
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 0.8, opacity: 0 }}
                  className="flex flex-col items-center gap-2"
                >
                  <motion.div
                    animate={{ rotate: [0, 10, -10, 0] }}
                    transition={{ duration: 0.5 }}
                  >
                    <Trophy className="size-12 text-amber-500" />
                  </motion.div>
                  <p className="text-lg font-semibold text-emerald-600 dark:text-emerald-400">
                    Lesson Completed!
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Great work! You earned points for completing this lesson.
                  </p>
                </motion.div>
              ) : isCompleted ? (
                <motion.div
                  key="completed"
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 0.8, opacity: 0 }}
                  className="flex flex-col items-center gap-2"
                >
                  <CheckCircle2 className="size-12 text-emerald-500" />
                  <p className="text-lg font-semibold text-emerald-600 dark:text-emerald-400">
                    You&apos;ve completed this lesson
                  </p>
                  <p className="text-sm text-muted-foreground">
                    Review the content anytime or move on to the next lesson.
                  </p>
                </motion.div>
              ) : (
                <motion.div
                  key="incomplete"
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 0.8, opacity: 0 }}
                  className="flex flex-col items-center gap-3"
                >
                  <Sparkles className="size-10 text-amber-500" />
                  <p className="text-sm text-muted-foreground">
                    Finished reading? Mark this lesson as complete to track your progress.
                  </p>
                  <Button
                    onClick={handleComplete}
                    disabled={completing}
                    className="bg-emerald-600 hover:bg-emerald-700 text-white"
                  >
                    {completing ? (
                      <span className="flex items-center gap-2">
                        <span className="size-4 animate-spin rounded-full border-2 border-white border-t-transparent" />
                        Completing...
                      </span>
                    ) : (
                      <>
                        <CheckCircle2 className="size-4 mr-2" />
                        Mark as Complete
                      </>
                    )}
                  </Button>
                </motion.div>
              )}
            </AnimatePresence>
          </CardContent>
        </Card>
      </motion.div>

      {/* Lesson Navigation */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="flex items-center justify-between gap-3"
      >
        <Button
          variant="outline"
          onClick={() => prevLesson && selectLesson(prevLesson.id)}
          disabled={!prevLesson}
          className="gap-2"
        >
          <ArrowLeft className="size-4" />
          <span className="hidden sm:inline">Previous</span>
        </Button>

        <Button
          onClick={() => nextLesson && selectLesson(nextLesson.id)}
          disabled={!nextLesson}
          className="gap-2"
        >
          <span className="hidden sm:inline">Next Lesson</span>
          <ArrowRight className="size-4" />
        </Button>
      </motion.div>
    </div>
  )
}
