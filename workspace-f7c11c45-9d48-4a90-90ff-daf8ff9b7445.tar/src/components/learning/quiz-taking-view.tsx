'use client'

import { useState, useMemo } from 'react'
import { useLearningStore } from '@/store/learning-store'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Separator } from '@/components/ui/separator'
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group'
import { Label } from '@/components/ui/label'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog'
import {
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  XCircle,
  Brain,
  Clock,
  HelpCircle,
  Trophy,
  Lightbulb,
  RotateCcw,
} from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'

const difficultyConfig: Record<string, { color: string }> = {
  Beginner: { color: 'bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-300' },
  Intermediate: { color: 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300' },
  Advanced: { color: 'bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-300' },
}

export default function QuizTakingView() {
  const {
    currentQuiz,
    quizAnswers,
    quizSubmitted,
    quizResult,
    loading,
    selectedQuizId,
    setQuizAnswer,
    submitQuiz,
    resetQuiz,
    setView,
  } = useLearningStore()

  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0)

  const questions = useMemo(() => {
    if (!currentQuiz?.questions) return []
    return [...currentQuiz.questions].sort((a, b) => a.order - b.order)
  }, [currentQuiz])

  const answeredCount = useMemo(() => {
    return questions.filter((q) => quizAnswers[q.id]).length
  }, [questions, quizAnswers])

  const allAnswered = answeredCount === questions.length

  const currentQuestion = questions[currentQuestionIndex]

  const progressPercent = questions.length > 0 ? (answeredCount / questions.length) * 100 : 0

  if (!currentQuiz) {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-center">
        <Brain className="size-12 text-muted-foreground mb-4" />
        <h3 className="text-lg font-semibold mb-1">Quiz not found</h3>
        <p className="text-muted-foreground mb-4">The quiz you&apos;re looking for doesn&apos;t exist.</p>
        <Button variant="outline" onClick={() => setView('quizzes')}>
          <ArrowLeft className="size-4 mr-2" />
          Back to Quizzes
        </Button>
      </div>
    )
  }

  // Result view
  if (quizSubmitted && quizResult) {
    const scorePercentage = quizResult.totalPoints > 0
      ? Math.round((quizResult.score / quizResult.totalPoints) * 100)
      : 0
    const isPassed = scorePercentage >= 70

    return (
      <div className="space-y-6">
        {/* Score Card */}
        <motion.div initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }}>
          <Card className="overflow-hidden">
            <div className={`h-2 ${isPassed ? 'bg-emerald-500' : 'bg-rose-500'}`} />
            <CardContent className="p-6 text-center">
              <motion.div
                animate={{ rotate: isPassed ? [0, 10, -10, 0] : 0 }}
                transition={{ duration: 0.6, delay: 0.3 }}
              >
                <Trophy className={`size-16 mx-auto mb-4 ${isPassed ? 'text-amber-500' : 'text-slate-400'}`} />
              </motion.div>
              <h2 className="text-2xl font-bold mb-2">
                {isPassed ? 'Great Job!' : 'Keep Practicing!'}
              </h2>
              <p className="text-muted-foreground mb-4">
                You scored <span className={`font-bold text-lg ${isPassed ? 'text-emerald-600 dark:text-emerald-400' : 'text-rose-600 dark:text-rose-400'}`}>{quizResult.score}</span> out of {quizResult.totalPoints} points
              </p>
              <div className="flex items-center justify-center gap-4">
                <div className="text-center">
                  <p className="text-3xl font-bold">{scorePercentage}%</p>
                  <p className="text-xs text-muted-foreground">Score</p>
                </div>
                <Separator orientation="vertical" className="h-12" />
                <div className="text-center">
                  <p className="text-3xl font-bold">{answeredCount}/{questions.length}</p>
                  <p className="text-xs text-muted-foreground">Answered</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Question Review */}
        <div className="space-y-3">
          <h3 className="text-lg font-semibold">Review Answers</h3>
          {questions.map((question, index) => {
            const userAnswer = quizResult.answers[question.id] || ''
            const isCorrect = userAnswer === question.correctAnswer

            return (
              <motion.div
                key={question.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
              >
                <Card className={`${isCorrect ? 'border-emerald-200 dark:border-emerald-800' : 'border-rose-200 dark:border-rose-800'}`}>
                  <CardContent className="p-4">
                    <div className="flex items-start gap-3">
                      {isCorrect ? (
                        <CheckCircle2 className="size-5 text-emerald-500 shrink-0 mt-0.5" />
                      ) : (
                        <XCircle className="size-5 text-rose-500 shrink-0 mt-0.5" />
                      )}
                      <div className="flex-1 min-w-0">
                        <p className="font-medium text-sm mb-1">
                          <span className="text-muted-foreground mr-1.5">Q{index + 1}.</span>
                          {question.text}
                        </p>
                        {!isCorrect && (
                          <div className="space-y-1 text-sm">
                            <p className="text-rose-600 dark:text-rose-400">
                              Your answer: {userAnswer || 'Not answered'}
                            </p>
                            <p className="text-emerald-600 dark:text-emerald-400">
                              Correct answer: {question.correctAnswer}
                            </p>
                          </div>
                        )}
                        {question.explanation && (
                          <div className="mt-2 flex items-start gap-2 rounded-md bg-amber-50 dark:bg-amber-900/20 p-2.5 text-sm text-amber-800 dark:text-amber-300">
                            <Lightbulb className="size-4 shrink-0 mt-0.5" />
                            <p>{question.explanation}</p>
                          </div>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )
          })}
        </div>

        {/* Actions */}
        <div className="flex items-center gap-3">
          <Button
            variant="outline"
            onClick={() => {
              resetQuiz()
              setView('quizzes')
            }}
          >
            <ArrowLeft className="size-4 mr-2" />
            Back to Quizzes
          </Button>
          <Button
            onClick={() => {
              resetQuiz()
              // Re-fetch to reload
              if (selectedQuizId) {
                const { fetchQuizDetail } = useLearningStore.getState()
                fetchQuizDetail(selectedQuizId)
              }
              setCurrentQuestionIndex(0)
            }}
            className="gap-2"
          >
            <RotateCcw className="size-4" />
            Retake Quiz
          </Button>
        </div>
      </div>
    )
  }

  // Quiz-taking view
  return (
    <div className="space-y-6">
      {/* Quiz Header */}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">{currentQuiz.title}</h1>
            <div className="flex items-center gap-3 mt-1">
              <Badge variant="secondary" className={difficultyConfig[currentQuiz.difficulty]?.color || ''}>
                {currentQuiz.difficulty}
              </Badge>
              <span className="flex items-center gap-1 text-sm text-muted-foreground">
                <HelpCircle className="size-3.5" />
                {questions.length} questions
              </span>
              {currentQuiz.timeLimit > 0 && (
                <span className="flex items-center gap-1 text-sm text-muted-foreground">
                  <Clock className="size-3.5" />
                  {currentQuiz.timeLimit} min
                </span>
              )}
            </div>
          </div>
          <Button variant="ghost" size="sm" onClick={() => setView('quizzes')} className="gap-1">
            <ArrowLeft className="size-4" />
            Exit
          </Button>
        </div>
      </motion.div>

      {/* Progress Bar */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-sm">
          <span className="text-muted-foreground">
            {answeredCount} of {questions.length} answered
          </span>
          <span className="font-medium">{Math.round(progressPercent)}%</span>
        </div>
        <Progress value={progressPercent} className="h-2.5" />
      </div>

      {/* Question Display */}
      {currentQuestion && (
        <AnimatePresence mode="wait">
          <motion.div
            key={currentQuestion.id}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.2 }}
          >
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-lg flex items-center gap-2">
                  <span className="flex items-center justify-center size-8 rounded-full bg-primary/10 text-sm font-bold text-primary shrink-0">
                    {currentQuestionIndex + 1}
                  </span>
                  <span className="text-base font-medium">{currentQuestion.text}</span>
                </CardTitle>
                {currentQuestion.points > 0 && (
                  <p className="text-xs text-muted-foreground ml-10">
                    {currentQuestion.points} point{currentQuestion.points !== 1 ? 's' : ''}
                  </p>
                )}
              </CardHeader>
              <Separator />
              <CardContent className="pt-4">
                {currentQuestion.type === 'TRUE_FALSE' ? (
                  <div className="flex gap-3">
                    {['True', 'False'].map((option) => (
                      <Button
                        key={option}
                        variant={quizAnswers[currentQuestion.id] === option ? 'default' : 'outline'}
                        className={`flex-1 py-6 text-base ${
                          quizAnswers[currentQuestion.id] === option
                            ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                            : 'hover:border-emerald-300'
                        }`}
                        onClick={() => setQuizAnswer(currentQuestion.id, option)}
                      >
                        {option}
                      </Button>
                    ))}
                  </div>
                ) : (
                  <RadioGroup
                    value={quizAnswers[currentQuestion.id] || ''}
                    onValueChange={(value) => setQuizAnswer(currentQuestion.id, value)}
                    className="space-y-2"
                  >
                    {currentQuestion.options.map((option, optIndex) => (
                      <div key={optIndex}>
                        <Label
                          htmlFor={`${currentQuestion.id}-${optIndex}`}
                          className={`flex items-center gap-3 rounded-lg border p-3.5 cursor-pointer transition-all hover:bg-muted/50 ${
                            quizAnswers[currentQuestion.id] === option
                              ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-900/20'
                              : 'border-border'
                          }`}
                        >
                          <RadioGroupItem
                            value={option}
                            id={`${currentQuestion.id}-${optIndex}`}
                          />
                          <span className="text-sm">{option}</span>
                        </Label>
                      </div>
                    ))}
                  </RadioGroup>
                )}
              </CardContent>
            </Card>
          </motion.div>
        </AnimatePresence>
      )}

      {/* Navigation */}
      <div className="flex items-center justify-between gap-3">
        <Button
          variant="outline"
          onClick={() => setCurrentQuestionIndex(Math.max(0, currentQuestionIndex - 1))}
          disabled={currentQuestionIndex === 0}
          className="gap-2"
        >
          <ArrowLeft className="size-4" />
          Previous
        </Button>

        <div className="flex items-center gap-1">
          {questions.map((_, i) => (
            <button
              key={i}
              onClick={() => setCurrentQuestionIndex(i)}
              className={`size-2.5 rounded-full transition-all ${
                i === currentQuestionIndex
                  ? 'bg-primary scale-125'
                  : quizAnswers[questions[i]?.id]
                    ? 'bg-emerald-400'
                    : 'bg-muted-foreground/25'
              }`}
              aria-label={`Go to question ${i + 1}`}
            />
          ))}
        </div>

        {currentQuestionIndex < questions.length - 1 ? (
          <Button
            onClick={() => setCurrentQuestionIndex(currentQuestionIndex + 1)}
            className="gap-2"
          >
            Next
            <ArrowRight className="size-4" />
          </Button>
        ) : (
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button disabled={!allAnswered || loading} className="gap-2 bg-emerald-600 hover:bg-emerald-700 text-white">
                <CheckCircle2 className="size-4" />
                Submit Quiz
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Submit Quiz?</AlertDialogTitle>
                <AlertDialogDescription>
                  You have answered {answeredCount} out of {questions.length} questions.
                  This action cannot be undone.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction
                  onClick={() => submitQuiz(selectedQuizId!)}
                  className="bg-emerald-600 hover:bg-emerald-700"
                >
                  Submit
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        )}
      </div>
    </div>
  )
}
