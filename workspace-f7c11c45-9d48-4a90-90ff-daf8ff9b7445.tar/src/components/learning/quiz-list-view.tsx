'use client'

import { useEffect, useState, useMemo } from 'react'
import { useLearningStore } from '@/store/learning-store'
import { Card, CardContent, CardFooter } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Brain,
  Clock,
  HelpCircle,
  Play,
  Trophy,
  Sparkles,
  Target,
} from 'lucide-react'
import { motion } from 'framer-motion'

const difficultyConfig: Record<string, { color: string; label: string }> = {
  Beginner: { color: 'bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-300', label: 'Beginner' },
  Intermediate: { color: 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300', label: 'Intermediate' },
  Advanced: { color: 'bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-300', label: 'Advanced' },
}

function QuizCardSkeleton() {
  return (
    <Card className="overflow-hidden">
      <CardContent className="p-6">
        <Skeleton className="h-5 w-24 mb-3" />
        <Skeleton className="h-6 w-3/4 mb-2" />
        <Skeleton className="h-4 w-full mb-1" />
        <Skeleton className="h-4 w-1/2 mb-4" />
        <div className="flex items-center gap-3">
          <Skeleton className="h-4 w-20" />
          <Skeleton className="h-4 w-20" />
        </div>
      </CardContent>
      <CardFooter className="px-6 pb-4">
        <Skeleton className="h-9 w-full" />
      </CardFooter>
    </Card>
  )
}

export default function QuizListView() {
  const { quizzes, courses, loading, fetchQuizzes, selectQuiz } = useLearningStore()
  const [courseFilter, setCourseFilter] = useState<string>('all')
  const [difficultyFilter, setDifficultyFilter] = useState<string>('all')

  useEffect(() => {
    fetchQuizzes()
  }, [fetchQuizzes])

  const filteredQuizzes = useMemo(() => {
    return quizzes.filter((quiz) => {
      const matchesCourse = courseFilter === 'all' || quiz.courseId === courseFilter
      const matchesDifficulty = difficultyFilter === 'all' || quiz.difficulty === difficultyFilter
      return matchesCourse && matchesDifficulty
    })
  }, [quizzes, courseFilter, difficultyFilter])

  const uniqueCourses = useMemo(() => {
    const courseIds = [...new Set(quizzes.map((q) => q.courseId).filter(Boolean))]
    return courses.filter((c) => courseIds.includes(c.id))
  }, [quizzes, courses])

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight sm:text-3xl flex items-center gap-2">
          <Brain className="size-7 text-amber-500" />
          Quizzes & Assessments
        </h1>
        <p className="text-muted-foreground mt-1">Test your knowledge and track your progress</p>
      </div>

      {/* Filters */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <Tabs value={difficultyFilter} onValueChange={setDifficultyFilter}>
          <TabsList>
            <TabsTrigger value="all">All Levels</TabsTrigger>
            <TabsTrigger value="Beginner">Beginner</TabsTrigger>
            <TabsTrigger value="Intermediate">Intermediate</TabsTrigger>
            <TabsTrigger value="Advanced">Advanced</TabsTrigger>
          </TabsList>
        </Tabs>

        {uniqueCourses.length > 0 && (
          <Select value={courseFilter} onValueChange={setCourseFilter}>
            <SelectTrigger className="w-[200px]">
              <SelectValue placeholder="Filter by course" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Courses</SelectItem>
              {uniqueCourses.map((course) => (
                <SelectItem key={course.id} value={course.id}>
                  {course.title}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}
      </div>

      {/* Loading State */}
      {loading && (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <QuizCardSkeleton key={i} />
          ))}
        </div>
      )}

      {/* Empty State */}
      {!loading && filteredQuizzes.length === 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col items-center justify-center py-16 text-center"
        >
          <div className="rounded-full bg-muted p-4 mb-4">
            <Sparkles className="size-8 text-muted-foreground" />
          </div>
          <h3 className="text-lg font-semibold mb-1">No quizzes found</h3>
          <p className="text-muted-foreground max-w-sm">
            Try adjusting your filters or check back later for new quizzes.
          </p>
        </motion.div>
      )}

      {/* Quiz Grid */}
      {!loading && filteredQuizzes.length > 0 && (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
          {filteredQuizzes.map((quiz, index) => {
            const diffConfig = difficultyConfig[quiz.difficulty] || difficultyConfig.Beginner
            const questionCount = quiz._count?.questions ?? quiz.questions?.length ?? 0
            const hasAttempted = quiz.latestScore !== null && quiz.latestScore !== undefined

            return (
              <motion.div
                key={quiz.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05, duration: 0.3 }}
              >
                <Card className="overflow-hidden group hover:shadow-lg transition-all duration-300 hover:-translate-y-0.5">
                  <CardContent className="p-6">
                    <div className="flex items-center gap-2 mb-3">
                      <Badge variant="secondary" className={diffConfig.color}>
                        {diffConfig.label}
                      </Badge>
                      {hasAttempted && (
                        <Badge variant="secondary" className="bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300 gap-1">
                          <Trophy className="size-3" />
                          Attempted
                        </Badge>
                      )}
                    </div>

                    <h3 className="font-semibold text-lg mb-1.5 group-hover:text-amber-600 dark:group-hover:text-amber-400 transition-colors line-clamp-2">
                      {quiz.title}
                    </h3>
                    <p className="text-sm text-muted-foreground line-clamp-2 mb-4">
                      {quiz.description || 'Test your knowledge with this assessment'}
                    </p>

                    <div className="flex items-center gap-4 text-xs text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <HelpCircle className="size-3.5" />
                        {questionCount} questions
                      </span>
                      {quiz.timeLimit > 0 && (
                        <span className="flex items-center gap-1">
                          <Clock className="size-3.5" />
                          {quiz.timeLimit} min
                        </span>
                      )}
                    </div>

                    {hasAttempted && quiz.latestScore !== null && (
                      <div className="mt-3 flex items-center gap-2">
                        <Target className="size-4 text-emerald-500" />
                        <span className="text-sm font-medium text-emerald-600 dark:text-emerald-400">
                          Latest Score: {quiz.latestScore}%
                        </span>
                      </div>
                    )}
                  </CardContent>

                  <CardFooter className="px-6 pb-4 pt-0">
                    <Button
                      className="w-full"
                      variant={hasAttempted ? 'outline' : 'default'}
                      size="sm"
                      onClick={() => selectQuiz(quiz.id)}
                    >
                      <Play className="size-3.5 mr-1.5" />
                      {hasAttempted ? 'Retake Quiz' : 'Start Quiz'}
                    </Button>
                  </CardFooter>
                </Card>
              </motion.div>
            )
          })}
        </div>
      )}
    </div>
  )
}
