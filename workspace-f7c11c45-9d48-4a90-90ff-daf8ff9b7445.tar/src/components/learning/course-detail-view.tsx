'use client'

import { useEffect, useMemo } from 'react'
import { useLearningStore } from '@/store/learning-store'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Progress } from '@/components/ui/progress'
import { Separator } from '@/components/ui/separator'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion'
import {
  ArrowLeft,
  Star,
  Clock,
  BookOpen,
  CheckCircle2,
  Circle,
  Play,
  GraduationCap,
  FlaskConical,
  Code,
  Brain,
} from 'lucide-react'
import { motion } from 'framer-motion'

const categoryConfig: Record<string, { color: string; icon: React.ReactNode }> = {
  Mathematics: { color: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300', icon: <GraduationCap className="size-4" /> },
  Science: { color: 'bg-teal-100 text-teal-700 dark:bg-teal-900/40 dark:text-teal-300', icon: <FlaskConical className="size-4" /> },
  'Computer Science': { color: 'bg-violet-100 text-violet-700 dark:bg-violet-900/40 dark:text-violet-300', icon: <Code className="size-4" /> },
}

const difficultyConfig: Record<string, { color: string }> = {
  Beginner: { color: 'bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-300' },
  Intermediate: { color: 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300' },
  Advanced: { color: 'bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-300' },
}

export default function CourseDetailView() {
  const {
    currentCourse,
    loading,
    selectedCourseId,
    fetchCourseDetail,
    setView,
    selectLesson,
    selectQuiz,
    fetchQuizzes,
    quizzes,
  } = useLearningStore()

  useEffect(() => {
    if (selectedCourseId) {
      fetchCourseDetail(selectedCourseId)
      fetchQuizzes(selectedCourseId)
    }
  }, [selectedCourseId, fetchCourseDetail, fetchQuizzes])

  const overallProgress = useMemo(() => {
    if (!currentCourse?.topics) return 0
    const allLessons = currentCourse.topics.flatMap((t) => t.lessons || [])
    if (allLessons.length === 0) return 0
    const completed = allLessons.filter((l) => l.progress?.completed).length
    return Math.round((completed / allLessons.length) * 100)
  }, [currentCourse])

  const completedLessonsCount = useMemo(() => {
    if (!currentCourse?.topics) return 0
    return currentCourse.topics.flatMap((t) => t.lessons || []).filter((l) => l.progress?.completed).length
  }, [currentCourse])

  const totalLessonsCount = useMemo(() => {
    if (!currentCourse?.topics) return 0
    return currentCourse.topics.flatMap((t) => t.lessons || []).length
  }, [currentCourse])

  if (loading && !currentCourse) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-8 w-48" />
        <Skeleton className="h-40 w-full" />
        <Skeleton className="h-60 w-full" />
      </div>
    )
  }

  if (!currentCourse) {
    return (
      <div className="flex flex-col items-center justify-center py-16 text-center">
        <BookOpen className="size-12 text-muted-foreground mb-4" />
        <h3 className="text-lg font-semibold mb-1">Course not found</h3>
        <p className="text-muted-foreground mb-4">The course you&apos;re looking for doesn&apos;t exist.</p>
        <Button variant="outline" onClick={() => setView('courses')}>
          <ArrowLeft className="size-4 mr-2" />
          Back to Courses
        </Button>
      </div>
    )
  }

  const catConfig = categoryConfig[currentCourse.category] || {
    color: 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300',
    icon: <BookOpen className="size-4" />,
  }
  const diffConfig = difficultyConfig[currentCourse.difficulty] || {
    color: 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300',
  }

  return (
    <div className="space-y-6">
      {/* Back Button */}
      <Button variant="ghost" size="sm" onClick={() => setView('courses')} className="gap-2">
        <ArrowLeft className="size-4" />
        Back to Courses
      </Button>

      {/* Course Header */}
      <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
        <Card>
          <CardContent className="p-6">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <Badge variant="secondary" className={`${catConfig.color} gap-1`}>
                    {catConfig.icon}
                    {currentCourse.category}
                  </Badge>
                  <Badge variant="secondary" className={diffConfig.color}>
                    {currentCourse.difficulty}
                  </Badge>
                </div>
                <h1 className="text-2xl font-bold tracking-tight sm:text-3xl mb-2">
                  {currentCourse.title}
                </h1>
                <p className="text-muted-foreground mb-4">{currentCourse.description}</p>
                <div className="flex items-center gap-4 text-sm text-muted-foreground">
                  {currentCourse.duration && (
                    <span className="flex items-center gap-1.5">
                      <Clock className="size-4" />
                      {currentCourse.duration}
                    </span>
                  )}
                  <span className="flex items-center gap-1.5">
                    <Star className="size-4 fill-amber-400 text-amber-400" />
                    {currentCourse.rating.toFixed(1)}
                  </span>
                  <span className="flex items-center gap-1.5">
                    <BookOpen className="size-4" />
                    {totalLessonsCount} lessons
                  </span>
                </div>
              </div>

              {/* Progress Circle */}
              <div className="flex flex-col items-center gap-2 min-w-[100px]">
                <div className="relative size-24">
                  <svg className="size-24 -rotate-90" viewBox="0 0 100 100">
                    <circle
                      cx="50"
                      cy="50"
                      r="42"
                      stroke="currentColor"
                      strokeWidth="8"
                      fill="none"
                      className="text-muted/30"
                    />
                    <circle
                      cx="50"
                      cy="50"
                      r="42"
                      stroke="currentColor"
                      strokeWidth="8"
                      fill="none"
                      strokeLinecap="round"
                      className="text-emerald-500"
                      strokeDasharray={`${2 * Math.PI * 42}`}
                      strokeDashoffset={`${2 * Math.PI * 42 * (1 - overallProgress / 100)}`}
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-xl font-bold">{overallProgress}%</span>
                  </div>
                </div>
                <p className="text-xs text-muted-foreground">
                  {completedLessonsCount}/{totalLessonsCount} completed
                </p>
              </div>
            </div>

            <Separator className="my-4" />

            <div className="flex items-center gap-3">
              <Progress value={overallProgress} className="flex-1 h-2.5" />
              <span className="text-sm font-medium text-emerald-600 dark:text-emerald-400">
                {overallProgress}%
              </span>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Topics Accordion */}
      {currentCourse.topics && currentCourse.topics.length > 0 && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
          <h2 className="text-xl font-semibold mb-4">Course Content</h2>
          <Accordion type="multiple" defaultValue={[currentCourse.topics[0]?.id]} className="space-y-2">
            {currentCourse.topics
              .sort((a, b) => a.order - b.order)
              .map((topic) => {
                const lessons = (topic.lessons || []).sort((a, b) => a.order - b.order)
                const completedInTopic = lessons.filter((l) => l.progress?.completed).length
                const topicProgress = lessons.length > 0 ? Math.round((completedInTopic / lessons.length) * 100) : 0

                return (
                  <AccordionItem key={topic.id} value={topic.id} className="border rounded-lg px-4">
                    <AccordionTrigger className="hover:no-underline">
                      <div className="flex flex-1 items-center gap-3 text-left">
                        <div className="flex-1">
                          <div className="font-medium">{topic.name}</div>
                          <div className="text-xs text-muted-foreground mt-0.5">
                            {completedInTopic}/{lessons.length} lessons · {topicProgress}% complete
                          </div>
                        </div>
                        <div className="w-20 mr-2 hidden sm:block">
                          <Progress value={topicProgress} className="h-1.5" />
                        </div>
                      </div>
                    </AccordionTrigger>
                    <AccordionContent>
                      <div className="space-y-1 pt-2">
                        {lessons.map((lesson) => {
                          const isCompleted = lesson.progress?.completed
                          const lessonDiffConfig = difficultyConfig[lesson.difficulty] || difficultyConfig.Beginner

                          return (
                            <motion.button
                              key={lesson.id}
                              whileHover={{ x: 4 }}
                              onClick={() => selectLesson(lesson.id)}
                              className={`w-full flex items-center gap-3 rounded-lg px-3 py-2.5 text-left text-sm transition-colors hover:bg-muted/60 ${
                                isCompleted ? 'opacity-80' : ''
                              }`}
                            >
                              <span className="shrink-0">
                                {isCompleted ? (
                                  <CheckCircle2 className="size-5 text-emerald-500" />
                                ) : (
                                  <Circle className="size-5 text-muted-foreground" />
                                )}
                              </span>
                              <span className="flex-1 font-medium line-clamp-1">
                                <span className="text-muted-foreground mr-1.5">{lesson.order}.</span>
                                {lesson.title}
                              </span>
                              <Badge variant="secondary" className={`${lessonDiffConfig.color} text-[10px] px-1.5 py-0 hidden sm:inline-flex`}>
                                {lesson.difficulty}
                              </Badge>
                              <span className="text-xs text-muted-foreground shrink-0">
                                {lesson.duration}m
                              </span>
                            </motion.button>
                          )
                        })}
                      </div>
                    </AccordionContent>
                  </AccordionItem>
                )
              })}
          </Accordion>
        </motion.div>
      )}

      {/* Quiz Section */}
      {quizzes.length > 0 && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Brain className="size-5 text-amber-500" />
                Quizzes & Assessments
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {quizzes.map((quiz) => {
                const quizDiffConfig = difficultyConfig[quiz.difficulty] || difficultyConfig.Beginner
                return (
                  <div
                    key={quiz.id}
                    className="flex items-center justify-between gap-3 rounded-lg border p-3"
                  >
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm truncate">{quiz.title}</p>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge variant="secondary" className={`${quizDiffConfig.color} text-[10px] px-1.5 py-0`}>
                          {quiz.difficulty}
                        </Badge>
                        <span className="text-xs text-muted-foreground">
                          {quiz._count?.questions ?? 0} questions
                        </span>
                        {quiz.timeLimit > 0 && (
                          <span className="text-xs text-muted-foreground">
                            {quiz.timeLimit} min
                          </span>
                        )}
                      </div>
                    </div>
                    <Button size="sm" onClick={() => selectQuiz(quiz.id)}>
                      <Play className="size-3.5 mr-1" />
                      Take Quiz
                    </Button>
                  </div>
                )
              })}
            </CardContent>
          </Card>
        </motion.div>
      )}
    </div>
  )
}
