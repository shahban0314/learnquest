'use client'

import { useEffect, useState, useMemo } from 'react'
import { useLearningStore } from '@/store/learning-store'
import { Card, CardContent, CardFooter } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Input } from '@/components/ui/input'
import { Progress } from '@/components/ui/progress'
import { Skeleton } from '@/components/ui/skeleton'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import {
  Search,
  Star,
  Users,
  Clock,
  BookOpen,
  GraduationCap,
  FlaskConical,
  Code,
  Sparkles,
} from 'lucide-react'
import { motion } from 'framer-motion'

const categoryConfig: Record<string, { color: string; icon: React.ReactNode; label: string }> = {
  Mathematics: { color: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300', icon: <GraduationCap className="size-3.5" />, label: 'Mathematics' },
  Science: { color: 'bg-teal-100 text-teal-700 dark:bg-teal-900/40 dark:text-teal-300', icon: <FlaskConical className="size-3.5" />, label: 'Science' },
  'Computer Science': { color: 'bg-violet-100 text-violet-700 dark:bg-violet-900/40 dark:text-violet-300', icon: <Code className="size-3.5" />, label: 'Computer Science' },
}

const difficultyConfig: Record<string, { color: string; label: string }> = {
  Beginner: { color: 'bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-300', label: 'Beginner' },
  Intermediate: { color: 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300', label: 'Intermediate' },
  Advanced: { color: 'bg-rose-100 text-rose-700 dark:bg-rose-900/40 dark:text-rose-300', label: 'Advanced' },
}

function CourseCardSkeleton() {
  return (
    <Card className="overflow-hidden">
      <CardContent className="p-6">
        <Skeleton className="h-5 w-24 mb-3" />
        <Skeleton className="h-6 w-3/4 mb-2" />
        <Skeleton className="h-4 w-full mb-1" />
        <Skeleton className="h-4 w-2/3 mb-4" />
        <div className="flex items-center gap-3 mb-3">
          <Skeleton className="h-4 w-16" />
          <Skeleton className="h-4 w-16" />
          <Skeleton className="h-4 w-16" />
        </div>
        <Skeleton className="h-2 w-full" />
      </CardContent>
      <CardFooter className="px-6 pb-4">
        <Skeleton className="h-9 w-full" />
      </CardFooter>
    </Card>
  )
}

export default function CoursesView() {
  const { courses, loading, fetchCourses, selectCourse } = useLearningStore()
  const [searchQuery, setSearchQuery] = useState('')
  const [categoryFilter, setCategoryFilter] = useState('all')
  const [difficultyFilter, setDifficultyFilter] = useState('all')

  useEffect(() => {
    fetchCourses()
  }, [fetchCourses])

  const filteredCourses = useMemo(() => {
    return courses.filter((course) => {
      const matchesSearch =
        !searchQuery ||
        course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        course.description.toLowerCase().includes(searchQuery.toLowerCase())
      const matchesCategory = categoryFilter === 'all' || course.category === categoryFilter
      const matchesDifficulty = difficultyFilter === 'all' || course.difficulty === difficultyFilter
      return matchesSearch && matchesCategory && matchesDifficulty
    })
  }, [courses, searchQuery, categoryFilter, difficultyFilter])

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight sm:text-3xl">Explore Courses</h1>
        <p className="text-muted-foreground mt-1">Discover and enroll in courses that match your interests</p>
      </div>

      {/* Search & Filters */}
      <div className="space-y-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 size-4 text-muted-foreground" />
          <Input
            placeholder="Search courses..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>

        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <Tabs value={categoryFilter} onValueChange={setCategoryFilter}>
            <TabsList className="flex-wrap">
              <TabsTrigger value="all">
                <BookOpen className="size-3.5 mr-1" />
                All
              </TabsTrigger>
              <TabsTrigger value="Mathematics">
                <GraduationCap className="size-3.5 mr-1" />
                Math
              </TabsTrigger>
              <TabsTrigger value="Science">
                <FlaskConical className="size-3.5 mr-1" />
                Science
              </TabsTrigger>
              <TabsTrigger value="Computer Science">
                <Code className="size-3.5 mr-1" />
                CS
              </TabsTrigger>
            </TabsList>
          </Tabs>

          <Tabs value={difficultyFilter} onValueChange={setDifficultyFilter}>
            <TabsList>
              <TabsTrigger value="all">All Levels</TabsTrigger>
              <TabsTrigger value="Beginner">Beginner</TabsTrigger>
              <TabsTrigger value="Intermediate">Intermediate</TabsTrigger>
              <TabsTrigger value="Advanced">Advanced</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </div>

      {/* Loading State */}
      {loading && (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <CourseCardSkeleton key={i} />
          ))}
        </div>
      )}

      {/* Empty State */}
      {!loading && filteredCourses.length === 0 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex flex-col items-center justify-center py-16 text-center"
        >
          <div className="rounded-full bg-muted p-4 mb-4">
            <Sparkles className="size-8 text-muted-foreground" />
          </div>
          <h3 className="text-lg font-semibold mb-1">No courses found</h3>
          <p className="text-muted-foreground max-w-sm">
            Try adjusting your search or filter criteria to find what you&apos;re looking for.
          </p>
        </motion.div>
      )}

      {/* Course Grid */}
      {!loading && filteredCourses.length > 0 && (
        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 lg:grid-cols-3">
          {filteredCourses.map((course, index) => {
            const catConfig = categoryConfig[course.category] || {
              color: 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300',
              icon: <BookOpen className="size-3.5" />,
              label: course.category,
            }
            const diffConfig = difficultyConfig[course.difficulty] || {
              color: 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300',
              label: course.difficulty,
            }

            return (
              <motion.div
                key={course.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05, duration: 0.3 }}
              >
                <Card
                  className="overflow-hidden cursor-pointer group hover:shadow-lg transition-all duration-300 hover:-translate-y-0.5"
                  onClick={() => selectCourse(course.id)}
                >
                  <CardContent className="p-6">
                    <div className="flex items-center gap-2 mb-3">
                      <Badge variant="secondary" className={`${catConfig.color} gap-1`}>
                        {catConfig.icon}
                        {catConfig.label}
                      </Badge>
                      <Badge variant="secondary" className={diffConfig.color}>
                        {diffConfig.label}
                      </Badge>
                    </div>

                    <h3 className="font-semibold text-lg mb-1.5 group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors line-clamp-2">
                      {course.title}
                    </h3>
                    <p className="text-sm text-muted-foreground line-clamp-2 mb-4">
                      {course.description}
                    </p>

                    <div className="flex items-center gap-4 text-xs text-muted-foreground mb-3">
                      {course.duration && (
                        <span className="flex items-center gap-1">
                          <Clock className="size-3.5" />
                          {course.duration}
                        </span>
                      )}
                      <span className="flex items-center gap-1">
                        <Star className="size-3.5 fill-amber-400 text-amber-400" />
                        {course.rating.toFixed(1)}
                      </span>
                      <span className="flex items-center gap-1">
                        <Users className="size-3.5" />
                        {course.enrolledCount.toLocaleString()}
                      </span>
                    </div>

                    {course.progress !== undefined && course.progress > 0 && (
                      <div className="space-y-1.5">
                        <div className="flex items-center justify-between text-xs">
                          <span className="text-muted-foreground">Progress</span>
                          <span className="font-medium text-emerald-600 dark:text-emerald-400">
                            {Math.round(course.progress)}%
                          </span>
                        </div>
                        <Progress value={course.progress} className="h-2" />
                      </div>
                    )}
                  </CardContent>

                  <CardFooter className="px-6 pb-4 pt-0">
                    <Button
                      className="w-full"
                      variant={course.progress && course.progress > 0 ? 'default' : 'outline'}
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation()
                        selectCourse(course.id)
                      }}
                    >
                      {course.progress && course.progress > 0 ? 'Continue Learning' : 'Start Learning'}
                    </Button>
                  </CardFooter>
                </Card>
              </motion.div>
            )
          })}
        </div>
      )}
    </div>
  )
}
