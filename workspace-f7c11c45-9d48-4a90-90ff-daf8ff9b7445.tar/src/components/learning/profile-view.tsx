'use client'

import { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import {
  Mail,
  Edit3,
  Save,
  X,
  Star,
  Flame,
  Coins,
  Calendar,
  Trophy,
  Loader2,
} from 'lucide-react'
import { useLearningStore, type User, type Badge } from '@/store/learning-store'
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Badge } from '@/components/ui/badge'

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.1 },
  },
}

const itemVariants = {
  hidden: { opacity: 0, y: 16 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.4 } },
}

export default function ProfileView() {
  const { user, badges, fetchBadges } = useLearningStore()

  useEffect(() => {
    fetchBadges()
  }, [fetchBadges])

  if (!user) return null

  return (
    <ProfileContent user={user} badges={badges} />
  )
}

function ProfileContent({ user, badges }: { user: User; badges: Badge[] }) {
  const { updateProfile } = useLearningStore()
  const [isEditing, setIsEditing] = useState(false)
  const [saving, setSaving] = useState(false)
  const [editName, setEditName] = useState(user.name)
  const [editBio, setEditBio] = useState(user.bio || '')

  const earnedBadges = badges.filter((b) => b.earned)
  const avatarEmoji = user.avatar || '🎓'
  const memberSince = new Date().toLocaleDateString('en-US', {
    month: 'long',
    year: 'numeric',
  })

  const handleSave = async () => {
    setSaving(true)
    await updateProfile({ name: editName, bio: editBio })
    setSaving(false)
    setIsEditing(false)
  }

  const handleCancel = () => {
    setEditName(user.name)
    setEditBio(user.bio || '')
    setIsEditing(false)
  }

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      animate="visible"
      className="space-y-6 p-4 md:p-6 max-w-4xl mx-auto"
    >
      {/* Profile Header Card */}
      <motion.div variants={itemVariants}>
        <Card className="overflow-hidden">
          <div className="h-28 bg-gradient-to-r from-emerald-500/20 via-emerald-500/10 to-amber-500/10 relative">
            <div className="absolute inset-0 opacity-20" style={{
              backgroundImage: 'radial-gradient(circle at 20% 50%, rgba(16,185,129,0.3) 0%, transparent 50%), radial-gradient(circle at 80% 50%, rgba(245,158,11,0.2) 0%, transparent 50%)',
            }} />
          </div>
          <CardContent className="pt-0 pb-6 relative">
            <div className="flex flex-col sm:flex-row items-start sm:items-end gap-4 -mt-12">
              <Avatar className="h-24 w-24 border-4 border-card shadow-xl">
                <AvatarFallback className="bg-emerald-500/10 text-4xl border-2 border-emerald-500/30">
                  {avatarEmoji}
                </AvatarFallback>
              </Avatar>
              <div className="flex-1 min-w-0 sm:pb-1">
                {isEditing ? (
                  <div className="space-y-3 mt-2">
                    <div className="space-y-1.5">
                      <Label htmlFor="edit-name" className="text-xs">Name</Label>
                      <Input
                        id="edit-name"
                        value={editName}
                        onChange={(e) => setEditName(e.target.value)}
                        className="max-w-xs"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <Label htmlFor="edit-bio" className="text-xs">Bio</Label>
                      <Textarea
                        id="edit-bio"
                        value={editBio}
                        onChange={(e) => setEditBio(e.target.value)}
                        placeholder="Tell us about yourself..."
                        className="max-w-md resize-none"
                        rows={3}
                      />
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        size="sm"
                        onClick={handleSave}
                        disabled={saving}
                        className="bg-emerald-600 hover:bg-emerald-700"
                      >
                        {saving ? (
                          <>
                            <Loader2 className="w-3.5 h-3.5 mr-1.5 animate-spin" />
                            Saving...
                          </>
                        ) : (
                          <>
                            <Save className="w-3.5 h-3.5 mr-1.5" />
                            Save
                          </>
                        )}
                      </Button>
                      <Button size="sm" variant="outline" onClick={handleCancel}>
                        <X className="w-3.5 h-3.5 mr-1.5" />
                        Cancel
                      </Button>
                    </div>
                  </div>
                ) : (
                  <>
                    <div className="flex items-center gap-3 flex-wrap">
                      <h2 className="text-2xl font-bold tracking-tight">{user.name}</h2>
                      <Badge variant="secondary" className="capitalize">
                        {user.role}
                      </Badge>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setIsEditing(true)}
                        className="text-muted-foreground"
                      >
                        <Edit3 className="w-3.5 h-3.5 mr-1" />
                        Edit
                      </Button>
                    </div>
                    <div className="flex items-center gap-2 mt-1 text-sm text-muted-foreground">
                      <Mail className="w-3.5 h-3.5" />
                      {user.email}
                    </div>
                    {user.bio && (
                      <p className="mt-2 text-sm text-muted-foreground max-w-lg">
                        {user.bio}
                      </p>
                    )}
                  </>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Stats Section */}
      <motion.div variants={itemVariants}>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 md:gap-4">
          <ProfileStatCard
            icon={Coins}
            label="Total Points"
            value={user.points.toLocaleString()}
            color="amber"
          />
          <ProfileStatCard
            icon={Star}
            label="Level"
            value={user.level.toString()}
            color="emerald"
          />
          <ProfileStatCard
            icon={Flame}
            label="Streak"
            value={`${user.streak} days`}
            color="rose"
          />
          <ProfileStatCard
            icon={Calendar}
            label="Member Since"
            value={memberSince}
            color="slate"
          />
        </div>
      </motion.div>

      {/* Badges Showcase */}
      <motion.div variants={itemVariants}>
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-lg flex items-center gap-2">
                  <Trophy className="w-5 h-5 text-amber-500" />
                  Badges Collection
                </CardTitle>
                <CardDescription className="mt-1">
                  {earnedBadges.length} of {badges.length} badges earned
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {badges.length > 0 ? (
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                {badges.map((badge) => (
                  <motion.div
                    key={badge.id}
                    whileHover={{ scale: 1.03 }}
                    className={`flex flex-col items-center p-4 rounded-xl text-center transition-colors ${
                      badge.earned
                        ? 'bg-emerald-500/5 border border-emerald-500/20'
                        : 'bg-muted/30 opacity-50 grayscale'
                    }`}
                  >
                    <span className="text-3xl mb-2">{badge.icon || '🏅'}</span>
                    <p className="font-medium text-xs">{badge.name}</p>
                    <p className="text-[10px] text-muted-foreground mt-0.5 line-clamp-2">
                      {badge.description}
                    </p>
                    {badge.earned && (
                      <Badge
                        variant="secondary"
                        className="mt-2 text-[10px] bg-emerald-500/10 text-emerald-700 dark:text-emerald-400"
                      >
                        ✓ Earned
                      </Badge>
                    )}
                  </motion.div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12 text-muted-foreground">
                <Trophy className="w-12 h-12 mx-auto mb-3 opacity-30" />
                <p className="text-sm">No badges available yet.</p>
                <p className="text-xs mt-1">Start learning to earn your first badge!</p>
              </div>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </motion.div>
  )
}

/* ───── Profile Stat Card ───── */

function ProfileStatCard({
  icon: Icon,
  label,
  value,
  color,
}: {
  icon: React.ElementType
  label: string
  value: string
  color: 'amber' | 'emerald' | 'rose' | 'slate'
}) {
  const colorMap = {
    amber: { bg: 'bg-amber-500/10', icon: 'text-amber-600 dark:text-amber-400' },
    emerald: { bg: 'bg-emerald-500/10', icon: 'text-emerald-600 dark:text-emerald-400' },
    rose: { bg: 'bg-rose-500/10', icon: 'text-rose-600 dark:text-rose-400' },
    slate: { bg: 'bg-slate-500/10', icon: 'text-slate-600 dark:text-slate-400' },
  }
  const c = colorMap[color]

  return (
    <Card>
      <CardContent className="p-4 flex items-center gap-3">
        <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${c.bg}`}>
          <Icon className={`w-5 h-5 ${c.icon}`} />
        </div>
        <div>
          <p className="text-lg font-bold tracking-tight">{value}</p>
          <p className="text-xs text-muted-foreground">{label}</p>
        </div>
      </CardContent>
    </Card>
  )
}
