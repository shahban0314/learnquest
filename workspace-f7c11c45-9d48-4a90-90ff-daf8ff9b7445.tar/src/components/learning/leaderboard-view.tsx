'use client'

import { useEffect, useState } from 'react'
import { useLearningStore } from '@/store/learning-store'
import { Card, CardContent } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Avatar, AvatarFallback } from '@/components/ui/avatar'
import { Separator } from '@/components/ui/separator'
import {
  Trophy,
  Medal,
  Flame,
  TrendingUp,
  Crown,
} from 'lucide-react'
import { motion } from 'framer-motion'

const medalEmojis = ['🥇', '🥈', '🥉']

function LeaderboardSkeleton() {
  return (
    <div className="space-y-3">
      {Array.from({ length: 8 }).map((_, i) => (
        <Card key={i}>
          <CardContent className="p-4 flex items-center gap-4">
            <Skeleton className="size-8 rounded-full" />
            <Skeleton className="size-10 rounded-full" />
            <div className="flex-1">
              <Skeleton className="h-4 w-32 mb-1" />
              <Skeleton className="h-3 w-20" />
            </div>
            <Skeleton className="h-4 w-16" />
          </CardContent>
        </Card>
      ))}
    </div>
  )
}

export default function LeaderboardView() {
  const { leaderboard, user, fetchLeaderboard } = useLearningStore()
  const [period, setPeriod] = useState('all')

  useEffect(() => {
    fetchLeaderboard(period)
  }, [period, fetchLeaderboard])

  const currentUserEntry = leaderboard.find((entry) => entry.id === user?.id)

  const getRankStyle = (rank: number) => {
    switch (rank) {
      case 1:
        return 'bg-gradient-to-r from-amber-50 to-amber-100 dark:from-amber-900/20 dark:to-amber-800/20 border-amber-300 dark:border-amber-700'
      case 2:
        return 'bg-gradient-to-r from-slate-50 to-slate-100 dark:from-slate-800/30 dark:to-slate-700/30 border-slate-300 dark:border-slate-600'
      case 3:
        return 'bg-gradient-to-r from-orange-50 to-orange-100 dark:from-orange-900/20 dark:to-orange-800/20 border-orange-300 dark:border-orange-700'
      default:
        return ''
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight sm:text-3xl flex items-center gap-2">
          <Trophy className="size-7 text-amber-500" />
          Leaderboard
        </h1>
        <p className="text-muted-foreground mt-1">See how you stack up against other learners</p>
      </div>

      {/* Period Tabs */}
      <Tabs value={period} onValueChange={setPeriod}>
        <TabsList>
          <TabsTrigger value="weekly">Weekly</TabsTrigger>
          <TabsTrigger value="monthly">Monthly</TabsTrigger>
          <TabsTrigger value="all">All Time</TabsTrigger>
        </TabsList>
      </Tabs>

      {/* Current User Rank Card */}
      {currentUserEntry && (
        <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }}>
          <Card className="border-emerald-300 dark:border-emerald-700 bg-gradient-to-r from-emerald-50 to-teal-50 dark:from-emerald-900/20 dark:to-teal-900/20">
            <CardContent className="p-4">
              <div className="flex items-center gap-4">
                <div className="flex items-center justify-center size-10 rounded-full bg-emerald-100 dark:bg-emerald-900/40">
                  <span className="font-bold text-emerald-700 dark:text-emerald-300">
                    #{currentUserEntry.rank}
                  </span>
                </div>
                <Avatar className="size-10">
                  <AvatarFallback className="bg-emerald-100 text-emerald-700 dark:bg-emerald-900/40 dark:text-emerald-300 font-semibold">
                    {currentUserEntry.avatar || currentUserEntry.name.charAt(0).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-sm">{currentUserEntry.name} <span className="text-xs text-emerald-600 dark:text-emerald-400">(You)</span></p>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <span>Level {currentUserEntry.level}</span>
                    <span className="flex items-center gap-0.5">
                      <Flame className="size-3 text-rose-500" />
                      {currentUserEntry.streak} day streak
                    </span>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-bold text-amber-600 dark:text-amber-400">
                    {currentUserEntry.points.toLocaleString()}
                  </p>
                  <p className="text-xs text-muted-foreground">points</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      )}

      {/* Top 3 Podium */}
      {leaderboard.length >= 3 && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-3 gap-3"
        >
          {/* 2nd Place */}
          <Card className="order-1 sm:order-1 mt-6">
            <CardContent className="p-4 flex flex-col items-center text-center">
              <div className="text-3xl mb-1">🥈</div>
              <Avatar className="size-12 mb-2">
                <AvatarFallback className="bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 font-semibold">
                  {leaderboard[1].avatar || leaderboard[1].name.charAt(0).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <p className="font-semibold text-sm line-clamp-1">{leaderboard[1].name}</p>
              <p className="text-xs text-muted-foreground">Level {leaderboard[1].level}</p>
              <p className="text-sm font-bold text-amber-600 dark:text-amber-400 mt-1">
                {leaderboard[1].points.toLocaleString()}
              </p>
            </CardContent>
          </Card>

          {/* 1st Place */}
          <Card className="order-0 sm:order-0 border-amber-300 dark:border-amber-700">
            <CardContent className="p-4 flex flex-col items-center text-center">
              <Crown className="size-6 text-amber-500 mb-1" />
              <div className="text-3xl mb-1">🥇</div>
              <Avatar className="size-14 mb-2 ring-2 ring-amber-400">
                <AvatarFallback className="bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300 font-semibold">
                  {leaderboard[0].avatar || leaderboard[0].name.charAt(0).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <p className="font-semibold text-sm line-clamp-1">{leaderboard[0].name}</p>
              <p className="text-xs text-muted-foreground">Level {leaderboard[0].level}</p>
              <p className="text-sm font-bold text-amber-600 dark:text-amber-400 mt-1">
                {leaderboard[0].points.toLocaleString()}
              </p>
            </CardContent>
          </Card>

          {/* 3rd Place */}
          <Card className="order-2 sm:order-2 mt-8">
            <CardContent className="p-4 flex flex-col items-center text-center">
              <div className="text-3xl mb-1">🥉</div>
              <Avatar className="size-12 mb-2">
                <AvatarFallback className="bg-orange-100 text-orange-700 dark:bg-orange-900/40 dark:text-orange-300 font-semibold">
                  {leaderboard[2].avatar || leaderboard[2].name.charAt(0).toUpperCase()}
                </AvatarFallback>
              </Avatar>
              <p className="font-semibold text-sm line-clamp-1">{leaderboard[2].name}</p>
              <p className="text-xs text-muted-foreground">Level {leaderboard[2].level}</p>
              <p className="text-sm font-bold text-amber-600 dark:text-amber-400 mt-1">
                {leaderboard[2].points.toLocaleString()}
              </p>
            </CardContent>
          </Card>
        </motion.div>
      )}

      <Separator />

      {/* Full Leaderboard List */}
      {leaderboard.length === 0 ? (
        <LeaderboardSkeleton />
      ) : (
        <div className="space-y-2">
          {leaderboard.map((entry, index) => {
            const isCurrentUser = entry.id === user?.id
            const rankStyle = getRankStyle(entry.rank)

            return (
              <motion.div
                key={entry.id}
                initial={{ opacity: 0, x: -10 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.03 }}
              >
                <Card className={`${rankStyle} ${isCurrentUser ? 'ring-2 ring-emerald-400 dark:ring-emerald-600' : ''} transition-all hover:shadow-sm`}>
                  <CardContent className="p-3 sm:p-4">
                    <div className="flex items-center gap-3 sm:gap-4">
                      {/* Rank */}
                      <div className="w-8 flex items-center justify-center shrink-0">
                        {entry.rank <= 3 ? (
                          <span className="text-xl">{medalEmojis[entry.rank - 1]}</span>
                        ) : (
                          <span className="text-sm font-semibold text-muted-foreground">
                            #{entry.rank}
                          </span>
                        )}
                      </div>

                      {/* Avatar */}
                      <Avatar className="size-9 sm:size-10">
                        <AvatarFallback className={`font-semibold ${
                          entry.rank === 1
                            ? 'bg-amber-100 text-amber-700 dark:bg-amber-900/40 dark:text-amber-300'
                            : entry.rank === 2
                              ? 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                              : entry.rank === 3
                                ? 'bg-orange-100 text-orange-700 dark:bg-orange-900/40 dark:text-orange-300'
                                : 'bg-muted text-muted-foreground'
                        }`}>
                          {entry.avatar || entry.name.charAt(0).toUpperCase()}
                        </AvatarFallback>
                      </Avatar>

                      {/* Name & Details */}
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-sm truncate">
                          {entry.name}
                          {isCurrentUser && (
                            <span className="text-xs text-emerald-600 dark:text-emerald-400 ml-1">(You)</span>
                          )}
                        </p>
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <span>Level {entry.level}</span>
                          <span className="flex items-center gap-0.5">
                            <Flame className="size-3 text-rose-500" />
                            {entry.streak}
                          </span>
                        </div>
                      </div>

                      {/* Points */}
                      <div className="text-right shrink-0">
                        <p className="font-bold text-sm text-amber-600 dark:text-amber-400">
                          {entry.points.toLocaleString()}
                        </p>
                        <p className="text-[10px] text-muted-foreground">points</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )
          })}
        </div>
      )}
    </div>
  )
}
