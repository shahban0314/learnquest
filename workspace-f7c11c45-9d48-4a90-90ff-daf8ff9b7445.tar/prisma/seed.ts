import { PrismaClient } from '@prisma/client'

const prisma = new PrismaClient()

async function main() {
  console.log('🌱 Seeding database...')

  // Clean existing data (in reverse dependency order)
  console.log('🧹 Cleaning existing data...')
  await prisma.recommendation.deleteMany()
  await prisma.bookmark.deleteMany()
  await prisma.userChallenge.deleteMany()
  await prisma.userBadge.deleteMany()
  await prisma.quizAttempt.deleteMany()
  await prisma.userProgress.deleteMany()
  await prisma.question.deleteMany()
  await prisma.quiz.deleteMany()
  await prisma.lesson.deleteMany()
  await prisma.topic.deleteMany()
  await prisma.course.deleteMany()
  await prisma.badge.deleteMany()
  await prisma.challenge.deleteMany()
  await prisma.user.deleteMany()

  // ==================== USERS ====================
  console.log('👤 Creating users...')
  const student = await prisma.user.create({
    data: {
      email: 'student@learn.com',
      name: 'Alex Student',
      password: 'password123',
      role: 'student',
      avatar: '🧑‍🎓',
      points: 750,
      streak: 5,
      lastLoginDate: new Date().toISOString().split('T')[0],
      level: 7,
      bio: 'A passionate learner exploring various subjects. Love math and science!',
    },
  })

  const teacher = await prisma.user.create({
    data: {
      email: 'teacher@learn.com',
      name: 'Dr. Sarah Teacher',
      password: 'password123',
      role: 'teacher',
      avatar: '👩‍🏫',
      points: 2500,
      level: 15,
      bio: 'Experienced educator with a PhD in Applied Mathematics. Teaching is my passion.',
    },
  })

  const admin = await prisma.user.create({
    data: {
      email: 'admin@learn.com',
      name: 'Admin User',
      password: 'password123',
      role: 'admin',
      avatar: '🔐',
      points: 5000,
      level: 20,
      bio: 'Platform administrator ensuring the best learning experience for everyone.',
    },
  })

  console.log(`  ✅ Created 3 users`)

  // ==================== COURSES, TOPICS, LESSONS ====================
  console.log('📚 Creating courses, topics, and lessons...')

  // ---- Course 1: Algebra ----
  const algebra = await prisma.course.create({
    data: {
      title: 'Algebra Fundamentals',
      description: 'Master the building blocks of algebra, from basic equations to complex polynomials. This course provides a solid foundation for all higher mathematics.',
      category: 'Mathematics',
      difficulty: 'beginner',
      duration: '8 weeks',
      rating: 4.7,
      enrolledCount: 1243,
    },
  })

  const algTopic1 = await prisma.topic.create({
    data: {
      name: 'Linear Equations',
      description: 'Understanding and solving linear equations with one variable',
      order: 1,
      courseId: algebra.id,
    },
  })

  const algTopic2 = await prisma.topic.create({
    data: {
      name: 'Quadratic Equations',
      description: 'Solving quadratic equations using various methods',
      order: 2,
      courseId: algebra.id,
    },
  })

  const algTopic3 = await prisma.topic.create({
    data: {
      name: 'Polynomials',
      description: 'Working with polynomial expressions and factoring',
      order: 3,
      courseId: algebra.id,
    },
  })

  // Linear Equations lessons
  await prisma.lesson.create({
    data: {
      title: 'Introduction to Variables and Expressions',
      content: `Variables are the cornerstone of algebra. A variable is a symbol, usually a letter like x, y, or z, that represents an unknown value. Algebraic expressions combine variables, numbers, and operations to describe mathematical relationships.\n\nFor example, the expression "3x + 5" means "three times some number x, plus five." When we write "2x - 7," we mean "two times some number x, minus seven." These expressions become powerful tools when we set them equal to something — that's when we get equations.\n\nAn equation is a statement that two expressions are equal, like 3x + 5 = 20. The goal in algebra is often to "solve" the equation — to find the value of the variable that makes the statement true. In this case, x = 5 because 3(5) + 5 = 20.\n\nUnderstanding how to translate real-world problems into algebraic expressions is a critical skill. If a movie ticket costs $12 and you have $50, the expression 50 - 12x represents how much money you have left after buying x tickets.`,
      type: 'text',
      order: 1,
      difficulty: 'beginner',
      duration: 15,
      topicId: algTopic1.id,
    },
  })

  await prisma.lesson.create({
    data: {
      title: 'Solving One-Step Equations',
      content: `A one-step equation can be solved with a single operation — addition, subtraction, multiplication, or division. The key principle is that whatever you do to one side of the equation, you must do to the other side to maintain balance.\n\nFor addition equations like x + 7 = 15, subtract 7 from both sides: x = 15 - 7 = 8.\nFor subtraction equations like x - 4 = 9, add 4 to both sides: x = 9 + 4 = 13.\nFor multiplication equations like 5x = 35, divide both sides by 5: x = 35 ÷ 5 = 7.\nFor division equations like x/3 = 6, multiply both sides by 3: x = 6 × 3 = 18.\n\nAlways check your answer by substituting it back into the original equation. If x + 7 = 15 and x = 8, then 8 + 7 = 15 ✓. This verification step helps catch errors and builds confidence in your solution.`,
      type: 'text',
      order: 2,
      difficulty: 'beginner',
      duration: 20,
      topicId: algTopic1.id,
    },
  })

  await prisma.lesson.create({
    data: {
      title: 'Solving Multi-Step Equations',
      content: `Multi-step equations require two or more operations to isolate the variable. The general strategy is to simplify both sides first, then move all variable terms to one side and all constants to the other.\n\nStep 1: Simplify each side by distributing and combining like terms.\nStep 2: Move all variable terms to one side using addition or subtraction.\nStep 3: Move all constant terms to the other side.\nStep 4: Isolate the variable by dividing or multiplying.\n\nExample: Solve 3(x + 2) - 4 = 2x + 7\n1. Distribute: 3x + 6 - 4 = 2x + 7\n2. Combine like terms: 3x + 2 = 2x + 7\n3. Subtract 2x from both sides: x + 2 = 7\n4. Subtract 2 from both sides: x = 5\n\nCommon mistakes to avoid: forgetting to distribute to all terms inside parentheses, and forgetting to apply operations to both sides of the equation. Always verify your solution by substituting back into the original equation.`,
      type: 'text',
      order: 3,
      difficulty: 'intermediate',
      duration: 25,
      topicId: algTopic1.id,
    },
  })

  await prisma.lesson.create({
    data: {
      title: 'Equations with Fractions and Decimals',
      content: `Equations containing fractions can look intimidating, but a simple technique makes them manageable: multiply every term by the least common denominator (LCD) to eliminate all fractions at once.\n\nExample: Solve x/3 + x/4 = 7\nThe LCD of 3 and 4 is 12. Multiply every term by 12:\n12(x/3) + 12(x/4) = 12(7)\n4x + 3x = 84\n7x = 84\nx = 12\n\nFor decimal equations, you can multiply every term by a power of 10 to convert to whole numbers. For 0.3x + 1.5 = 0.9, multiply by 10: 3x + 15 = 9, so 3x = -6, x = -2.\n\nWhen working with mixed fractions, convert them to improper fractions first. For instance, 2½ becomes 5/2. This standardization makes finding the LCD and performing calculations much cleaner.\n\nRemember: the goal is always to simplify the equation first, then solve using the standard techniques for multi-step equations.`,
      type: 'text',
      order: 4,
      difficulty: 'intermediate',
      duration: 20,
      topicId: algTopic1.id,
    },
  })

  // Quadratic Equations lessons
  await prisma.lesson.create({
    data: {
      title: 'Introduction to Quadratic Equations',
      content: `A quadratic equation is any equation that can be written in the standard form ax² + bx + c = 0, where a, b, and c are constants and a ≠ 0. The "quadratic" part comes from the Latin "quadratus" meaning square — these equations involve a variable raised to the second power.\n\nQuadratic equations appear everywhere in real life: calculating the trajectory of a thrown ball, determining the area of a rectangular garden with a fixed perimeter, modeling profit optimization in business, and even in computer graphics for rendering curves.\n\nThe graph of a quadratic equation y = ax² + bx + c is a parabola. If a > 0, the parabola opens upward (like a smile). If a < 0, it opens downward (like a frown). The highest or lowest point of the parabola is called the vertex, and the vertical line passing through the vertex is the axis of symmetry.\n\nA quadratic equation can have 0, 1, or 2 real solutions (also called roots). These correspond to where the parabola crosses the x-axis. We'll explore multiple methods for finding these solutions in the following lessons.`,
      type: 'text',
      order: 1,
      difficulty: 'beginner',
      duration: 20,
      topicId: algTopic2.id,
    },
  })

  await prisma.lesson.create({
    data: {
      title: 'Factoring Quadratic Equations',
      content: `Factoring is often the quickest way to solve a quadratic equation, especially when the coefficients are small integers. The method relies on the Zero Product Property: if ab = 0, then either a = 0 or b = 0.\n\nFor a quadratic x² + bx + c, we look for two numbers that multiply to give c and add to give b. For example, to factor x² + 7x + 12 = 0, we need two numbers that multiply to 12 and add to 7. Those numbers are 3 and 4, so: (x + 3)(x + 4) = 0, giving x = -3 or x = -4.\n\nFor quadratics with a leading coefficient, like 2x² + 7x + 3, use the AC method: multiply a and c (2 × 3 = 6), find two numbers that multiply to 6 and add to 7 (6 and 1), then rewrite and factor by grouping: 2x² + 6x + x + 3 = 2x(x + 3) + 1(x + 3) = (2x + 1)(x + 3) = 0.\n\nNot all quadratics factor nicely — that's when we need other methods like the quadratic formula, which we'll cover next.`,
      type: 'text',
      order: 2,
      difficulty: 'intermediate',
      duration: 25,
      topicId: algTopic2.id,
    },
  })

  await prisma.lesson.create({
    data: {
      title: 'The Quadratic Formula',
      content: `The quadratic formula is a universal method that works for ANY quadratic equation ax² + bx + c = 0:\n\nx = (-b ± √(b² - 4ac)) / 2a\n\nThe expression under the square root, b² - 4ac, is called the discriminant. It tells us about the nature of the solutions:\n\n• If b² - 4ac > 0: Two distinct real solutions\n• If b² - 4ac = 0: One repeated real solution (the parabola just touches the x-axis)\n• If b² - 4ac < 0: No real solutions (two complex solutions)\n\nExample: Solve 2x² - 5x - 3 = 0\na = 2, b = -5, c = -3\nDiscriminant = (-5)² - 4(2)(-3) = 25 + 24 = 49\nx = (5 ± √49) / 4 = (5 ± 7) / 4\nx = 3 or x = -1/2\n\nThe quadratic formula is derived by completing the square on the general form ax² + bx + c = 0. While it may look complex, memorizing this formula gives you a reliable tool that never fails.`,
      type: 'text',
      order: 3,
      difficulty: 'intermediate',
      duration: 30,
      topicId: algTopic2.id,
    },
  })

  // Polynomials lessons
  await prisma.lesson.create({
    data: {
      title: 'Understanding Polynomials',
      content: `A polynomial is an expression made up of variables and coefficients, using only addition, subtraction, multiplication, and non-negative integer exponents. Examples include 3x² + 2x - 1, 5y⁴ - 3y² + 7, and even simple expressions like 4x or the constant 8.\n\nKey terminology:\n• Term: each part of the polynomial separated by + or - (e.g., 3x², 2x, -1)\n• Coefficient: the number in front of a variable (3 in 3x²)\n• Degree: the highest exponent in the polynomial (2 in 3x² + 2x - 1)\n• Leading coefficient: the coefficient of the highest-degree term (3 in 3x² + 2x - 1)\n• Constant term: the term without a variable (-1)\n\nPolynomials are classified by degree: constant (0), linear (1), quadratic (2), cubic (3), quartic (4), and so on. They can also be classified by the number of terms: monomial (1 term), binomial (2 terms), trinomial (3 terms).\n\nPolynomials are fundamental in mathematics because they can approximate many other functions, and they have nice properties that make them easy to work with — they're continuous, differentiable, and integrable everywhere.`,
      type: 'text',
      order: 1,
      difficulty: 'beginner',
      duration: 20,
      topicId: algTopic3.id,
    },
  })

  await prisma.lesson.create({
    data: {
      title: 'Adding and Subtracting Polynomials',
      content: `Adding and subtracting polynomials involves combining like terms — terms that have the same variables raised to the same powers. The process is straightforward once you identify which terms can be combined.\n\nAddition: (3x² + 2x - 5) + (x² - 4x + 3) = (3x² + x²) + (2x - 4x) + (-5 + 3) = 4x² - 2x - 2\n\nSubtraction: (3x² + 2x - 5) - (x² - 4x + 3) — remember to distribute the negative sign! = 3x² + 2x - 5 - x² + 4x - 3 = 2x² + 6x - 8\n\nA common error in subtraction is forgetting to change the sign of every term in the polynomial being subtracted. Always distribute the negative sign to each term before combining. Writing out the intermediate step explicitly can help prevent this mistake.\n\nWhen working with polynomials in multiple variables, only combine terms with identical variable parts. For example, 3xy² and 5xy² are like terms, but 3xy² and 3x²y are not — even though they have the same variables, the exponents are in different positions.`,
      type: 'text',
      order: 2,
      difficulty: 'beginner',
      duration: 15,
      topicId: algTopic3.id,
    },
  })

  await prisma.lesson.create({
    data: {
      title: 'Factoring Polynomials',
      content: `Factoring a polynomial means expressing it as a product of simpler polynomials. This is the reverse of multiplying polynomials and is essential for solving equations and simplifying expressions.\n\nCommon factoring techniques:\n\n1. Greatest Common Factor (GCF): Always check this first! 6x³ + 9x² = 3x²(2x + 3)\n\n2. Grouping: For four-term polynomials, group pairs and factor each group. ax + ay + bx + by = a(x + y) + b(x + y) = (a + b)(x + y)\n\n3. Difference of Squares: a² - b² = (a + b)(a - b). Example: x² - 25 = (x + 5)(x - 5)\n\n4. Perfect Square Trinomials: a² + 2ab + b² = (a + b)² and a² - 2ab + b² = (a - b)². Example: x² + 6x + 9 = (x + 3)²\n\n5. General Trinomials (x² + bx + c): Find two numbers that multiply to c and add to b. Example: x² + 5x + 6 = (x + 2)(x + 3)\n\nStrategy: Always factor out the GCF first, then look for other patterns. Keep factoring until no polynomial factor can be factored further — this is called "factoring completely."`,
      type: 'text',
      order: 3,
      difficulty: 'intermediate',
      duration: 25,
      topicId: algTopic3.id,
    },
  })

  // ---- Course 2: Calculus ----
  const calculus = await prisma.course.create({
    data: {
      title: 'Calculus: Limits and Derivatives',
      description: 'Discover the elegant world of calculus, from the concept of limits to the power of derivatives. Learn how to analyze change and motion mathematically.',
      category: 'Mathematics',
      difficulty: 'advanced',
      duration: '12 weeks',
      rating: 4.5,
      enrolledCount: 892,
    },
  })

  const calcTopic1 = await prisma.topic.create({
    data: {
      name: 'Limits and Continuity',
      description: 'Understanding the fundamental concept of limits and continuous functions',
      order: 1,
      courseId: calculus.id,
    },
  })

  const calcTopic2 = await prisma.topic.create({
    data: {
      name: 'Introduction to Derivatives',
      description: 'Learning the concept of derivatives and basic differentiation rules',
      order: 2,
      courseId: calculus.id,
    },
  })

  const calcTopic3 = await prisma.topic.create({
    data: {
      name: 'Applications of Derivatives',
      description: 'Using derivatives to solve real-world optimization and rate problems',
      order: 3,
      courseId: calculus.id,
    },
  })

  // Limits lessons
  await prisma.lesson.create({
    data: {
      title: 'The Concept of a Limit',
      content: `The limit is the foundational concept of calculus. When we write lim(x→a) f(x) = L, we mean that as x gets closer and closer to a (but never actually reaches a), the function f(x) gets closer and closer to L.\n\nConsider f(x) = (x² - 1)/(x - 1). At x = 1, this function is undefined (0/0). But what happens as x approaches 1? If we factor the numerator: (x² - 1)/(x - 1) = (x + 1)(x - 1)/(x - 1) = x + 1 (for x ≠ 1). So as x approaches 1, f(x) approaches 2.\n\nLimits can be approached from the left (x → a⁻) or from the right (x → a⁺). For a limit to exist, both one-sided limits must exist and be equal. If lim(x→a⁻) f(x) ≠ lim(x→a⁺) f(x), then lim(x→a) f(x) does not exist.\n\nSome limits go to infinity: lim(x→0) 1/x² = ∞, meaning the function grows without bound. This is different from a limit that does not exist — the function has a definite behavior (growing), just not approaching a finite number.`,
      type: 'text',
      order: 1,
      difficulty: 'advanced',
      duration: 30,
      topicId: calcTopic1.id,
    },
  })

  await prisma.lesson.create({
    data: {
      title: 'Limit Laws and Techniques',
      content: `Calculating limits is made easier by a set of established rules. These limit laws allow us to break complex limits into simpler parts:\n\n1. Sum Rule: lim[f(x) + g(x)] = lim f(x) + lim g(x)\n2. Difference Rule: lim[f(x) - g(x)] = lim f(x) - lim g(x)\n3. Product Rule: lim[f(x) · g(x)] = lim f(x) · lim g(x)\n4. Quotient Rule: lim[f(x)/g(x)] = lim f(x) / lim g(x), provided lim g(x) ≠ 0\n5. Power Rule: lim[f(x)]ⁿ = [lim f(x)]ⁿ\n\nFor indeterminate forms (0/0 or ∞/∞), L'Hôpital's Rule states that if lim(x→a) f(x)/g(x) is indeterminate, then:\nlim(x→a) f(x)/g(x) = lim(x→a) f'(x)/g'(x)\n\nThis powerful rule can be applied repeatedly if the resulting limit is still indeterminate. Other techniques include factoring, rationalizing, and using squeeze theorem for limits that are difficult to evaluate directly.`,
      type: 'text',
      order: 2,
      difficulty: 'advanced',
      duration: 35,
      topicId: calcTopic1.id,
    },
  })

  await prisma.lesson.create({
    data: {
      title: 'Continuity of Functions',
      content: `A function f is continuous at a point a if three conditions are met:\n1. f(a) is defined\n2. lim(x→a) f(x) exists\n3. lim(x→a) f(x) = f(a)\n\nIn intuitive terms, you can draw a continuous function without lifting your pen from the paper. Discontinuities come in three types:\n\n• Removable discontinuity (a hole): The limit exists but doesn't equal f(a), or f(a) is undefined. Example: f(x) = (x²-1)/(x-1) at x = 1.\n\n• Jump discontinuity: The left and right limits exist but are not equal. Example: step functions like the Heaviside function.\n\n• Infinite discontinuity: The function goes to ±∞. Example: f(x) = 1/x at x = 0.\n\nThe Intermediate Value Theorem (IVT) states that if f is continuous on [a, b] and k is any number between f(a) and f(b), then there exists c in (a, b) such that f(c) = k. This theorem guarantees that continuous functions take on every intermediate value, which has profound implications for root-finding and optimization.`,
      type: 'text',
      order: 3,
      difficulty: 'advanced',
      duration: 30,
      topicId: calcTopic1.id,
    },
  })

  // Derivatives lessons
  await prisma.lesson.create({
    data: {
      title: 'The Derivative as a Rate of Change',
      content: `The derivative measures how a function changes as its input changes — it's the instantaneous rate of change at a specific point. Formally, the derivative of f at point a is:\n\nf'(a) = lim(h→0) [f(a + h) - f(a)] / h\n\nThis is called the limit definition of the derivative. Geometrically, f'(a) gives the slope of the tangent line to the graph of f at the point (a, f(a)).\n\nReal-world examples:\n• If s(t) represents position at time t, then s'(t) = v(t) is velocity\n• If v(t) represents velocity, then v'(t) = a(t) is acceleration\n• If C(x) represents the cost of producing x items, then C'(x) is the marginal cost\n• If P(t) represents population, then P'(t) is the population growth rate\n\nNotation: The derivative can be written as f'(x), y', dy/dx, or df/dx — all equivalent. The notation dy/dx, introduced by Leibniz, emphasizes that the derivative is a ratio of infinitesimal changes.`,
      type: 'text',
      order: 1,
      difficulty: 'advanced',
      duration: 30,
      topicId: calcTopic2.id,
    },
  })

  await prisma.lesson.create({
    data: {
      title: 'Basic Differentiation Rules',
      content: `Once you understand the concept, memorizing these rules makes differentiation efficient:\n\n1. Constant Rule: d/dx[c] = 0 (constants don't change)\n2. Power Rule: d/dx[xⁿ] = nxⁿ⁻¹ (the most-used rule!)\n3. Constant Multiple Rule: d/dx[cf(x)] = c · f'(x)\n4. Sum/Difference Rule: d/dx[f(x) ± g(x)] = f'(x) ± g'(x)\n5. Product Rule: d/dx[f(x)g(x)] = f'(x)g(x) + f(x)g'(x)\n6. Quotient Rule: d/dx[f(x)/g(x)] = [f'(x)g(x) - f(x)g'(x)] / [g(x)]²\n7. Chain Rule: d/dx[f(g(x))] = f'(g(x)) · g'(x)\n\nExamples using the Power Rule:\n• d/dx[x³] = 3x²\n• d/dx[x⁵] = 5x⁴\n• d/dx[√x] = d/dx[x^(1/2)] = (1/2)x^(-1/2) = 1/(2√x)\n• d/dx[1/x²] = d/dx[x^(-2)] = -2x^(-3) = -2/x³\n\nThe chain rule is especially powerful for composite functions like sin(x²), where we differentiate the outer function (sin) and multiply by the derivative of the inner function (2x).`,
      type: 'text',
      order: 2,
      difficulty: 'advanced',
      duration: 35,
      topicId: calcTopic2.id,
    },
  })

  await prisma.lesson.create({
    data: {
      title: 'Derivatives of Trigonometric Functions',
      content: `The derivatives of the six trigonometric functions are essential to memorize:\n\n• d/dx[sin(x)] = cos(x)\n• d/dx[cos(x)] = -sin(x)\n• d/dx[tan(x)] = sec²(x)\n• d/dx[cot(x)] = -csc²(x)\n• d/dx[sec(x)] = sec(x)tan(x)\n• d/dx[csc(x)] = -csc(x)cot(x)\n\nNotice the pattern: the three "co-" functions (cosine, cotangent, cosecant) all have negative derivatives. This isn't a coincidence — it comes from the co-function identities.\n\nCombined with the chain rule, these become incredibly versatile. For example:\n• d/dx[sin(3x)] = cos(3x) · 3 = 3cos(3x)\n• d/dx[cos(x²)] = -sin(x²) · 2x = -2x·sin(x²)\n• d/dx[tan²(x)] = 2tan(x) · sec²(x)\n\nTrigonometric derivatives are crucial in physics (describing oscillations and waves), engineering (signal processing), and many other fields. Simple harmonic motion, alternating current, and sound waves all involve sine and cosine functions whose derivatives describe their behavior over time.`,
      type: 'text',
      order: 3,
      difficulty: 'advanced',
      duration: 30,
      topicId: calcTopic2.id,
    },
  })

  // Applications of Derivatives lessons
  await prisma.lesson.create({
    data: {
      title: 'Finding Maxima and Minima',
      content: `One of the most practical applications of derivatives is finding maximum and minimum values of functions. A critical point occurs where f'(x) = 0 or f'(x) is undefined.\n\nThe First Derivative Test:\n• If f'(x) changes from positive to negative at a critical point → local maximum\n• If f'(x) changes from negative to positive at a critical point → local minimum\n• If f'(x) doesn't change sign → neither max nor min (inflection point)\n\nThe Second Derivative Test:\n• If f'(c) = 0 and f''(c) < 0 → local maximum at c\n• If f'(c) = 0 and f''(c) > 0 → local minimum at c\n• If f''(c) = 0 → test is inconclusive, use First Derivative Test\n\nFor absolute (global) extrema on a closed interval [a, b]:\n1. Find all critical points in (a, b)\n2. Evaluate f at each critical point\n3. Evaluate f(a) and f(b)\n4. The largest value is the absolute max; the smallest is the absolute min\n\nThis technique is essential for optimization problems: maximizing profit, minimizing cost, finding the most efficient shape, and countless other real-world applications.`,
      type: 'text',
      order: 1,
      difficulty: 'advanced',
      duration: 35,
      topicId: calcTopic3.id,
    },
  })

  await prisma.lesson.create({
    data: {
      title: 'Optimization Problems',
      content: `Optimization is the process of finding the best solution from all feasible solutions. In calculus, we use derivatives to find the maximum or minimum value that a function can achieve.\n\nGeneral strategy for optimization problems:\n1. Draw a diagram and identify what's given and what's unknown\n2. Write an equation for the quantity to be optimized\n3. If the equation has multiple variables, use a constraint to eliminate one\n4. Find the domain of the function\n5. Find critical points by setting the derivative equal to zero\n6. Use the first or second derivative test to confirm max/min\n7. Verify the answer makes physical sense\n\nClassic example: A farmer has 100 feet of fencing to enclose a rectangular garden. What dimensions give the maximum area?\n• Constraint: 2L + 2W = 100, so W = 50 - L\n• Area: A = L × W = L(50 - L) = 50L - L²\n• A'(L) = 50 - 2L = 0 → L = 25\n• W = 25, so the maximum area is 625 sq ft (a square!)\n\nThe fact that a square maximizes area for a given perimeter is a beautiful result that appears throughout mathematics and nature.`,
      type: 'text',
      order: 2,
      difficulty: 'advanced',
      duration: 40,
      topicId: calcTopic3.id,
    },
  })

  await prisma.lesson.create({
    data: {
      title: 'Related Rates',
      content: `Related rates problems involve finding the rate at which one quantity changes by relating it to other quantities whose rates of change are known. The key is to find an equation connecting the variables, then differentiate with respect to time.\n\nGeneral approach:\n1. Draw a diagram and label variables\n2. Write down what you know and what you need to find\n3. Find an equation relating the variables\n4. Differentiate both sides with respect to time t (using chain rule!)\n5. Substitute known values and solve for the unknown rate\n\nClassic example: A 10-foot ladder leans against a wall. The bottom slides away at 1 ft/s. How fast is the top sliding down when the bottom is 6 feet from the wall?\n• x² + y² = 100 (Pythagorean theorem)\n• 2x(dx/dt) + 2y(dy/dt) = 0\n• When x = 6: y = 8, dx/dt = 1\n• 2(6)(1) + 2(8)(dy/dt) = 0\n• dy/dt = -6/8 = -3/4 ft/s (negative because y is decreasing)\n\nImportant: Don't substitute numerical values until AFTER differentiating! Substituting too early eliminates the variables you need for the chain rule.`,
      type: 'text',
      order: 3,
      difficulty: 'advanced',
      duration: 35,
      topicId: calcTopic3.id,
    },
  })

  // ---- Course 3: Physics ----
  const physics = await prisma.course.create({
    data: {
      title: 'Physics: Mechanics and Motion',
      description: 'Explore the fundamental laws governing motion, forces, and energy. From Newton\'s laws to conservation principles, understand how the physical world works.',
      category: 'Science',
      difficulty: 'intermediate',
      duration: '10 weeks',
      rating: 4.6,
      enrolledCount: 1056,
    },
  })

  const physTopic1 = await prisma.topic.create({
    data: {
      name: 'Kinematics',
      description: 'Describing motion without considering its causes',
      order: 1,
      courseId: physics.id,
    },
  })

  const physTopic2 = await prisma.topic.create({
    data: {
      name: 'Newton\'s Laws of Motion',
      description: 'Understanding forces and how they affect motion',
      order: 2,
      courseId: physics.id,
    },
  })

  const physTopic3 = await prisma.topic.create({
    data: {
      name: 'Energy and Work',
      description: 'Conservation of energy and the work-energy theorem',
      order: 3,
      courseId: physics.id,
    },
  })

  // Kinematics lessons
  await prisma.lesson.create({
    data: {
      title: 'Describing Motion: Displacement, Velocity, and Acceleration',
      content: `Kinematics is the branch of physics that describes motion without considering what causes it. Three fundamental quantities define motion:\n\nDisplacement (Δx) is the change in position — a vector quantity with both magnitude and direction. If you walk 3 meters east then 1 meter west, your displacement is 2 meters east, even though you walked 4 meters total (distance).\n\nVelocity (v) is the rate of change of displacement: v = Δx/Δt. Average velocity considers the entire trip, while instantaneous velocity is the velocity at a specific moment (the derivative of position with respect to time). Velocity is also a vector — 30 m/s north is different from 30 m/s south.\n\nAcceleration (a) is the rate of change of velocity: a = Δv/Δt. When you press the gas pedal, you accelerate forward. When you brake, you accelerate backward (decelerate). Even turning involves acceleration because velocity's direction changes, even if its magnitude stays constant.\n\nSI Units: displacement in meters (m), velocity in meters per second (m/s), acceleration in meters per second squared (m/s²). These units chain logically: m → m/s → m/s², each representing the rate of change of the previous quantity.`,
      type: 'text',
      order: 1,
      difficulty: 'intermediate',
      duration: 25,
      topicId: physTopic1.id,
    },
  })

  await prisma.lesson.create({
    data: {
      title: 'Equations of Motion (Constant Acceleration)',
      content: `When acceleration is constant, four powerful kinematic equations allow us to predict an object's motion:\n\n1. v = v₀ + at — relates velocity, acceleration, and time\n2. x = x₀ + v₀t + ½at² — relates position, velocity, acceleration, and time\n3. v² = v₀² + 2a(x - x₀) — relates velocity, acceleration, and displacement (no time!)\n4. x = x₀ + ½(v₀ + v)t — relates position, velocities, and time\n\nWhere: v₀ = initial velocity, v = final velocity, a = acceleration, t = time, x₀ = initial position, x = final position.\n\nExample: A car traveling at 20 m/s applies brakes with deceleration of 5 m/s². How far does it travel before stopping?\nUsing equation 3: 0² = 20² + 2(-5)(x - 0)\n0 = 400 - 10x\nx = 40 meters\n\nThese equations only work for constant acceleration! For variable acceleration, calculus is needed. Also, remember that free fall near Earth's surface has constant acceleration g ≈ 9.8 m/s² downward, making these equations perfect for projectile problems.`,
      type: 'text',
      order: 2,
      difficulty: 'intermediate',
      duration: 25,
      topicId: physTopic1.id,
    },
  })

  await prisma.lesson.create({
    data: {
      title: 'Projectile Motion',
      content: `Projectile motion is the motion of an object launched into the air and moving under the influence of gravity alone (ignoring air resistance). The key insight is that horizontal and vertical motions are independent.\n\nHorizontal: No acceleration (aₓ = 0), so x = x₀ + v₀ₓt. The horizontal velocity remains constant.\n\nVertical: Constant downward acceleration (ay = -g), so the vertical motion follows the kinematic equations with a = -g.\n\nProblem-solving strategy:\n1. Resolve the initial velocity into components: v₀ₓ = v₀cos(θ) and v₀ᵧ = v₀sin(θ)\n2. Treat horizontal and vertical motions separately\n3. Time (t) is the same for both — it's the link between them\n4. At the maximum height, the vertical velocity is zero\n5. The range is maximized at a launch angle of 45°\n\nExample: A ball is launched at 30 m/s at 37° above horizontal. Find the maximum height and range.\n• v₀ₓ = 30cos(37°) ≈ 24 m/s, v₀ᵧ = 30sin(37°) ≈ 18 m/s\n• Max height: at top vᵧ = 0, so 0 = 18² - 2(9.8)h → h ≈ 16.5 m\n• Time of flight: 0 = 18t - 4.9t² → t ≈ 3.67 s\n• Range: x = 24(3.67) ≈ 88.1 m`,
      type: 'text',
      order: 3,
      difficulty: 'intermediate',
      duration: 30,
      topicId: physTopic1.id,
    },
  })

  // Newton's Laws lessons
  await prisma.lesson.create({
    data: {
      title: 'Newton\'s First and Second Laws',
      content: `Newton's First Law (Law of Inertia): An object at rest stays at rest, and an object in motion stays in motion with the same speed and direction, unless acted upon by an unbalanced force. This means objects naturally resist changes in their state of motion — this resistance is called inertia, and mass is its measure.\n\nNewton's Second Law: F = ma. The acceleration of an object is directly proportional to the net force acting on it and inversely proportional to its mass. This is perhaps the most important equation in classical mechanics.\n\nKey implications:\n• If the net force is zero, acceleration is zero (consistent with the First Law)\n• More force → more acceleration (for the same mass)\n• More mass → less acceleration (for the same force)\n• Force and acceleration are vectors — they have direction\n\nProblem-solving with F = ma:\n1. Identify the object and all forces acting on it (free body diagram)\n2. Choose a coordinate system\n3. Write F = ma for each direction separately\n4. Solve the system of equations\n\nThe unit of force is the Newton (N): 1 N = 1 kg · m/s². A 1 kg mass experiencing a 1 N force accelerates at 1 m/s². For reference, a medium apple weighs about 1 N.`,
      type: 'text',
      order: 1,
      difficulty: 'intermediate',
      duration: 25,
      topicId: physTopic2.id,
    },
  })

  await prisma.lesson.create({
    data: {
      title: 'Newton\'s Third Law and Applications',
      content: `Newton's Third Law: For every action, there is an equal and opposite reaction. When object A exerts a force on object B, object B simultaneously exerts an equal force in the opposite direction on object A. These force pairs act on different objects.\n\nCommon misconceptions:\n• "The forces cancel out" — No! They act on different objects. If you push a box, your push on the box and the box's push on you are equal and opposite, but only the push on the box affects the box's motion.\n• "Bigger objects exert bigger forces" — No! The forces are always equal. When a car hits a fly, the fly and car exert equal forces on each other. The fly loses because it has less mass (a = F/m).\n\nApplications:\n• Walking: You push backward on the ground; the ground pushes you forward\n• Rockets: Hot gas is expelled backward; the gas pushes the rocket forward\n• Swimming: You push water backward; water pushes you forward\n• Book on table: Gravity pulls the book down; the table pushes the book up (normal force)\n\nUnderstanding action-reaction pairs is essential for analyzing systems of interacting objects, from simple blocks on surfaces to complex orbital mechanics.`,
      type: 'text',
      order: 2,
      difficulty: 'intermediate',
      duration: 25,
      topicId: physTopic2.id,
    },
  })

  // Energy and Work lessons
  await prisma.lesson.create({
    data: {
      title: 'Work and the Work-Energy Theorem',
      content: `In physics, work has a very specific meaning: W = F·d·cos(θ), where F is the force, d is the displacement, and θ is the angle between them. Work is measured in Joules (J), where 1 J = 1 N·m.\n\nKey points about work:\n• Only the component of force parallel to the displacement does work\n• If force is perpendicular to displacement (θ = 90°), no work is done\n• Work can be positive (force helps motion) or negative (force opposes motion)\n• Work is a scalar quantity — it has magnitude but no direction\n\nThe Work-Energy Theorem states that the net work done on an object equals its change in kinetic energy: W_net = ΔKE = ½mv² - ½mv₀². This is incredibly powerful because it relates force and distance to speed without needing to know the details of the motion.\n\nExample: A 1000 kg car moving at 20 m/s comes to a stop over 50 meters. What was the average braking force?\n• ΔKE = 0 - ½(1000)(20²) = -200,000 J\n• W = F × 50\n• F = -200,000/50 = -4,000 N (negative because it opposes motion)\n\nThis theorem simplifies many problems that would be difficult with Newton's second law alone.`,
      type: 'text',
      order: 1,
      difficulty: 'intermediate',
      duration: 30,
      topicId: physTopic3.id,
    },
  })

  await prisma.lesson.create({
    data: {
      title: 'Conservation of Energy',
      content: `The Law of Conservation of Energy is one of the most fundamental principles in all of physics: energy cannot be created or destroyed, only transformed from one form to another. The total energy of an isolated system remains constant.\n\nIn mechanical systems, we focus on two forms:\n• Kinetic Energy (KE) = ½mv² — energy of motion\n• Potential Energy (PE) — energy of position or configuration\n  - Gravitational PE = mgh (near Earth's surface)\n  - Elastic PE = ½kx² (for springs)\n\nFor a system with only conservative forces (no friction or air resistance):\nKE₁ + PE₁ = KE₂ + PE₂\n\nThis means we can solve many problems by tracking energy transformations:\nA roller coaster at the top of a 40m hill moving at 5 m/s: What's its speed at the bottom?\n• At top: KE = ½m(25) + mg(40), at bottom: ½mv² + 0\n• ½(25) + 9.8(40) = ½v²\n• 12.5 + 392 = ½v²\n• v² = 809, v ≈ 28.4 m/s\n\nWhen friction is present, mechanical energy isn't conserved — some converts to thermal energy. But total energy is still conserved: KE₁ + PE₁ = KE₂ + PE₂ + E_thermal.`,
      type: 'text',
      order: 2,
      difficulty: 'intermediate',
      duration: 30,
      topicId: physTopic3.id,
    },
  })

  // ---- Course 4: Chemistry ----
  const chemistry = await prisma.course.create({
    data: {
      title: 'Chemistry: Atoms and Reactions',
      description: 'Dive into the world of atoms, molecules, and chemical reactions. Understand the building blocks of matter and how they interact and transform.',
      category: 'Science',
      difficulty: 'beginner',
      duration: '8 weeks',
      rating: 4.4,
      enrolledCount: 934,
    },
  })

  const chemTopic1 = await prisma.topic.create({
    data: {
      name: 'Atomic Structure',
      description: 'Understanding the structure and properties of atoms',
      order: 1,
      courseId: chemistry.id,
    },
  })

  const chemTopic2 = await prisma.topic.create({
    data: {
      name: 'Chemical Bonding',
      description: 'How atoms bond to form molecules and compounds',
      order: 2,
      courseId: chemistry.id,
    },
  })

  // Atomic Structure lessons
  await prisma.lesson.create({
    data: {
      title: 'The Atomic Model',
      content: `Atoms are the fundamental building blocks of all matter. The modern atomic model describes an atom as consisting of a dense nucleus surrounded by a cloud of electrons.\n\nThe nucleus contains:\n• Protons: positively charged particles with a mass of approximately 1 atomic mass unit (amu)\n• Neutrons: electrically neutral particles with a mass of approximately 1 amu\n\nElectrons are negatively charged particles with negligible mass (about 1/1836 of a proton's mass) that orbit the nucleus in electron shells or energy levels.\n\nKey atomic numbers:\n• Atomic number (Z) = number of protons — this defines the element\n• Mass number (A) = protons + neutrons\n• Number of neutrons = A - Z\n\nIsotopes are atoms of the same element with different numbers of neutrons. For example, Carbon-12 (6 protons, 6 neutrons) and Carbon-14 (6 protons, 8 neutrons) are isotopes of carbon. They have the same chemical properties but different nuclear stability.\n\nThe quantum mechanical model replaced the simple "planetary" model, describing electrons not as orbiting particles but as probability clouds (orbitals) where electrons are most likely to be found. This model explains chemical behavior much more accurately.`,
      type: 'text',
      order: 1,
      difficulty: 'beginner',
      duration: 20,
      topicId: chemTopic1.id,
    },
  })

  await prisma.lesson.create({
    data: {
      title: 'Electron Configuration and the Periodic Table',
      content: `Electron configuration describes how electrons are distributed among the various orbitals of an atom. Understanding electron configuration is key to predicting chemical behavior.\n\nOrbitals are filled in order of increasing energy (Aufbau principle):\n1s → 2s → 2p → 3s → 3p → 4s → 3d → 4p → 5s → 4d → 5p → 6s → 4f → 5d → 6p → 7s → 5f → 6d\n\nKey rules:\n• Pauli Exclusion Principle: Each orbital holds a maximum of 2 electrons with opposite spins\n• Hund's Rule: In a subshell, electrons occupy orbitals singly before pairing up\n• Aufbau Principle: Electrons fill the lowest energy orbitals first\n\nExample - Oxygen (8 electrons): 1s² 2s² 2p⁴\nThis means: 2 electrons in the 1s orbital, 2 in 2s, and 4 in 2p (with one p orbital having a pair and two having single electrons).\n\nThe periodic table is organized by electron configuration. Elements in the same column (group) have similar outer electron configurations and thus similar chemical properties. The noble gases (Group 18) have full outer shells and are chemically inert, while alkali metals (Group 1) have one electron beyond a full shell and are highly reactive.`,
      type: 'text',
      order: 2,
      difficulty: 'beginner',
      duration: 25,
      topicId: chemTopic1.id,
    },
  })

  await prisma.lesson.create({
    data: {
      title: 'The Periodic Table and Element Properties',
      content: `The periodic table organizes all known elements by increasing atomic number, revealing patterns in their properties. These periodic trends are some of the most powerful tools in chemistry.\n\nMajor periodic trends:\n\nAtomic Radius: Decreases across a period (left to right) because increasing nuclear charge pulls electrons closer. Increases down a group because each row adds a new electron shell.\n\nIonization Energy: The energy required to remove the outermost electron. Increases across a period (harder to remove from a more positively charged nucleus). Decreases down a group (outer electrons are farther from the nucleus and shielded by inner electrons).\n\nElectronegativity: The tendency of an atom to attract electrons in a bond. Follows the same trend as ionization energy — increases across a period, decreases down a group. Fluorine is the most electronegative element (3.98 on the Pauling scale).\n\nMetallic Character: Metals are on the left side of the table, nonmetals on the right. Metallic character increases down a group and decreases across a period. This explains why cesium (bottom-left area) is extremely reactive while noble gases (far right) are inert.\n\nUnderstanding these trends allows chemists to predict how elements will behave in reactions without having to test each one individually — one of the great powers of the periodic table.`,
      type: 'text',
      order: 3,
      difficulty: 'beginner',
      duration: 25,
      topicId: chemTopic1.id,
    },
  })

  // Chemical Bonding lessons
  await prisma.lesson.create({
    data: {
      title: 'Ionic and Covalent Bonds',
      content: `Chemical bonds are the forces that hold atoms together in compounds. Two primary types of bonds exist: ionic and covalent.\n\nIonic Bonds form when one atom transfers electrons to another, creating oppositely charged ions that attract each other. This typically occurs between metals (low ionization energy) and nonmetals (high electronegativity).\n\nExample: Sodium (Na) transfers one electron to Chlorine (Cl), forming Na⁺ and Cl⁻. The electrostatic attraction between these ions creates NaCl (table salt). Ionic compounds have high melting points, are brittle, and conduct electricity when dissolved or molten.\n\nCovalent Bonds form when two atoms share electrons. This typically occurs between nonmetals. Covalent bonds can be:\n• Nonpolar covalent: Equal sharing (e.g., H₂, O₂) — electronegativity difference < 0.5\n• Polar covalent: Unequal sharing (e.g., H₂O, HCl) — electronegativity difference 0.5-1.7\n\nIn water (H₂O), oxygen is more electronegative than hydrogen, so the shared electrons spend more time near oxygen. This creates a partial negative charge on oxygen and partial positive charges on hydrogen, making water a polar molecule.\n\nThe continuum from nonpolar covalent → polar covalent → ionic is based on electronegativity difference. Most bonds have some character of both types; the categories are convenient simplifications.`,
      type: 'text',
      order: 1,
      difficulty: 'beginner',
      duration: 25,
      topicId: chemTopic2.id,
    },
  })

  await prisma.lesson.create({
    data: {
      title: 'Molecular Geometry and VSEPR Theory',
      content: `The Valence Shell Electron Pair Repulsion (VSEPR) theory predicts the three-dimensional shape of molecules based on the principle that electron pairs around a central atom arrange themselves to minimize repulsion.\n\nBasic molecular geometries:\n• 2 electron pairs → Linear (180°) — e.g., CO₂, BeCl₂\n• 3 electron pairs → Trigonal planar (120°) — e.g., BF₃, SO₃\n• 4 electron pairs → Tetrahedral (109.5°) — e.g., CH₄, CCl₄\n• 4 pairs (1 lone pair) → Trigonal pyramidal (~107°) — e.g., NH₃\n• 4 pairs (2 lone pairs) → Bent (~104.5°) — e.g., H₂O\n\nLone pairs occupy more space than bonding pairs because they're attracted to only one nucleus rather than two. This compresses the bond angles. In water, the two lone pairs on oxygen squeeze the H-O-H angle from the ideal 109.5° down to about 104.5°.\n\nMolecular shape determines many important properties:\n• Polarity: Symmetric molecules (like CO₂) are nonpolar even with polar bonds\n• Boiling point: Polar molecules have higher boiling points due to dipole-dipole interactions\n• Biological activity: Shape determines how molecules fit together in biological systems (lock-and-key model)\n\nUnderstanding VSEPR is essential for predicting molecular behavior in chemical reactions and biological processes.`,
      type: 'text',
      order: 2,
      difficulty: 'intermediate',
      duration: 25,
      topicId: chemTopic2.id,
    },
  })

  await prisma.lesson.create({
    data: {
      title: 'Chemical Reactions and Balancing Equations',
      content: `A chemical reaction is a process in which substances (reactants) are transformed into different substances (products). Chemical equations describe these transformations using chemical formulas and symbols.\n\nTypes of chemical reactions:\n• Synthesis (Combination): A + B → AB (e.g., 2Na + Cl₂ → 2NaCl)\n• Decomposition: AB → A + B (e.g., 2H₂O → 2H₂ + O₂)\n• Single Replacement: A + BC → AC + B (e.g., Zn + 2HCl → ZnCl₂ + H₂)\n• Double Replacement: AB + CD → AD + CB (e.g., AgNO₃ + NaCl → AgCl + NaNO₃)\n• Combustion: Fuel + O₂ → CO₂ + H₂O (e.g., CH₄ + 2O₂ → CO₂ + 2H₂O)\n\nBalancing equations is based on the Law of Conservation of Mass — atoms cannot be created or destroyed in a chemical reaction. Every atom in the reactants must appear in the products.\n\nTips for balancing:\n1. Start with the most complex molecule\n2. Balance elements that appear in only one compound on each side first\n3. Balance H and O last (they often appear in multiple compounds)\n4. Check your work by counting atoms on both sides\n5. Ensure all coefficients are in the lowest whole-number ratio`,
      type: 'text',
      order: 3,
      difficulty: 'beginner',
      duration: 20,
      topicId: chemTopic2.id,
    },
  })

  // ---- Course 5: Programming ----
  const programming = await prisma.course.create({
    data: {
      title: 'Programming with Python',
      description: 'Learn programming from scratch using Python. Master variables, loops, functions, and object-oriented programming through practical examples and projects.',
      category: 'Computer Science',
      difficulty: 'beginner',
      duration: '10 weeks',
      rating: 4.8,
      enrolledCount: 2156,
    },
  })

  const progTopic1 = await prisma.topic.create({
    data: {
      name: 'Python Basics',
      description: 'Variables, data types, and basic operations in Python',
      order: 1,
      courseId: programming.id,
    },
  })

  const progTopic2 = await prisma.topic.create({
    data: {
      name: 'Control Flow',
      description: 'Conditional statements and loops for controlling program execution',
      order: 2,
      courseId: programming.id,
    },
  })

  const progTopic3 = await prisma.topic.create({
    data: {
      name: 'Functions and Modules',
      description: 'Creating reusable code with functions and organizing with modules',
      order: 3,
      courseId: programming.id,
    },
  })

  // Python Basics lessons
  await prisma.lesson.create({
    data: {
      title: 'Getting Started with Python',
      content: `Python is one of the most popular and beginner-friendly programming languages in the world. Its clean syntax reads almost like English, making it an excellent first language to learn.\n\nWhy Python?\n• Simple, readable syntax with minimal punctuation\n• Huge standard library — "batteries included"\n• Massive community and ecosystem of third-party packages\n• Versatile: web development, data science, AI, automation, and more\n• Interpreted language — no compilation step needed\n\nYour first Python program:\nprint("Hello, World!")\n\nThis single line demonstrates several Python concepts: print() is a built-in function, "Hello, World!" is a string (text data), and the function call causes the string to appear on screen.\n\nPython can also do arithmetic:\nprint(2 + 3)       # Addition: 5\nprint(10 - 4)      # Subtraction: 6\nprint(3 * 7)       # Multiplication: 21\nprint(15 / 4)      # Division: 3.75\nprint(15 // 4)     # Integer division: 3\nprint(15 % 4)      # Modulo (remainder): 3\nprint(2 ** 5)      # Exponentiation: 32\n\nThe # symbol starts a comment — text that Python ignores. Comments help explain your code to other programmers (and your future self).`,
      type: 'text',
      order: 1,
      difficulty: 'beginner',
      duration: 15,
      topicId: progTopic1.id,
    },
  })

  await prisma.lesson.create({
    data: {
      title: 'Variables and Data Types',
      content: `Variables are named containers for storing data values. In Python, you create a variable simply by assigning a value:\n\nname = "Alice"        # String (text)\nage = 25              # Integer (whole number)\nheight = 5.7          # Float (decimal number)\nis_student = True     # Boolean (True/False)\n\nPython is dynamically typed — you don't need to declare the type, Python figures it out. You can even change a variable's type:\nx = 5        # x is an integer\nx = "hello"  # now x is a string (not recommended but allowed)\n\nString operations:\ngreeting = "Hello" + " " + "World"  # Concatenation: "Hello World"\nrepeat = "Ha" * 3                    # Repetition: "HaHaHa"\nlength = len("Python")              # Length: 6\n\nType conversion:\nstr(42)      # Converts integer to string: "42"\nint("7")     # Converts string to integer: 7\nfloat("3.14") # Converts string to float: 3.14\n\nNaming conventions:\n• Use descriptive names: student_count instead of sc\n• Use snake_case (lowercase with underscores): my_variable\n• Cannot start with a number: 1name is invalid\n• Cannot use Python keywords: if, for, while, class, etc.\n• Case-sensitive: Age and age are different variables`,
      type: 'text',
      order: 2,
      difficulty: 'beginner',
      duration: 20,
      topicId: progTopic1.id,
    },
  })

  await prisma.lesson.create({
    data: {
      title: 'Lists and Data Collections',
      content: `Lists are one of Python's most versatile data structures. They store an ordered collection of items that can be of any type:\n\nCreating lists:\nfruits = ["apple", "banana", "cherry"]\nnumbers = [1, 2, 3, 4, 5]\nmixed = [1, "hello", 3.14, True]  # Lists can hold different types\n\nAccessing elements (0-indexed):\nfruits[0]     # "apple" (first element)\nfruits[-1]    # "cherry" (last element)\nfruits[1:3]   # ["banana", "cherry"] (slicing)\n\nModifying lists:\nfruits.append("date")        # Add to end: ["apple", "banana", "cherry", "date"]\nfruits.insert(1, "blueberry") # Insert at index 1\nfruits.remove("banana")      # Remove by value\nfruits.pop()                 # Remove and return last item\n\nUseful list methods:\nlen(fruits)       # Number of items\nsorted(fruits)    # Return sorted copy\n"apple" in fruits # Check membership: True\n\nList comprehensions — a powerful Python feature:\nsquares = [x**2 for x in range(10)]  # [0, 1, 4, 9, 16, 25, 36, 49, 64, 81]\nevens = [x for x in range(20) if x % 2 == 0]  # [0, 2, 4, 6, 8, 10, 12, 14, 16, 18]\n\nOther collection types:\n• Tuples: (1, 2, 3) — immutable (can't change after creation)\n• Dictionaries: {"name": "Alice", "age": 25} — key-value pairs\n• Sets: {1, 2, 3} — unique elements, no order`,
      type: 'text',
      order: 3,
      difficulty: 'beginner',
      duration: 25,
      topicId: progTopic1.id,
    },
  })

  // Control Flow lessons
  await prisma.lesson.create({
    data: {
      title: 'Conditional Statements',
      content: `Conditional statements allow your program to make decisions based on conditions. Python uses if, elif, and else keywords:\n\nBasic if statement:\nage = 18\nif age >= 18:\n    print("You can vote!")\n\nIf-else:\ntemperature = 35\nif temperature > 30:\n    print("It's hot outside!")\nelse:\n    print("The weather is pleasant.")\n\nIf-elif-else chain:\nscore = 85\nif score >= 90:\n    grade = "A"\nelif score >= 80:\n    grade = "B"\nelif score >= 70:\n    grade = "C"\nelif score >= 60:\n    grade = "D"\nelse:\n    grade = "F"\nprint(f"Your grade is {grade}")  # Your grade is B\n\nComparison operators: == (equal), != (not equal), > (greater), < (less), >= (greater or equal), <= (less or equal)\n\nLogical operators: and, or, not\nif age >= 13 and age <= 19:\n    print("You're a teenager!")\n\nTernary expression (conditional expression):\nstatus = "adult" if age >= 18 else "minor"\n\nImportant: Python uses indentation (4 spaces) to define code blocks instead of curly braces. Consistent indentation is not just good style — it's required for your code to run!`,
      type: 'text',
      order: 1,
      difficulty: 'beginner',
      duration: 20,
      topicId: progTopic2.id,
    },
  })

  await prisma.lesson.create({
    data: {
      title: 'Loops: For and While',
      content: `Loops allow you to repeat code efficiently. Python has two main loop types:\n\nFor loops iterate over a sequence:\nfor fruit in ["apple", "banana", "cherry"]:\n    print(fruit)\n\nUsing range():\nfor i in range(5):       # 0, 1, 2, 3, 4\n    print(i)\nfor i in range(2, 8):    # 2, 3, 4, 5, 6, 7\n    print(i)\nfor i in range(0, 10, 2): # 0, 2, 4, 6, 8 (step by 2)\n    print(i)\n\nWhile loops repeat as long as a condition is true:\ncount = 0\nwhile count < 5:\n    print(count)\n    count += 1\n\nControl statements:\n• break: Exit the loop immediately\n• continue: Skip to the next iteration\n• else: Runs if the loop completes normally (not broken)\n\nPractical example — finding prime numbers:\nfor num in range(2, 20):\n    for i in range(2, num):\n        if num % i == 0:\n            break\n    else:\n        print(f"{num} is prime")\n\nNested loops are common for 2D data:\nfor row in range(3):\n    for col in range(3):\n        print(f"({row},{col})", end=" ")\n    print()  # New line after each row\n\nCommon pitfall: Forgetting to update the while loop condition, causing an infinite loop. Always ensure the loop will eventually terminate!`,
      type: 'text',
      order: 2,
      difficulty: 'beginner',
      duration: 25,
      topicId: progTopic2.id,
    },
  })

  await prisma.lesson.create({
    data: {
      title: 'Error Handling with Try-Except',
      content: `Errors are inevitable in programming. Python's try-except blocks let you handle errors gracefully instead of crashing:\n\nBasic error handling:\ntry:\n    number = int(input("Enter a number: "))\n    result = 100 / number\n    print(f"Result: {result}")\nexcept ValueError:\n    print("That's not a valid number!")\nexcept ZeroDivisionError:\n    print("Can't divide by zero!")\n\nMultiple exceptions in one block:\ntry:\n    file = open("data.txt")\n    content = file.read()\nexcept (FileNotFoundError, PermissionError) as e:\n    print(f"File error: {e}")\n\nComplete try-except-else-finally:\ntry:\n    result = risky_operation()\nexcept Exception as e:\n    print(f"An error occurred: {e}")\nelse:\n    print(f"Success! Result: {result}")  # Runs if no exception\nfinally:\n    print("This always runs")  # Cleanup code\n\nRaising your own exceptions:\ndef set_age(age):\n    if age < 0:\n        raise ValueError("Age cannot be negative")\n    if age > 150:\n        raise ValueError("Age seems unrealistic")\n    return age\n\nCommon exception types:\n• ValueError: Wrong value type (e.g., int("abc"))\n• TypeError: Wrong data type (e.g., "2" + 2)\n• IndexError: List index out of range\n• KeyError: Dictionary key not found\n• FileNotFoundError: File doesn't exist\n\nBest practice: Catch specific exceptions rather than using a bare except, and always include helpful error messages.`,
      type: 'text',
      order: 3,
      difficulty: 'intermediate',
      duration: 20,
      topicId: progTopic2.id,
    },
  })

  // Functions lessons
  await prisma.lesson.create({
    data: {
      title: 'Defining and Calling Functions',
      content: `Functions are reusable blocks of code that perform a specific task. They're the building blocks of well-organized programs:\n\nBasic function:\ndef greet(name):\n    return f"Hello, {name}!"\n\nmessage = greet("Alice")  # "Hello, Alice!"\n\nParameters and arguments:\ndef add(a, b):          # a and b are parameters\n    return a + b\n\nresult = add(3, 5)     # 3 and 5 are arguments\n\nDefault parameters:\ndef greet(name, greeting="Hello"):\n    return f"{greeting}, {name}!"\n\ngreet("Bob")              # "Hello, Bob!"\ngreet("Bob", "Good morning")  # "Good morning, Bob!"\n\nKeyword arguments:\ndef create_profile(name, age, city):\n    return f"{name}, {age}, lives in {city}"\n\ncreate_profile(name="Alice", city="NYC", age=25)  # Order doesn't matter\n\nMultiple return values:\ndef min_max(numbers):\n    return min(numbers), max(numbers)\n\nlowest, highest = min_max([3, 1, 4, 1, 5, 9])\n\nDocstrings document your functions:\ndef calculate_bmi(weight_kg, height_m):\n    \"\"\"Calculate Body Mass Index.\n    \n    Args:\n        weight_kg: Weight in kilograms\n        height_m: Height in meters\n    Returns:\n        BMI value as a float\n    \"\"\"\n    return weight_kg / (height_m ** 2)\n\nFunctions make code DRY (Don't Repeat Yourself), easier to test, and easier to understand.`,
      type: 'text',
      order: 1,
      difficulty: 'beginner',
      duration: 25,
      topicId: progTopic3.id,
    },
  })

  await prisma.lesson.create({
    data: {
      title: 'Lambda Functions and Higher-Order Functions',
      content: `Lambda functions are small anonymous functions defined with the lambda keyword. They're useful for short, simple operations:\n\nBasic lambda:\nsquare = lambda x: x ** 2\nprint(square(5))  # 25\n\nadd = lambda a, b: a + b\nprint(add(3, 7))  # 10\n\nHigher-order functions take functions as arguments or return functions:\n\nmap() — apply a function to every item:\nnumbers = [1, 2, 3, 4, 5]\nsquared = list(map(lambda x: x**2, numbers))  # [1, 4, 9, 16, 25]\n\nfilter() — keep items that meet a condition:\neven = list(filter(lambda x: x % 2 == 0, numbers))  # [2, 4]\n\nsorted() with a key function:\nstudents = [("Alice", 85), ("Bob", 92), ("Charlie", 78)]\nsorted_by_grade = sorted(students, key=lambda s: s[1], reverse=True)\n# [("Bob", 92), ("Alice", 85), ("Charlie", 78)]\n\nDecorators — functions that modify other functions:\ndef timer(func):\n    import time\n    def wrapper(*args, **kwargs):\n        start = time.time()\n        result = func(*args, **kwargs)\n        end = time.time()\n        print(f"{func.__name__} took {end-start:.4f}s")\n        return result\n    return wrapper\n\n@timer\ndef slow_function():\n    import time\n    time.sleep(1)\n\nWhile lambdas are powerful, use regular functions for anything complex — readability matters more than cleverness!`,
      type: 'text',
      order: 2,
      difficulty: 'intermediate',
      duration: 25,
      topicId: progTopic3.id,
    },
  })

  // ---- Course 6: Data Structures ----
  const dataStructures = await prisma.course.create({
    data: {
      title: 'Data Structures and Algorithms',
      description: 'Master the fundamental data structures and algorithms that power efficient software. From arrays to trees, learn to choose the right structure for any problem.',
      category: 'Computer Science',
      difficulty: 'intermediate',
      duration: '14 weeks',
      rating: 4.6,
      enrolledCount: 1567,
    },
  })

  const dsTopic1 = await prisma.topic.create({
    data: {
      name: 'Arrays and Linked Lists',
      description: 'Sequential data structures and their trade-offs',
      order: 1,
      courseId: dataStructures.id,
    },
  })

  const dsTopic2 = await prisma.topic.create({
    data: {
      name: 'Stacks and Queues',
      description: 'LIFO and FIFO data structures for ordered processing',
      order: 2,
      courseId: dataStructures.id,
    },
  })

  const dsTopic3 = await prisma.topic.create({
    data: {
      name: 'Trees and Graphs',
      description: 'Hierarchical and networked data structures',
      order: 3,
      courseId: dataStructures.id,
    },
  })

  // Arrays and Linked Lists lessons
  await prisma.lesson.create({
    data: {
      title: 'Arrays: The Foundation of Data Storage',
      content: `An array is a contiguous block of memory storing elements of the same type, accessed by their index. Arrays are the most fundamental data structure in computer science.\n\nHow arrays work in memory:\nIf an integer takes 4 bytes and the array starts at memory address 1000, then:\n• Element at index 0 is at address 1000\n• Element at index 1 is at address 1004\n• Element at index i is at address 1000 + (4 × i)\n\nThis formula allows O(1) random access — you can jump to any element instantly without traversing the entire array.\n\nTime complexities:\n• Access by index: O(1)\n• Search (unsorted): O(n)\n• Search (sorted, binary search): O(log n)\n• Insert at end (with space): O(1)\n• Insert at beginning/middle: O(n) — must shift elements\n• Delete from beginning/middle: O(n) — must shift elements\n\nDynamic arrays (like Python lists, Java ArrayList, C++ vector) automatically resize when full. They typically double in size when capacity is reached, giving amortized O(1) append time.\n\nWhen to use arrays:\n• You need fast random access by index\n• The size is known and relatively stable\n• You need cache-friendly memory access (contiguous memory is fast!)\n• You're implementing other data structures (stacks, heaps, hash tables)\n\nArrays are not ideal when you frequently insert or delete from the beginning or middle — that's when linked lists shine.`,
      type: 'text',
      order: 1,
      difficulty: 'intermediate',
      duration: 25,
      topicId: dsTopic1.id,
    },
  })

  await prisma.lesson.create({
    data: {
      title: 'Linked Lists: Dynamic Data Structures',
      content: `A linked list is a linear data structure where elements (nodes) are connected by pointers rather than stored contiguously in memory. Each node contains data and a reference to the next node.\n\nSingly Linked List:\n[Data|Next] → [Data|Next] → [Data|Next] → null\n\nNode implementation (Python):\nclass Node:\n    def __init__(self, data):\n        self.data = data\n        self.next = None\n\nTime complexities:\n• Access by index: O(n) — must traverse from the head\n• Search: O(n)\n• Insert at head: O(1)\n• Insert at tail (with tail pointer): O(1)\n• Insert in middle (after finding position): O(n) for finding + O(1) for inserting\n• Delete head: O(1)\n• Delete from middle: O(n)\n\nDoubly Linked List:\nnull ← [Prev|Data|Next] ⇄ [Prev|Data|Next] ⇄ [Prev|Data|Next] → null\n\nEach node has pointers to both the next and previous nodes, enabling:\n• Traversal in both directions\n• O(1) deletion given a pointer to the node\n• Easier implementation of certain algorithms\n\nArrays vs. Linked Lists:\n• Arrays: Fast access O(1), slow insert/delete O(n), cache-friendly\n• Linked Lists: Slow access O(n), fast insert/delete at known positions O(1), cache-unfriendly\n\nIn practice, arrays (dynamic arrays) are preferred for most use cases due to cache locality. Linked lists excel when you need frequent insertions/deletions at known positions, or when the total size is highly unpredictable.`,
      type: 'text',
      order: 2,
      difficulty: 'intermediate',
      duration: 30,
      topicId: dsTopic1.id,
    },
  })

  await prisma.lesson.create({
    data: {
      title: 'Sorting Algorithms: From Bubble to Quick Sort',
      content: `Sorting is one of the most fundamental operations in computer science. Understanding different sorting algorithms teaches important concepts about algorithm design and analysis.\n\nO(n²) Algorithms (Simple but Slow):\n\nBubble Sort: Repeatedly swap adjacent elements if they're in the wrong order. Simple but inefficient. Best for: learning, nearly-sorted data.\n\nSelection Sort: Find the minimum element and swap it to the front. Always makes O(n²) comparisons regardless of input. Best for: when memory writes are expensive.\n\nInsertion Sort: Build a sorted array one element at a time by inserting each new element in its correct position. Efficient for small or nearly-sorted data. Best for: small datasets, nearly-sorted data, online sorting.\n\nO(n log n) Algorithms (Efficient):\n\nMerge Sort: Divide the array in half, sort each half, then merge. Guaranteed O(n log n), stable, but requires O(n) extra space. Best for: guaranteed performance, linked lists, external sorting.\n\nQuick Sort: Pick a pivot, partition elements around it, recursively sort partitions. Average O(n log n), but worst case O(n²). In practice, it's often the fastest due to cache efficiency. Best for: general-purpose sorting, arrays in memory.\n\nHeap Sort: Build a max-heap, then repeatedly extract the maximum. Guaranteed O(n log n), in-place, but not stable and slower than Quick Sort in practice.\n\nPython's built-in sort uses Tim Sort, a hybrid of Merge Sort and Insertion Sort, optimized for real-world data that often has runs of already-sorted elements. Choosing the right algorithm depends on your data characteristics, size constraints, and whether stability matters.`,
      type: 'text',
      order: 3,
      difficulty: 'intermediate',
      duration: 35,
      topicId: dsTopic1.id,
    },
  })

  // Stacks and Queues lessons
  await prisma.lesson.create({
    data: {
      title: 'Stacks: Last In, First Out',
      content: `A stack is a linear data structure that follows the Last In, First Out (LIFO) principle — like a stack of plates where you can only add or remove from the top.\n\nCore operations:\n• push(item): Add item to top — O(1)\n• pop(): Remove and return top item — O(1)\n• peek()/top(): View top item without removing — O(1)\n• isEmpty(): Check if stack is empty — O(1)\n\nPython implementation using lists:\nstack = []\nstack.append("A")     # push: ["A"]\nstack.append("B")     # push: ["A", "B"]\nstack.append("C")     # push: ["A", "B", "C"]\ntop = stack[-1]       # peek: "C"\nremoved = stack.pop() # pop: "C", stack = ["A", "B"]\n\nReal-world applications:\n• Function call stack: When a function is called, its state is pushed; when it returns, it's popped\n• Undo/Redo: Each action is pushed; undo pops and pushes to redo stack\n• Browser history: Each page visit is pushed; back button pops\n• Expression evaluation: Converting infix to postfix notation\n• Balanced parentheses: Push opening brackets, pop for closing\n\nExample — Valid Parentheses:\ndef is_valid(s):\n    stack = []\n    pairs = {")": "(", "]": "[", "}": "{"}\n    for char in s:\n        if char in pairs.values():\n            stack.append(char)\n        elif char in pairs:\n            if not stack or stack.pop() != pairs[char]:\n                return False\n    return len(stack) == 0`,
      type: 'text',
      order: 1,
      difficulty: 'intermediate',
      duration: 25,
      topicId: dsTopic2.id,
    },
  })

  await prisma.lesson.create({
    data: {
      title: 'Queues: First In, First Out',
      content: `A queue is a linear data structure that follows the First In, First Out (FIFO) principle — like a line at a store where the first person in line is served first.\n\nCore operations:\n• enqueue(item): Add item to rear — O(1)\n• dequeue(): Remove and return front item — O(1)\n• front(): View front item without removing — O(1)\n• isEmpty(): Check if queue is empty — O(1)\n\nPython implementation using collections.deque:\nfrom collections import deque\nqueue = deque()\nqueue.append("A")      # enqueue: ["A"]\nqueue.append("B")      # enqueue: ["A", "B"]\nqueue.append("C")      # enqueue: ["A", "B", "C"]\nfront = queue[0]       # front: "A"\nserved = queue.popleft() # dequeue: "A", queue = ["B", "C"]\n\nWhy use deque instead of list? List pop(0) is O(n) because all elements shift. Deque popleft() is O(1) using a doubly-linked list internally.\n\nVariations:\n• Priority Queue: Elements dequeued by priority, not order. Implemented with a heap.\n• Circular Queue: Fixed-size queue that wraps around. Efficient for buffering.\n• Double-ended Queue (Deque): Can add/remove from both ends.\n\nReal-world applications:\n• Task scheduling: Print jobs, CPU process scheduling\n• BFS (Breadth-First Search): Explore nodes level by level\n• Message queues: Asynchronous communication between systems\n• Buffering: Keyboard buffer, I/O buffers\n• Call center systems: Customers wait in queue for next available agent`,
      type: 'text',
      order: 2,
      difficulty: 'intermediate',
      duration: 25,
      topicId: dsTopic2.id,
    },
  })

  // Trees and Graphs lessons
  await prisma.lesson.create({
    data: {
      title: 'Binary Trees and Binary Search Trees',
      content: `A tree is a hierarchical data structure consisting of nodes connected by edges. A binary tree is a tree where each node has at most two children (left and right).\n\nTree terminology:\n• Root: The top node (no parent)\n• Leaf: A node with no children\n• Height: Longest path from root to leaf\n• Depth: Distance from root to a specific node\n• Subtree: Any node and all its descendants\n\nBinary Search Tree (BST): A binary tree where for every node:\n• All values in the left subtree are less than the node's value\n• All values in the right subtree are greater than the node's value\n\nThis property enables efficient searching — at each node, you eliminate half the remaining tree.\n\nBST operations (average case / worst case):\n• Search: O(log n) / O(n)\n• Insert: O(log n) / O(n)\n• Delete: O(log n) / O(n)\n\nThe worst case occurs when the tree becomes a linear chain (like a linked list). Self-balancing trees (AVL, Red-Black) guarantee O(log n) by keeping the tree balanced.\n\nTree traversals:\n• Inorder (Left, Root, Right): Visits BST nodes in sorted order\n• Preorder (Root, Left, Right): Creates a copy of the tree\n• Postorder (Left, Right, Root): Used for deletion\n• Level-order: BFS using a queue\n\nBSTs are widely used in database indexing, file systems, and as the foundation for more complex structures like AVL trees and B-trees.`,
      type: 'text',
      order: 1,
      difficulty: 'intermediate',
      duration: 30,
      topicId: dsTopic3.id,
    },
  })

  await prisma.lesson.create({
    data: {
      title: 'Graphs: Networks and Connections',
      content: `A graph is a data structure consisting of vertices (nodes) and edges (connections between nodes). Graphs model relationships in ways that other structures cannot.\n\nTypes of graphs:\n• Directed: Edges have direction (A → B ≠ B → A), like one-way streets\n• Undirected: Edges are bidirectional, like friendships\n• Weighted: Edges have costs/distances, like road distances\n• Cyclic: Contains cycles (paths that return to starting node)\n• Acyclic: No cycles — DAGs (Directed Acyclic Graphs) are especially important\n\nRepresentations:\nAdjacency Matrix: 2D array where matrix[i][j] = 1 if edge exists. Space: O(V²). Fast edge lookup O(1), but wasteful for sparse graphs.\n\nAdjacency List: Dictionary of lists. Space: O(V + E). Efficient for sparse graphs, the most common representation.\n\nGraph traversal:\nBFS (Breadth-First Search): Uses a queue, explores all neighbors before going deeper. Finds shortest path in unweighted graphs.\n\nDFS (Depth-First Search): Uses a stack (or recursion), explores as deep as possible first. Used for topological sorting, cycle detection, and maze solving.\n\nKey algorithms:\n• Dijkstra's: Shortest path in weighted graphs (non-negative weights)\n• Bellman-Ford: Shortest path with negative weights\n• Kruskal's/Prim's: Minimum spanning tree\n• Topological Sort: Ordering for DAGs (prerequisite chains)\n\nApplications: Social networks, maps and navigation, recommendation systems, network routing, dependency management, and compiler design.`,
      type: 'text',
      order: 2,
      difficulty: 'advanced',
      duration: 35,
      topicId: dsTopic3.id,
    },
  })

  console.log(`  ✅ Created 6 courses with topics and lessons`)

  // ==================== QUIZZES AND QUESTIONS ====================
  console.log('📝 Creating quizzes and questions...')

  // Quiz 1: Algebra Quiz
  const algebraQuiz = await prisma.quiz.create({
    data: {
      title: 'Algebra Fundamentals Quiz',
      description: 'Test your understanding of linear equations, quadratic equations, and polynomials',
      difficulty: 'beginner',
      timeLimit: 20,
      courseId: algebra.id,
    },
  })

  await prisma.question.createMany({
    data: [
      {
        quizId: algebraQuiz.id,
        text: 'Solve for x: 3x + 7 = 22',
        type: 'mcq',
        options: '["3", "5", "7", "15"]',
        correctAnswer: '5',
        explanation: 'Subtract 7 from both sides: 3x = 15. Divide both sides by 3: x = 5.',
        points: 10,
        order: 1,
      },
      {
        quizId: algebraQuiz.id,
        text: 'What is the factored form of x² - 9?',
        type: 'mcq',
        options: '["(x-3)(x-3)", "(x+3)(x-3)", "(x+9)(x-1)", "(x-9)(x+1)"]',
        correctAnswer: '(x+3)(x-3)',
        explanation: 'This is a difference of squares: a² - b² = (a+b)(a-b). Here, x² - 9 = x² - 3² = (x+3)(x-3).',
        points: 10,
        order: 2,
      },
      {
        quizId: algebraQuiz.id,
        text: 'Using the quadratic formula, solve x² + 5x + 6 = 0',
        type: 'mcq',
        options: '["x = -2, x = -3", "x = 2, x = 3", "x = -1, x = -6", "x = 1, x = 6"]',
        correctAnswer: 'x = -2, x = -3',
        explanation: 'Factor: (x+2)(x+3) = 0, so x = -2 or x = -3. Or use the quadratic formula: x = (-5 ± √(25-24))/2 = (-5 ± 1)/2.',
        points: 10,
        order: 3,
      },
      {
        quizId: algebraQuiz.id,
        text: 'What is the GCF (Greatest Common Factor) of 12x³ and 8x²?',
        type: 'mcq',
        options: '["2x²", "4x²", "4x³", "8x²"]',
        correctAnswer: '4x²',
        explanation: 'GCF of 12 and 8 is 4. GCF of x³ and x² is x² (lowest power). So GCF = 4x².',
        points: 10,
        order: 4,
      },
      {
        quizId: algebraQuiz.id,
        text: 'Simplify: (3x² + 2x - 5) + (x² - 4x + 3)',
        type: 'mcq',
        options: '["4x² - 2x - 2", "4x² + 6x - 2", "2x² - 2x - 8", "4x² - 2x + 2"]',
        correctAnswer: '4x² - 2x - 2',
        explanation: 'Combine like terms: (3x² + x²) + (2x - 4x) + (-5 + 3) = 4x² - 2x - 2.',
        points: 10,
        order: 5,
      },
      {
        quizId: algebraQuiz.id,
        text: 'If the discriminant of a quadratic equation is negative, what does this tell us about the solutions?',
        type: 'mcq',
        options: '["There are two real solutions", "There is one real solution", "There are no real solutions", "The equation is linear"]',
        correctAnswer: 'There are no real solutions',
        explanation: 'A negative discriminant (b² - 4ac < 0) means the square root is not a real number, so there are no real solutions (only complex solutions).',
        points: 10,
        order: 6,
      },
      {
        quizId: algebraQuiz.id,
        text: 'Solve for x: 2(x - 4) = 3x + 1',
        type: 'mcq',
        options: '["x = -9", "x = -7", "x = 9", "x = 7"]',
        correctAnswer: 'x = -9',
        explanation: 'Distribute: 2x - 8 = 3x + 1. Subtract 2x: -8 = x + 1. Subtract 1: x = -9.',
        points: 10,
        order: 7,
      },
    ],
  })

  // Quiz 2: Calculus Quiz
  const calcQuiz = await prisma.quiz.create({
    data: {
      title: 'Calculus: Limits and Derivatives Quiz',
      description: 'Assess your knowledge of limits, continuity, and derivative rules',
      difficulty: 'advanced',
      timeLimit: 30,
      courseId: calculus.id,
    },
  })

  await prisma.question.createMany({
    data: [
      {
        quizId: calcQuiz.id,
        text: 'What is lim(x→2) (x² - 4)/(x - 2)?',
        type: 'mcq',
        options: '["0", "2", "4", "Undefined"]',
        correctAnswer: '4',
        explanation: 'Factor the numerator: (x²-4)/(x-2) = (x+2)(x-2)/(x-2) = x+2 for x≠2. As x→2, this approaches 4.',
        points: 10,
        order: 1,
      },
      {
        quizId: calcQuiz.id,
        text: 'What is the derivative of f(x) = 3x⁴ - 2x² + 7?',
        type: 'mcq',
        options: '["12x³ - 2x", "12x³ - 4x", "3x³ - 4x + 7", "12x⁴ - 4x²"]',
        correctAnswer: '12x³ - 4x',
        explanation: 'Apply the power rule to each term: d/dx(3x⁴) = 12x³, d/dx(-2x²) = -4x, d/dx(7) = 0. So f\'(x) = 12x³ - 4x.',
        points: 10,
        order: 2,
      },
      {
        quizId: calcQuiz.id,
        text: 'Which rule is used to differentiate f(g(x))?',
        type: 'mcq',
        options: '["Product Rule", "Quotient Rule", "Chain Rule", "Power Rule"]',
        correctAnswer: 'Chain Rule',
        explanation: 'The Chain Rule states that d/dx[f(g(x))] = f\'(g(x)) · g\'(x). It is used for composite functions.',
        points: 10,
        order: 3,
      },
      {
        quizId: calcQuiz.id,
        text: 'What is d/dx[sin(x)]?',
        type: 'mcq',
        options: '["-sin(x)", "cos(x)", "-cos(x)", "tan(x)"]',
        correctAnswer: 'cos(x)',
        explanation: 'The derivative of sin(x) is cos(x). This is a fundamental trigonometric derivative that should be memorized.',
        points: 10,
        order: 4,
      },
      {
        quizId: calcQuiz.id,
        text: 'If a function f is continuous at point a, which of the following must be true?',
        type: 'mcq',
        options: '["f(a) is defined", "lim(x→a) f(x) exists", "lim(x→a) f(x) = f(a)", "All of the above"]',
        correctAnswer: 'All of the above',
        explanation: 'Continuity at a point requires all three conditions: f(a) is defined, the limit exists, and the limit equals f(a).',
        points: 10,
        order: 5,
      },
      {
        quizId: calcQuiz.id,
        text: 'What is the derivative of f(x) = e^(2x)?',
        type: 'mcq',
        options: '["e^(2x)", "2e^(2x)", "2e^x", "e^(2x) · 2x"]',
        correctAnswer: '2e^(2x)',
        explanation: 'Using the chain rule: d/dx[e^(2x)] = e^(2x) · d/dx[2x] = e^(2x) · 2 = 2e^(2x).',
        points: 10,
        order: 6,
      },
      {
        quizId: calcQuiz.id,
        text: 'At a critical point where f\'(c) = 0 and f\'\'(c) > 0, what can we conclude?',
        type: 'mcq',
        options: '["Local maximum at c", "Local minimum at c", "Inflection point at c", "No conclusion possible"]',
        correctAnswer: 'Local minimum at c',
        explanation: 'By the second derivative test: if f\'(c) = 0 and f\'\'(c) > 0, the function is concave up at c, indicating a local minimum.',
        points: 10,
        order: 7,
      },
      {
        quizId: calcQuiz.id,
        text: 'What does L\'Hôpital\'s Rule allow us to do?',
        type: 'mcq',
        options: '["Find the derivative of any function", "Evaluate limits of indeterminate forms", "Prove continuity", "Find the area under a curve"]',
        correctAnswer: 'Evaluate limits of indeterminate forms',
        explanation: 'L\'Hôpital\'s Rule allows us to evaluate limits of the form 0/0 or ∞/∞ by differentiating the numerator and denominator separately.',
        points: 10,
        order: 8,
      },
    ],
  })

  // Quiz 3: Physics Quiz
  const physicsQuiz = await prisma.quiz.create({
    data: {
      title: 'Physics: Mechanics Quiz',
      description: 'Test your understanding of motion, forces, and energy',
      difficulty: 'intermediate',
      timeLimit: 25,
      courseId: physics.id,
    },
  })

  await prisma.question.createMany({
    data: [
      {
        quizId: physicsQuiz.id,
        text: 'A car accelerates from rest at 3 m/s² for 5 seconds. What is its final velocity?',
        type: 'mcq',
        options: '["8 m/s", "15 m/s", "25 m/s", "75 m/s"]',
        correctAnswer: '15 m/s',
        explanation: 'Using v = v₀ + at = 0 + 3(5) = 15 m/s. The car starts from rest (v₀ = 0).',
        points: 10,
        order: 1,
      },
      {
        quizId: physicsQuiz.id,
        text: 'What is Newton\'s Second Law of Motion?',
        type: 'mcq',
        options: '["F = mv", "F = ma", "F = mg", "F = mgh"]',
        correctAnswer: 'F = ma',
        explanation: 'Newton\'s Second Law states that the net force on an object equals its mass times its acceleration: F = ma.',
        points: 10,
        order: 2,
      },
      {
        quizId: physicsQuiz.id,
        text: 'A ball is thrown upward at 20 m/s. How high does it go? (g = 10 m/s²)',
        type: 'mcq',
        options: '["10 m", "20 m", "40 m", "80 m"]',
        correctAnswer: '20 m',
        explanation: 'At max height, v = 0. Using v² = v₀² - 2gh: 0 = 400 - 20h, h = 20 m.',
        points: 10,
        order: 3,
      },
      {
        quizId: physicsQuiz.id,
        text: 'What is the kinetic energy of a 2 kg object moving at 5 m/s?',
        type: 'mcq',
        options: '["10 J", "25 J", "50 J", "100 J"]',
        correctAnswer: '25 J',
        explanation: 'KE = ½mv² = ½(2)(25) = 25 J.',
        points: 10,
        order: 4,
      },
      {
        quizId: physicsQuiz.id,
        text: 'According to Newton\'s Third Law, when you push on a wall, the wall:',
        type: 'mcq',
        options: '["Does not push back", "Pushes back with equal force", "Pushes back with less force", "Pushes back with more force"]',
        correctAnswer: 'Pushes back with equal force',
        explanation: 'Newton\'s Third Law states that for every action, there is an equal and opposite reaction. The wall pushes back on you with the same force.',
        points: 10,
        order: 5,
      },
      {
        quizId: physicsQuiz.id,
        text: 'A projectile is launched at 45°. At what other angle would it have the same range (ignoring air resistance)?',
        type: 'mcq',
        options: '["30°", "60°", "90°", "No other angle gives the same range"]',
        correctAnswer: '60°',
        explanation: 'Complementary angles (angles that add to 90°) give the same range. Since 45° + 60° is not 90°, let me correct: actually 90° - 45° = 45°, so only 45° gives maximum range. But for a general angle θ, the angle (90° - θ) gives the same range. So 30° and 60° give the same range.',
        points: 10,
        order: 6,
      },
      {
        quizId: physicsQuiz.id,
        text: 'What does the Work-Energy Theorem state?',
        type: 'mcq',
        options: '["Work equals force times distance", "Net work equals change in kinetic energy", "Energy is always conserved", "Power equals work divided by time"]',
        correctAnswer: 'Net work equals change in kinetic energy',
        explanation: 'The Work-Energy Theorem states W_net = ΔKE = ½mv² - ½mv₀². The net work done on an object equals its change in kinetic energy.',
        points: 10,
        order: 7,
      },
    ],
  })

  // Quiz 4: Chemistry Quiz
  const chemQuiz = await prisma.quiz.create({
    data: {
      title: 'Chemistry: Atoms and Reactions Quiz',
      description: 'Test your knowledge of atomic structure, bonding, and chemical reactions',
      difficulty: 'beginner',
      timeLimit: 20,
      courseId: chemistry.id,
    },
  })

  await prisma.question.createMany({
    data: [
      {
        quizId: chemQuiz.id,
        text: 'What is the atomic number of an element?',
        type: 'mcq',
        options: '["Number of neutrons", "Number of protons", "Number of electrons + neutrons", "Mass of the atom"]',
        correctAnswer: 'Number of protons',
        explanation: 'The atomic number (Z) equals the number of protons in the nucleus. This uniquely identifies the element.',
        points: 10,
        order: 1,
      },
      {
        quizId: chemQuiz.id,
        text: 'Which type of bond involves the sharing of electrons?',
        type: 'mcq',
        options: '["Ionic bond", "Covalent bond", "Metallic bond", "Hydrogen bond"]',
        correctAnswer: 'Covalent bond',
        explanation: 'In a covalent bond, atoms share electrons to achieve a stable electron configuration. Ionic bonds involve electron transfer.',
        points: 10,
        order: 2,
      },
      {
        quizId: chemQuiz.id,
        text: 'What is the electron configuration of Carbon (atomic number 6)?',
        type: 'mcq',
        options: '["1s² 2s² 2p¹", "1s² 2s² 2p²", "1s² 2s² 2p⁴", "1s² 2s¹ 2p³"]',
        correctAnswer: '1s² 2s² 2p²',
        explanation: 'Carbon has 6 electrons. They fill in order: 1s² (2), 2s² (4), 2p² (6).',
        points: 10,
        order: 3,
      },
      {
        quizId: chemQuiz.id,
        text: 'What happens to atomic radius as you move across a period (left to right)?',
        type: 'mcq',
        options: '["Increases", "Decreases", "Stays the same", "First increases then decreases"]',
        correctAnswer: 'Decreases',
        explanation: 'Moving across a period, nuclear charge increases while shielding stays similar, pulling electrons closer and decreasing atomic radius.',
        points: 10,
        order: 4,
      },
      {
        quizId: chemQuiz.id,
        text: 'Which is the correct balanced equation for the combustion of methane?',
        type: 'mcq',
        options: '["CH₄ + O₂ → CO₂ + H₂O", "CH₄ + 2O₂ → CO₂ + 2H₂O", "2CH₄ + O₂ → 2CO₂ + H₂O", "CH₄ + O₂ → CO₂ + 2H₂O"]',
        correctAnswer: 'CH₄ + 2O₂ → CO₂ + 2H₂O',
        explanation: 'Balancing: C: 1=1 ✓, H: 4=4 ✓, O: 4=2+2=4 ✓. The equation is balanced with 2 O₂ molecules.',
        points: 10,
        order: 5,
      },
      {
        quizId: chemQuiz.id,
        text: 'According to VSEPR theory, what is the molecular geometry of a molecule with 4 bonding pairs and no lone pairs?',
        type: 'mcq',
        options: '["Linear", "Trigonal planar", "Tetrahedral", "Bent"]',
        correctAnswer: 'Tetrahedral',
        explanation: 'Four bonding pairs with no lone pairs arrange themselves to maximize distance, forming a tetrahedral shape with 109.5° bond angles. Example: CH₄.',
        points: 10,
        order: 6,
      },
      {
        quizId: chemQuiz.id,
        text: 'Isotopes of the same element have different numbers of:',
        type: 'mcq',
        options: '["Protons", "Electrons", "Neutrons", "Atomic number"]',
        correctAnswer: 'Neutrons',
        explanation: 'Isotopes have the same number of protons (same element) but different numbers of neutrons, giving them different mass numbers.',
        points: 10,
        order: 7,
      },
    ],
  })

  // Quiz 5: Programming Quiz
  const progQuiz = await prisma.quiz.create({
    data: {
      title: 'Python Programming Quiz',
      description: 'Test your Python programming knowledge from basics to functions',
      difficulty: 'beginner',
      timeLimit: 20,
      courseId: programming.id,
    },
  })

  await prisma.question.createMany({
    data: [
      {
        quizId: progQuiz.id,
        text: 'What is the output of: print(type(3.14))?',
        type: 'mcq',
        options: '["<class \'int\'>", "<class \'float\'>", "<class \'str\'>", "<class \'number\'>"]',
        correctAnswer: "<class 'float'>",
        explanation: '3.14 is a floating-point number (decimal), so its type is float.',
        points: 10,
        order: 1,
      },
      {
        quizId: progQuiz.id,
        text: 'What does len([1, 2, 3, [4, 5]]) return?',
        type: 'mcq',
        options: '["4", "5", "3", "6"]',
        correctAnswer: '4',
        explanation: 'The list has 4 elements: 1, 2, 3, and [4, 5]. The nested list counts as one element.',
        points: 10,
        order: 2,
      },
      {
        quizId: progQuiz.id,
        text: 'What is the output of: print("Hello"[1:4])?',
        type: 'mcq',
        options: '["Hel", "ell", "ello", "ello"]',
        correctAnswer: 'ell',
        explanation: 'String slicing [1:4] extracts characters at indices 1, 2, 3 (not including 4): "e", "l", "l" → "ell".',
        points: 10,
        order: 3,
      },
      {
        quizId: progQuiz.id,
        text: 'Which keyword is used to define a function in Python?',
        type: 'mcq',
        options: '["function", "func", "def", "define"]',
        correctAnswer: 'def',
        explanation: 'In Python, functions are defined using the "def" keyword followed by the function name and parameters.',
        points: 10,
        order: 4,
      },
      {
        quizId: progQuiz.id,
        text: 'What does the "continue" statement do in a loop?',
        type: 'mcq',
        options: '["Exits the loop completely", "Skips the current iteration and moves to the next", "Restarts the loop from the beginning", "Pauses the loop"]',
        correctAnswer: 'Skips the current iteration and moves to the next',
        explanation: 'The continue statement skips the remaining code in the current iteration and jumps to the next iteration of the loop.',
        points: 10,
        order: 5,
      },
      {
        quizId: progQuiz.id,
        text: 'What is the result of: [x**2 for x in range(5)]?',
        type: 'mcq',
        options: '["[1, 4, 9, 16, 25]", "[0, 1, 4, 9, 16]", "[0, 2, 4, 6, 8]", "[1, 2, 3, 4, 5]"]',
        correctAnswer: '[0, 1, 4, 9, 16]',
        explanation: 'range(5) generates 0,1,2,3,4. Squaring each: 0,1,4,9,16. Note it starts from 0, not 1.',
        points: 10,
        order: 6,
      },
      {
        quizId: progQuiz.id,
        text: 'What exception is raised when dividing by zero in Python?',
        type: 'mcq',
        options: '["ValueError", "TypeError", "ZeroDivisionError", "ArithmeticError"]',
        correctAnswer: 'ZeroDivisionError',
        explanation: 'Division by zero raises ZeroDivisionError in Python. It is a specific type of ArithmeticError.',
        points: 10,
        order: 7,
      },
      {
        quizId: progQuiz.id,
        text: 'What is a default parameter in Python?',
        type: 'mcq',
        options: '["A parameter that must always be provided", "A parameter with a pre-set value used if no argument is given", "The first parameter of every function", "A parameter that cannot be changed"]',
        correctAnswer: 'A parameter with a pre-set value used if no argument is given',
        explanation: 'Default parameters have preset values. If no argument is provided, the default is used. Example: def greet(name, msg="Hello")',
        points: 10,
        order: 8,
      },
    ],
  })

  // Quiz 6: Data Structures Quiz
  const dsQuiz = await prisma.quiz.create({
    data: {
      title: 'Data Structures and Algorithms Quiz',
      description: 'Test your understanding of fundamental data structures and their operations',
      difficulty: 'intermediate',
      timeLimit: 25,
      courseId: dataStructures.id,
    },
  })

  await prisma.question.createMany({
    data: [
      {
        quizId: dsQuiz.id,
        text: 'What is the time complexity of accessing an element by index in an array?',
        type: 'mcq',
        options: '["O(1)", "O(n)", "O(log n)", "O(n²)"]',
        correctAnswer: 'O(1)',
        explanation: 'Arrays store elements in contiguous memory, so the address of any element can be calculated directly: base_address + index × element_size.',
        points: 10,
        order: 1,
      },
      {
        quizId: dsQuiz.id,
        text: 'Which data structure uses LIFO (Last In, First Out) ordering?',
        type: 'mcq',
        options: '["Queue", "Stack", "Array", "Linked List"]',
        correctAnswer: 'Stack',
        explanation: 'A stack follows LIFO — the last element pushed is the first one popped. Think of a stack of plates.',
        points: 10,
        order: 2,
      },
      {
        quizId: dsQuiz.id,
        text: 'What is the average time complexity of searching in a balanced Binary Search Tree?',
        type: 'mcq',
        options: '["O(1)", "O(n)", "O(log n)", "O(n log n)"]',
        correctAnswer: 'O(log n)',
        explanation: 'In a balanced BST, each comparison eliminates half the remaining nodes, giving O(log n) search time.',
        points: 10,
        order: 3,
      },
      {
        quizId: dsQuiz.id,
        text: 'Which sorting algorithm has the best average-case time complexity?',
        type: 'mcq',
        options: '["Bubble Sort - O(n²)", "Selection Sort - O(n²)", "Merge Sort - O(n log n)", "Insertion Sort - O(n²)"]',
        correctAnswer: 'Merge Sort - O(n log n)',
        explanation: 'Merge Sort guarantees O(n log n) time complexity in all cases, making it the most efficient among these options on average.',
        points: 10,
        order: 4,
      },
      {
        quizId: dsQuiz.id,
        text: 'In a doubly linked list, each node contains:',
        type: 'mcq',
        options: '["Data and one pointer", "Data and two pointers", "Two data fields and one pointer", "Only data"]',
        correctAnswer: 'Data and two pointers',
        explanation: 'A doubly linked list node contains data, a pointer to the next node, and a pointer to the previous node.',
        points: 10,
        order: 5,
      },
      {
        quizId: dsQuiz.id,
        text: 'BFS (Breadth-First Search) uses which data structure?',
        type: 'mcq',
        options: '["Stack", "Queue", "Heap", "Tree"]',
        correctAnswer: 'Queue',
        explanation: 'BFS uses a queue to explore nodes level by level. Nodes are enqueued when discovered and dequeued for processing.',
        points: 10,
        order: 6,
      },
      {
        quizId: dsQuiz.id,
        text: 'What is the main advantage of a linked list over an array?',
        type: 'mcq',
        options: '["Faster random access", "Dynamic size with efficient insertion/deletion", "Better cache performance", "Less memory usage"]',
        correctAnswer: 'Dynamic size with efficient insertion/deletion',
        explanation: 'Linked lists can grow/shrink dynamically and insert/delete nodes in O(1) time (if the position is known), unlike arrays which require shifting elements.',
        points: 10,
        order: 7,
      },
      {
        quizId: dsQuiz.id,
        text: 'Which graph algorithm finds the shortest path in a weighted graph with non-negative weights?',
        type: 'mcq',
        options: '["BFS", "DFS", "Dijkstra\'s Algorithm", "Kruskal\'s Algorithm"]',
        correctAnswer: "Dijkstra's Algorithm",
        explanation: "Dijkstra's Algorithm finds the shortest path from a source to all other vertices in a graph with non-negative edge weights.",
        points: 10,
        order: 8,
      },
      {
        quizId: dsQuiz.id,
        text: 'What is an adjacency list representation of a graph?',
        type: 'mcq',
        options: '["A 2D matrix of all possible edges", "A list of vertices with their connected neighbors", "An array of all edges", "A tree structure"]',
        correctAnswer: 'A list of vertices with their connected neighbors',
        explanation: 'An adjacency list stores each vertex along with a list of its adjacent vertices. It uses O(V + E) space, efficient for sparse graphs.',
        points: 10,
        order: 9,
      },
    ],
  })

  console.log(`  ✅ Created 6 quizzes with questions`)

  // ==================== BADGES ====================
  console.log('🏅 Creating badges...')
  const badges = await Promise.all([
    prisma.badge.create({
      data: {
        name: 'Beginner Badge',
        description: 'Complete your first lesson and begin your learning journey',
        icon: '🌟',
        category: 'achievement',
        requirement: 'Complete 1 lesson',
        points: 10,
      },
    }),
    prisma.badge.create({
      data: {
        name: 'Quiz Master',
        description: 'Score 100% on any quiz — show your mastery of the subject',
        icon: '🧠',
        category: 'achievement',
        requirement: 'Score 100% on a quiz',
        points: 50,
      },
    }),
    prisma.badge.create({
      data: {
        name: 'Learning Champion',
        description: 'Complete 50 lessons across all courses',
        icon: '👑',
        category: 'learning',
        requirement: 'Complete 50 lessons',
        points: 100,
      },
    }),
    prisma.badge.create({
      data: {
        name: 'Streak Star',
        description: 'Maintain a 7-day learning streak — consistency is key!',
        icon: '🔥',
        category: 'learning',
        requirement: '7-day streak',
        points: 75,
      },
    }),
    prisma.badge.create({
      data: {
        name: 'Quick Learner',
        description: 'Complete 5 lessons in a single day',
        icon: '⚡',
        category: 'learning',
        requirement: 'Complete 5 lessons in one day',
        points: 30,
      },
    }),
    prisma.badge.create({
      data: {
        name: 'Course Completer',
        description: 'Complete an entire course from start to finish',
        icon: '🎓',
        category: 'achievement',
        requirement: 'Complete 1 full course',
        points: 200,
      },
    }),
    prisma.badge.create({
      data: {
        name: 'Math Wizard',
        description: 'Complete all Mathematics courses with high scores',
        icon: '🧙',
        category: 'special',
        requirement: 'Complete all Math courses',
        points: 150,
      },
    }),
    prisma.badge.create({
      data: {
        name: 'Science Explorer',
        description: 'Complete all Science courses and discover the wonders of science',
        icon: '🔬',
        category: 'special',
        requirement: 'Complete all Science courses',
        points: 150,
      },
    }),
    prisma.badge.create({
      data: {
        name: 'Code Ninja',
        description: 'Complete all Computer Science courses and become a coding warrior',
        icon: '💻',
        category: 'special',
        requirement: 'Complete all CS courses',
        points: 150,
      },
    }),
    prisma.badge.create({
      data: {
        name: 'Perfectionist',
        description: 'Score above 90% in 5 different quizzes',
        icon: '💎',
        category: 'achievement',
        requirement: 'Score >90% in 5 quizzes',
        points: 100,
      },
    }),
    prisma.badge.create({
      data: {
        name: 'Social Butterfly',
        description: 'Invite 5 friends to join the learning platform',
        icon: '🦋',
        category: 'social',
        requirement: 'Invite 5 friends',
        points: 50,
      },
    }),
    prisma.badge.create({
      data: {
        name: 'Helpful Hand',
        description: 'Answer 10 questions correctly in the community forum',
        icon: '🤝',
        category: 'social',
        requirement: 'Answer 10 community questions',
        points: 75,
      },
    }),
  ])

  console.log(`  ✅ Created ${badges.length} badges`)

  // ==================== CHALLENGES ====================
  console.log('🎯 Creating challenges...')
  const challenges = await Promise.all([
    prisma.challenge.create({
      data: {
        title: 'Complete 5 Lessons This Week',
        description: 'Dedicate time to learning by completing at least 5 lessons this week. Build your knowledge consistently!',
        type: 'lesson',
        target: 5,
        points: 50,
        duration: 'weekly',
        icon: '📖',
        active: true,
      },
    }),
    prisma.challenge.create({
      data: {
        title: 'Score Above 80% in 3 Quizzes',
        description: 'Prove your understanding by scoring above 80% in at least 3 quizzes. Quality learning over quantity!',
        type: 'quiz',
        target: 3,
        points: 100,
        duration: 'weekly',
        icon: '📝',
        active: true,
      },
    }),
    prisma.challenge.create({
      data: {
        title: 'Maintain a 7-Day Streak',
        description: 'Show your dedication by learning every day for a full week. Consistency builds habits that last!',
        type: 'streak',
        target: 7,
        points: 75,
        duration: 'monthly',
        icon: '🔥',
        active: true,
      },
    }),
    prisma.challenge.create({
      data: {
        title: 'Earn 500 Points',
        description: 'Accumulate 500 points through lessons, quizzes, and challenges. Every point counts towards mastery!',
        type: 'points',
        target: 500,
        points: 75,
        duration: 'monthly',
        icon: '⭐',
        active: true,
      },
    }),
    prisma.challenge.create({
      data: {
        title: 'Complete 2 Courses',
        description: 'Go deep into your learning by completing 2 full courses. Specialization leads to expertise!',
        type: 'lesson',
        target: 2,
        points: 200,
        duration: 'monthly',
        icon: '🎓',
        active: true,
      },
    }),
    prisma.challenge.create({
      data: {
        title: 'Master 10 Topics',
        description: 'Complete all lessons in 10 different topics to become a well-rounded learner. Breadth of knowledge is power!',
        type: 'lesson',
        target: 10,
        points: 150,
        duration: 'monthly',
        icon: '🏆',
        active: true,
      },
    }),
    prisma.challenge.create({
      data: {
        title: 'Daily Learner',
        description: 'Complete at least 1 lesson today. Small steps every day lead to big results!',
        type: 'lesson',
        target: 1,
        points: 10,
        duration: 'daily',
        icon: '☀️',
        active: true,
      },
    }),
  ])

  console.log(`  ✅ Created ${challenges.length} challenges`)

  // ==================== USER PROGRESS (for student) ====================
  console.log('📊 Creating user progress for student...')

  // Get all lessons to add progress for some of them
  const allLessons = await prisma.lesson.findMany()
  const algebraLessons = allLessons.filter(l => {
    const topic = algTopic1
    return true // We'll filter below
  })

  // Get lessons for specific topics
  const algTopic1Lessons = await prisma.lesson.findMany({ where: { topicId: algTopic1.id } })
  const algTopic2Lessons = await prisma.lesson.findMany({ where: { topicId: algTopic2.id } })
  const physTopic1Lessons = await prisma.lesson.findMany({ where: { topicId: physTopic1.id } })
  const progTopic1Lessons = await prisma.lesson.findMany({ where: { topicId: progTopic1.id } })

  // Mark some lessons as completed for the student
  const progressData = []

  // Algebra Topic 1 - all completed
  for (let i = 0; i < algTopic1Lessons.length; i++) {
    progressData.push({
      userId: student.id,
      lessonId: algTopic1Lessons[i].id,
      completed: true,
      score: 85 + Math.floor(Math.random() * 16), // 85-100
      timeSpent: (algTopic1Lessons[i].duration || 15) * 60, // minutes to seconds
      completedAt: new Date(Date.now() - (7 - i) * 24 * 60 * 60 * 1000), // past week
    })
  }

  // Algebra Topic 2 - first 2 completed
  for (let i = 0; i < Math.min(2, algTopic2Lessons.length); i++) {
    progressData.push({
      userId: student.id,
      lessonId: algTopic2Lessons[i].id,
      completed: true,
      score: 80 + Math.floor(Math.random() * 21), // 80-100
      timeSpent: (algTopic2Lessons[i].duration || 15) * 60,
      completedAt: new Date(Date.now() - (3 - i) * 24 * 60 * 60 * 1000),
    })
  }

  // Physics Topic 1 - first 2 completed
  for (let i = 0; i < Math.min(2, physTopic1Lessons.length); i++) {
    progressData.push({
      userId: student.id,
      lessonId: physTopic1Lessons[i].id,
      completed: true,
      score: 75 + Math.floor(Math.random() * 26), // 75-100
      timeSpent: (physTopic1Lessons[i].duration || 15) * 60,
      completedAt: new Date(Date.now() - (5 - i) * 24 * 60 * 60 * 1000),
    })
  }

  // Programming Topic 1 - first 2 completed
  for (let i = 0; i < Math.min(2, progTopic1Lessons.length); i++) {
    progressData.push({
      userId: student.id,
      lessonId: progTopic1Lessons[i].id,
      completed: true,
      score: 90 + Math.floor(Math.random() * 11), // 90-100
      timeSpent: (progTopic1Lessons[i].duration || 15) * 60,
      completedAt: new Date(Date.now() - (2 - i) * 24 * 60 * 60 * 1000),
    })
  }

  // One in-progress lesson (not completed)
  if (progTopic1Lessons.length > 2) {
    progressData.push({
      userId: student.id,
      lessonId: progTopic1Lessons[2].id,
      completed: false,
      timeSpent: 8 * 60, // 8 minutes spent
      completedAt: null,
    })
  }

  if (physTopic1Lessons.length > 2) {
    progressData.push({
      userId: student.id,
      lessonId: physTopic1Lessons[2].id,
      completed: false,
      timeSpent: 5 * 60, // 5 minutes spent
      completedAt: null,
    })
  }

  for (const pd of progressData) {
    await prisma.userProgress.create({ data: pd })
  }

  console.log(`  ✅ Created ${progressData.length} user progress records`)

  // ==================== QUIZ ATTEMPTS (for student) ====================
  console.log('📋 Creating quiz attempts for student...')

  // Attempt on Algebra Quiz - completed with good score
  await prisma.quizAttempt.create({
    data: {
      userId: student.id,
      quizId: algebraQuiz.id,
      score: 60,
      totalPoints: 70,
      answers: '{}',
      completed: true,
      startedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
      completedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000 + 15 * 60 * 1000),
    },
  })

  // Attempt on Physics Quiz - completed with decent score
  await prisma.quizAttempt.create({
    data: {
      userId: student.id,
      quizId: physicsQuiz.id,
      score: 50,
      totalPoints: 70,
      answers: '{}',
      completed: true,
      startedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
      completedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000 + 20 * 60 * 1000),
    },
  })

  // Attempt on Programming Quiz - completed with perfect score
  await prisma.quizAttempt.create({
    data: {
      userId: student.id,
      quizId: progQuiz.id,
      score: 80,
      totalPoints: 80,
      answers: '{}',
      completed: true,
      startedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
      completedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000 + 12 * 60 * 1000),
    },
  })

  // Attempt on Data Structures Quiz - in progress (not completed)
  await prisma.quizAttempt.create({
    data: {
      userId: student.id,
      quizId: dsQuiz.id,
      score: 20,
      totalPoints: 90,
      answers: '{}',
      completed: false,
      startedAt: new Date(Date.now() - 30 * 60 * 1000), // started 30 min ago
      completedAt: null,
    },
  })

  console.log(`  ✅ Created 4 quiz attempts`)

  // ==================== USER BADGES (for student) ====================
  console.log('🎖️ Awarding badges to student...')

  await prisma.userBadge.create({
    data: {
      userId: student.id,
      badgeId: badges[0].id, // Beginner Badge
      earnedAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
    },
  })

  await prisma.userBadge.create({
    data: {
      userId: student.id,
      badgeId: badges[3].id, // Streak Star
      earnedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
    },
  })

  await prisma.userBadge.create({
    data: {
      userId: student.id,
      badgeId: badges[6].id, // Math Wizard
      earnedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
    },
  })

  await prisma.userBadge.create({
    data: {
      userId: student.id,
      badgeId: badges[9].id, // Perfectionist (for the perfect Python quiz score)
      earnedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
    },
  })

  console.log(`  ✅ Awarded 4 badges to student`)

  // ==================== USER CHALLENGES (for student) ====================
  console.log('🏃 Adding student to challenges...')

  await prisma.userChallenge.create({
    data: {
      userId: student.id,
      challengeId: challenges[0].id, // Complete 5 Lessons This Week
      progress: 4,
      completed: false,
      startedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
    },
  })

  await prisma.userChallenge.create({
    data: {
      userId: student.id,
      challengeId: challenges[1].id, // Score Above 80% in 3 Quizzes
      progress: 2,
      completed: false,
      startedAt: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000),
    },
  })

  await prisma.userChallenge.create({
    data: {
      userId: student.id,
      challengeId: challenges[2].id, // Maintain a 7-Day Streak
      progress: 5,
      completed: false,
      startedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
    },
  })

  await prisma.userChallenge.create({
    data: {
      userId: student.id,
      challengeId: challenges[3].id, // Earn 500 Points
      progress: 750,
      completed: true,
      startedAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
      completedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
    },
  })

  await prisma.userChallenge.create({
    data: {
      userId: student.id,
      challengeId: challenges[5].id, // Master 10 Topics
      progress: 3,
      completed: false,
      startedAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
    },
  })

  await prisma.userChallenge.create({
    data: {
      userId: student.id,
      challengeId: challenges[6].id, // Daily Learner
      progress: 1,
      completed: true,
      startedAt: new Date(),
      completedAt: new Date(),
    },
  })

  console.log(`  ✅ Added student to 6 challenges`)

  // ==================== RECOMMENDATIONS (for student) ====================
  console.log('💡 Creating recommendations for student...')

  await prisma.recommendation.create({
    data: {
      userId: student.id,
      courseId: calculus.id,
      reason: 'Continue your math journey after completing Algebra topics',
      type: 'next_step',
      priority: 5,
    },
  })

  await prisma.recommendation.create({
    data: {
      userId: student.id,
      courseId: dataStructures.id,
      reason: 'Recommended based on your interest in Programming with Python',
      type: 'ai_suggested',
      priority: 4,
    },
  })

  await prisma.recommendation.create({
    data: {
      userId: student.id,
      courseId: chemistry.id,
      reason: 'Popular among students who study Physics',
      type: 'popular',
      priority: 3,
    },
  })

  console.log(`  ✅ Created 3 recommendations`)

  // ==================== BOOKMARKS (for student) ====================
  console.log('🔖 Creating bookmarks for student...')

  if (algTopic1Lessons.length > 0) {
    await prisma.bookmark.create({
      data: {
        userId: student.id,
        lessonId: algTopic1Lessons[2].id, // Multi-step equations
      },
    })
  }

  if (physTopic1Lessons.length > 0) {
    await prisma.bookmark.create({
      data: {
        userId: student.id,
        lessonId: physTopic1Lessons[0].id, // Displacement, Velocity, Acceleration
      },
    })
  }

  if (progTopic1Lessons.length > 0) {
    await prisma.bookmark.create({
      data: {
        userId: student.id,
        lessonId: progTopic1Lessons[2].id, // Lists and Data Collections
      },
    })
  }

  console.log(`  ✅ Created 3 bookmarks`)

  // ==================== SUMMARY ====================
  console.log('\n' + '='.repeat(50))
  console.log('📊 SEED SUMMARY')
  console.log('='.repeat(50))

  const counts = {
    users: await prisma.user.count(),
    courses: await prisma.course.count(),
    topics: await prisma.topic.count(),
    lessons: await prisma.lesson.count(),
    quizzes: await prisma.quiz.count(),
    questions: await prisma.question.count(),
    badges: await prisma.badge.count(),
    challenges: await prisma.challenge.count(),
    userProgress: await prisma.userProgress.count(),
    quizAttempts: await prisma.quizAttempt.count(),
    userBadges: await prisma.userBadge.count(),
    userChallenges: await prisma.userChallenge.count(),
    recommendations: await prisma.recommendation.count(),
    bookmarks: await prisma.bookmark.count(),
  }

  console.log(`  Users:          ${counts.users}`)
  console.log(`  Courses:        ${counts.courses}`)
  console.log(`  Topics:         ${counts.topics}`)
  console.log(`  Lessons:        ${counts.lessons}`)
  console.log(`  Quizzes:        ${counts.quizzes}`)
  console.log(`  Questions:      ${counts.questions}`)
  console.log(`  Badges:         ${counts.badges}`)
  console.log(`  Challenges:     ${counts.challenges}`)
  console.log(`  User Progress:  ${counts.userProgress}`)
  console.log(`  Quiz Attempts:  ${counts.quizAttempts}`)
  console.log(`  User Badges:    ${counts.userBadges}`)
  console.log(`  User Challenges:${counts.userChallenges}`)
  console.log(`  Recommendations:${counts.recommendations}`)
  console.log(`  Bookmarks:      ${counts.bookmarks}`)
  console.log(`  TOTAL RECORDS:  ${Object.values(counts).reduce((a, b) => a + b, 0)}`)
  console.log('='.repeat(50))
  console.log('🌱 Seeding complete!')
}

main()
  .catch((e) => {
    console.error('❌ Seeding failed:', e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })
